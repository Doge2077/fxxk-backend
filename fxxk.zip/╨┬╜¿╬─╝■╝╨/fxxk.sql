/*
 Navicat Premium Data Transfer

 Source Server         : MySql
 Source Server Type    : MySQL
 Source Server Version : 80032 (8.0.32)
 Source Host           : localhost:3306
 Source Schema         : fxxk

 Target Server Type    : MySQL
 Target Server Version : 80032 (8.0.32)
 File Encoding         : 65001

 Date: 12/07/2023 23:34:26
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for auth_group
-- ----------------------------
DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_group
-- ----------------------------

-- ----------------------------
-- Table structure for auth_group_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_group_permissions_group_id_permission_id_0cd325b0_uniq`(`group_id` ASC, `permission_id` ASC) USING BTREE,
  INDEX `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm`(`permission_id` ASC) USING BTREE,
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_group_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for auth_permission
-- ----------------------------
DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_permission_content_type_id_codename_01ab375a_uniq`(`content_type_id` ASC, `codename` ASC) USING BTREE,
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 45 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_permission
-- ----------------------------
INSERT INTO `auth_permission` VALUES (1, 'Can add log entry', 1, 'add_logentry');
INSERT INTO `auth_permission` VALUES (2, 'Can change log entry', 1, 'change_logentry');
INSERT INTO `auth_permission` VALUES (3, 'Can delete log entry', 1, 'delete_logentry');
INSERT INTO `auth_permission` VALUES (4, 'Can view log entry', 1, 'view_logentry');
INSERT INTO `auth_permission` VALUES (5, 'Can add permission', 2, 'add_permission');
INSERT INTO `auth_permission` VALUES (6, 'Can change permission', 2, 'change_permission');
INSERT INTO `auth_permission` VALUES (7, 'Can delete permission', 2, 'delete_permission');
INSERT INTO `auth_permission` VALUES (8, 'Can view permission', 2, 'view_permission');
INSERT INTO `auth_permission` VALUES (9, 'Can add group', 3, 'add_group');
INSERT INTO `auth_permission` VALUES (10, 'Can change group', 3, 'change_group');
INSERT INTO `auth_permission` VALUES (11, 'Can delete group', 3, 'delete_group');
INSERT INTO `auth_permission` VALUES (12, 'Can view group', 3, 'view_group');
INSERT INTO `auth_permission` VALUES (13, 'Can add user', 4, 'add_user');
INSERT INTO `auth_permission` VALUES (14, 'Can change user', 4, 'change_user');
INSERT INTO `auth_permission` VALUES (15, 'Can delete user', 4, 'delete_user');
INSERT INTO `auth_permission` VALUES (16, 'Can view user', 4, 'view_user');
INSERT INTO `auth_permission` VALUES (17, 'Can add content type', 5, 'add_contenttype');
INSERT INTO `auth_permission` VALUES (18, 'Can change content type', 5, 'change_contenttype');
INSERT INTO `auth_permission` VALUES (19, 'Can delete content type', 5, 'delete_contenttype');
INSERT INTO `auth_permission` VALUES (20, 'Can view content type', 5, 'view_contenttype');
INSERT INTO `auth_permission` VALUES (21, 'Can add session', 6, 'add_session');
INSERT INTO `auth_permission` VALUES (22, 'Can change session', 6, 'change_session');
INSERT INTO `auth_permission` VALUES (23, 'Can delete session', 6, 'delete_session');
INSERT INTO `auth_permission` VALUES (24, 'Can view session', 6, 'view_session');
INSERT INTO `auth_permission` VALUES (25, 'Can add user', 7, 'add_user');
INSERT INTO `auth_permission` VALUES (26, 'Can change user', 7, 'change_user');
INSERT INTO `auth_permission` VALUES (27, 'Can delete user', 7, 'delete_user');
INSERT INTO `auth_permission` VALUES (28, 'Can view user', 7, 'view_user');
INSERT INTO `auth_permission` VALUES (29, 'Can add worker', 8, 'add_worker');
INSERT INTO `auth_permission` VALUES (30, 'Can change worker', 8, 'change_worker');
INSERT INTO `auth_permission` VALUES (31, 'Can delete worker', 8, 'delete_worker');
INSERT INTO `auth_permission` VALUES (32, 'Can view worker', 8, 'view_worker');
INSERT INTO `auth_permission` VALUES (33, 'Can add have', 9, 'add_have');
INSERT INTO `auth_permission` VALUES (34, 'Can change have', 9, 'change_have');
INSERT INTO `auth_permission` VALUES (35, 'Can delete have', 9, 'delete_have');
INSERT INTO `auth_permission` VALUES (36, 'Can view have', 9, 'view_have');
INSERT INTO `auth_permission` VALUES (37, 'Can add job', 10, 'add_job');
INSERT INTO `auth_permission` VALUES (38, 'Can change job', 10, 'change_job');
INSERT INTO `auth_permission` VALUES (39, 'Can delete job', 10, 'delete_job');
INSERT INTO `auth_permission` VALUES (40, 'Can view job', 10, 'view_job');
INSERT INTO `auth_permission` VALUES (41, 'Can add matchwork', 11, 'add_matchwork');
INSERT INTO `auth_permission` VALUES (42, 'Can change matchwork', 11, 'change_matchwork');
INSERT INTO `auth_permission` VALUES (43, 'Can delete matchwork', 11, 'delete_matchwork');
INSERT INTO `auth_permission` VALUES (44, 'Can view matchwork', 11, 'view_matchwork');

-- ----------------------------
-- Table structure for auth_user
-- ----------------------------
DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE `auth_user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `last_login` datetime(6) NULL DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `first_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `last_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(254) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_user
-- ----------------------------

-- ----------------------------
-- Table structure for auth_user_groups
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE `auth_user_groups`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_groups_user_id_group_id_94350c0c_uniq`(`user_id` ASC, `group_id` ASC) USING BTREE,
  INDEX `auth_user_groups_group_id_97559544_fk_auth_group_id`(`group_id` ASC) USING BTREE,
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_user_groups
-- ----------------------------

-- ----------------------------
-- Table structure for auth_user_user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE `auth_user_user_permissions`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq`(`user_id` ASC, `permission_id` ASC) USING BTREE,
  INDEX `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm`(`permission_id` ASC) USING BTREE,
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_user_user_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for django_admin_log
-- ----------------------------
DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `object_repr` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `action_flag` smallint UNSIGNED NOT NULL,
  `change_message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `content_type_id` int NULL DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `django_admin_log_content_type_id_c4bce8eb_fk_django_co`(`content_type_id` ASC) USING BTREE,
  INDEX `django_admin_log_user_id_c564eba6_fk_auth_user_id`(`user_id` ASC) USING BTREE,
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `django_admin_log_chk_1` CHECK (`action_flag` >= 0)
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_admin_log
-- ----------------------------

-- ----------------------------
-- Table structure for django_content_type
-- ----------------------------
DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `model` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `django_content_type_app_label_model_76bd3d3b_uniq`(`app_label` ASC, `model` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_content_type
-- ----------------------------
INSERT INTO `django_content_type` VALUES (1, 'admin', 'logentry');
INSERT INTO `django_content_type` VALUES (3, 'auth', 'group');
INSERT INTO `django_content_type` VALUES (2, 'auth', 'permission');
INSERT INTO `django_content_type` VALUES (4, 'auth', 'user');
INSERT INTO `django_content_type` VALUES (5, 'contenttypes', 'contenttype');
INSERT INTO `django_content_type` VALUES (6, 'sessions', 'session');
INSERT INTO `django_content_type` VALUES (9, 'UserCenter', 'have');
INSERT INTO `django_content_type` VALUES (10, 'UserCenter', 'job');
INSERT INTO `django_content_type` VALUES (11, 'UserCenter', 'matchwork');
INSERT INTO `django_content_type` VALUES (7, 'UserCenter', 'user');
INSERT INTO `django_content_type` VALUES (8, 'UserCenter', 'worker');

-- ----------------------------
-- Table structure for django_migrations
-- ----------------------------
DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_migrations
-- ----------------------------
INSERT INTO `django_migrations` VALUES (1, 'UserCenter', '0001_initial', '2023-07-01 11:28:26.127654');
INSERT INTO `django_migrations` VALUES (2, 'UserCenter', '0002_auto_20230606_1950', '2023-07-01 11:28:26.151797');
INSERT INTO `django_migrations` VALUES (3, 'UserCenter', '0003_auto_20230606_2029', '2023-07-01 11:28:26.178803');
INSERT INTO `django_migrations` VALUES (4, 'UserCenter', '0004_auto_20230606_2100', '2023-07-01 11:28:26.258774');
INSERT INTO `django_migrations` VALUES (5, 'UserCenter', '0005_auto_20230611_2028', '2023-07-01 11:28:26.293659');
INSERT INTO `django_migrations` VALUES (6, 'UserCenter', '0006_auto_20230611_2055', '2023-07-01 11:28:26.307663');
INSERT INTO `django_migrations` VALUES (7, 'UserCenter', '0007_worker_fileid', '2023-07-01 11:28:26.323464');
INSERT INTO `django_migrations` VALUES (8, 'contenttypes', '0001_initial', '2023-07-01 11:28:26.341957');
INSERT INTO `django_migrations` VALUES (9, 'auth', '0001_initial', '2023-07-01 11:28:26.555356');
INSERT INTO `django_migrations` VALUES (10, 'admin', '0001_initial', '2023-07-01 11:28:26.613634');
INSERT INTO `django_migrations` VALUES (11, 'admin', '0002_logentry_remove_auto_add', '2023-07-01 11:28:26.620635');
INSERT INTO `django_migrations` VALUES (12, 'admin', '0003_logentry_add_action_flag_choices', '2023-07-01 11:28:26.626636');
INSERT INTO `django_migrations` VALUES (13, 'contenttypes', '0002_remove_content_type_name', '2023-07-01 11:28:26.667007');
INSERT INTO `django_migrations` VALUES (14, 'auth', '0002_alter_permission_name_max_length', '2023-07-01 11:28:26.689562');
INSERT INTO `django_migrations` VALUES (15, 'auth', '0003_alter_user_email_max_length', '2023-07-01 11:28:26.707145');
INSERT INTO `django_migrations` VALUES (16, 'auth', '0004_alter_user_username_opts', '2023-07-01 11:28:26.713179');
INSERT INTO `django_migrations` VALUES (17, 'auth', '0005_alter_user_last_login_null', '2023-07-01 11:28:26.738194');
INSERT INTO `django_migrations` VALUES (18, 'auth', '0006_require_contenttypes_0002', '2023-07-01 11:28:26.740180');
INSERT INTO `django_migrations` VALUES (19, 'auth', '0007_alter_validators_add_error_messages', '2023-07-01 11:28:26.749481');
INSERT INTO `django_migrations` VALUES (20, 'auth', '0008_alter_user_username_max_length', '2023-07-01 11:28:26.778487');
INSERT INTO `django_migrations` VALUES (21, 'auth', '0009_alter_user_last_name_max_length', '2023-07-01 11:28:26.812554');
INSERT INTO `django_migrations` VALUES (22, 'auth', '0010_alter_group_name_max_length', '2023-07-01 11:28:26.829683');
INSERT INTO `django_migrations` VALUES (23, 'auth', '0011_update_proxy_permissions', '2023-07-01 11:28:26.836684');
INSERT INTO `django_migrations` VALUES (24, 'auth', '0012_alter_user_first_name_max_length', '2023-07-01 11:28:26.867692');
INSERT INTO `django_migrations` VALUES (25, 'sessions', '0001_initial', '2023-07-01 11:28:26.912468');

-- ----------------------------
-- Table structure for django_session
-- ----------------------------
DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session`  (
  `session_key` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `session_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`) USING BTREE,
  INDEX `django_session_expire_date_a5c62663`(`expire_date` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_session
-- ----------------------------

-- ----------------------------
-- Table structure for have
-- ----------------------------
DROP TABLE IF EXISTS `have`;
CREATE TABLE `have`  (
  `hid` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL,
  `wid` int NOT NULL,
  PRIMARY KEY (`hid`) USING BTREE,
  INDEX `have_hid_92aeaf_idx`(`hid` ASC) USING BTREE,
  INDEX `have_uid_41684d_idx`(`uid` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 301 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of have
-- ----------------------------
INSERT INTO `have` VALUES (1, 3, 1);
INSERT INTO `have` VALUES (2, 3, 2);
INSERT INTO `have` VALUES (3, 3, 3);
INSERT INTO `have` VALUES (4, 3, 4);
INSERT INTO `have` VALUES (5, 3, 5);
INSERT INTO `have` VALUES (6, 3, 6);
INSERT INTO `have` VALUES (7, 3, 7);
INSERT INTO `have` VALUES (8, 3, 8);
INSERT INTO `have` VALUES (9, 3, 9);
INSERT INTO `have` VALUES (10, 3, 10);
INSERT INTO `have` VALUES (11, 3, 11);
INSERT INTO `have` VALUES (12, 3, 12);
INSERT INTO `have` VALUES (13, 3, 13);
INSERT INTO `have` VALUES (14, 3, 14);
INSERT INTO `have` VALUES (15, 3, 15);
INSERT INTO `have` VALUES (16, 3, 16);
INSERT INTO `have` VALUES (17, 3, 17);
INSERT INTO `have` VALUES (18, 3, 18);
INSERT INTO `have` VALUES (19, 3, 19);
INSERT INTO `have` VALUES (20, 3, 20);
INSERT INTO `have` VALUES (21, 3, 21);
INSERT INTO `have` VALUES (22, 3, 22);
INSERT INTO `have` VALUES (23, 3, 23);
INSERT INTO `have` VALUES (24, 3, 24);
INSERT INTO `have` VALUES (25, 3, 25);
INSERT INTO `have` VALUES (26, 3, 26);
INSERT INTO `have` VALUES (27, 3, 27);
INSERT INTO `have` VALUES (28, 3, 28);
INSERT INTO `have` VALUES (29, 3, 29);
INSERT INTO `have` VALUES (30, 3, 30);
INSERT INTO `have` VALUES (31, 3, 31);
INSERT INTO `have` VALUES (32, 3, 32);
INSERT INTO `have` VALUES (33, 3, 33);
INSERT INTO `have` VALUES (34, 3, 34);
INSERT INTO `have` VALUES (35, 3, 35);
INSERT INTO `have` VALUES (36, 3, 36);
INSERT INTO `have` VALUES (37, 3, 37);
INSERT INTO `have` VALUES (38, 3, 38);
INSERT INTO `have` VALUES (39, 3, 39);
INSERT INTO `have` VALUES (40, 3, 40);
INSERT INTO `have` VALUES (41, 3, 41);
INSERT INTO `have` VALUES (42, 3, 42);
INSERT INTO `have` VALUES (43, 3, 43);
INSERT INTO `have` VALUES (44, 3, 44);
INSERT INTO `have` VALUES (45, 3, 45);
INSERT INTO `have` VALUES (46, 3, 46);
INSERT INTO `have` VALUES (47, 3, 47);
INSERT INTO `have` VALUES (48, 3, 48);
INSERT INTO `have` VALUES (49, 3, 49);
INSERT INTO `have` VALUES (50, 3, 50);
INSERT INTO `have` VALUES (51, 3, 51);
INSERT INTO `have` VALUES (52, 3, 52);
INSERT INTO `have` VALUES (53, 3, 53);
INSERT INTO `have` VALUES (54, 3, 54);
INSERT INTO `have` VALUES (55, 3, 55);
INSERT INTO `have` VALUES (56, 3, 56);
INSERT INTO `have` VALUES (57, 3, 57);
INSERT INTO `have` VALUES (58, 3, 58);
INSERT INTO `have` VALUES (59, 3, 59);
INSERT INTO `have` VALUES (60, 3, 60);
INSERT INTO `have` VALUES (61, 3, 61);
INSERT INTO `have` VALUES (62, 3, 62);
INSERT INTO `have` VALUES (63, 3, 63);
INSERT INTO `have` VALUES (64, 3, 64);
INSERT INTO `have` VALUES (65, 3, 65);
INSERT INTO `have` VALUES (66, 3, 66);
INSERT INTO `have` VALUES (67, 3, 67);
INSERT INTO `have` VALUES (68, 3, 68);
INSERT INTO `have` VALUES (69, 3, 69);
INSERT INTO `have` VALUES (70, 3, 70);
INSERT INTO `have` VALUES (71, 3, 71);
INSERT INTO `have` VALUES (72, 3, 72);
INSERT INTO `have` VALUES (73, 3, 73);
INSERT INTO `have` VALUES (74, 3, 74);
INSERT INTO `have` VALUES (75, 3, 75);
INSERT INTO `have` VALUES (76, 3, 76);
INSERT INTO `have` VALUES (77, 3, 77);
INSERT INTO `have` VALUES (78, 3, 78);
INSERT INTO `have` VALUES (79, 3, 79);
INSERT INTO `have` VALUES (80, 3, 80);
INSERT INTO `have` VALUES (81, 3, 81);
INSERT INTO `have` VALUES (82, 3, 82);
INSERT INTO `have` VALUES (83, 3, 83);
INSERT INTO `have` VALUES (84, 3, 84);
INSERT INTO `have` VALUES (85, 3, 85);
INSERT INTO `have` VALUES (86, 3, 86);
INSERT INTO `have` VALUES (87, 3, 87);
INSERT INTO `have` VALUES (88, 3, 88);
INSERT INTO `have` VALUES (89, 3, 89);
INSERT INTO `have` VALUES (90, 3, 90);
INSERT INTO `have` VALUES (91, 3, 91);
INSERT INTO `have` VALUES (92, 3, 92);
INSERT INTO `have` VALUES (93, 3, 93);
INSERT INTO `have` VALUES (94, 3, 94);
INSERT INTO `have` VALUES (95, 3, 95);
INSERT INTO `have` VALUES (96, 3, 96);
INSERT INTO `have` VALUES (97, 3, 97);
INSERT INTO `have` VALUES (98, 3, 98);
INSERT INTO `have` VALUES (99, 3, 99);
INSERT INTO `have` VALUES (100, 3, 100);
INSERT INTO `have` VALUES (101, 3, 101);
INSERT INTO `have` VALUES (102, 3, 102);
INSERT INTO `have` VALUES (103, 3, 103);
INSERT INTO `have` VALUES (104, 3, 104);
INSERT INTO `have` VALUES (105, 3, 105);
INSERT INTO `have` VALUES (106, 3, 106);
INSERT INTO `have` VALUES (107, 3, 107);
INSERT INTO `have` VALUES (108, 3, 108);
INSERT INTO `have` VALUES (109, 3, 109);
INSERT INTO `have` VALUES (110, 3, 110);
INSERT INTO `have` VALUES (111, 3, 111);
INSERT INTO `have` VALUES (112, 3, 112);
INSERT INTO `have` VALUES (113, 3, 113);
INSERT INTO `have` VALUES (114, 3, 114);
INSERT INTO `have` VALUES (115, 3, 115);
INSERT INTO `have` VALUES (116, 3, 116);
INSERT INTO `have` VALUES (117, 3, 117);
INSERT INTO `have` VALUES (118, 3, 118);
INSERT INTO `have` VALUES (119, 3, 119);
INSERT INTO `have` VALUES (120, 3, 120);
INSERT INTO `have` VALUES (121, 3, 121);
INSERT INTO `have` VALUES (122, 3, 122);
INSERT INTO `have` VALUES (123, 3, 123);
INSERT INTO `have` VALUES (124, 3, 124);
INSERT INTO `have` VALUES (125, 3, 125);
INSERT INTO `have` VALUES (126, 3, 126);
INSERT INTO `have` VALUES (127, 3, 127);
INSERT INTO `have` VALUES (128, 3, 128);
INSERT INTO `have` VALUES (129, 3, 129);
INSERT INTO `have` VALUES (130, 3, 130);
INSERT INTO `have` VALUES (131, 3, 131);
INSERT INTO `have` VALUES (132, 3, 132);
INSERT INTO `have` VALUES (133, 3, 133);
INSERT INTO `have` VALUES (134, 3, 134);
INSERT INTO `have` VALUES (135, 3, 135);
INSERT INTO `have` VALUES (136, 3, 136);
INSERT INTO `have` VALUES (137, 3, 137);
INSERT INTO `have` VALUES (138, 3, 138);
INSERT INTO `have` VALUES (139, 3, 139);
INSERT INTO `have` VALUES (140, 3, 140);
INSERT INTO `have` VALUES (141, 3, 141);
INSERT INTO `have` VALUES (142, 3, 142);
INSERT INTO `have` VALUES (143, 3, 143);
INSERT INTO `have` VALUES (144, 3, 144);
INSERT INTO `have` VALUES (145, 3, 145);
INSERT INTO `have` VALUES (146, 3, 146);
INSERT INTO `have` VALUES (147, 3, 147);
INSERT INTO `have` VALUES (148, 3, 148);
INSERT INTO `have` VALUES (149, 3, 149);
INSERT INTO `have` VALUES (150, 3, 150);
INSERT INTO `have` VALUES (151, 3, 151);
INSERT INTO `have` VALUES (152, 3, 152);
INSERT INTO `have` VALUES (153, 3, 153);
INSERT INTO `have` VALUES (154, 3, 154);
INSERT INTO `have` VALUES (155, 3, 155);
INSERT INTO `have` VALUES (156, 3, 156);
INSERT INTO `have` VALUES (157, 3, 157);
INSERT INTO `have` VALUES (158, 3, 158);
INSERT INTO `have` VALUES (159, 3, 159);
INSERT INTO `have` VALUES (160, 3, 160);
INSERT INTO `have` VALUES (161, 3, 161);
INSERT INTO `have` VALUES (162, 3, 162);
INSERT INTO `have` VALUES (163, 3, 163);
INSERT INTO `have` VALUES (164, 3, 164);
INSERT INTO `have` VALUES (165, 3, 165);
INSERT INTO `have` VALUES (166, 3, 166);
INSERT INTO `have` VALUES (167, 3, 167);
INSERT INTO `have` VALUES (168, 3, 168);
INSERT INTO `have` VALUES (169, 3, 169);
INSERT INTO `have` VALUES (170, 3, 170);
INSERT INTO `have` VALUES (171, 3, 171);
INSERT INTO `have` VALUES (172, 3, 172);
INSERT INTO `have` VALUES (173, 3, 173);
INSERT INTO `have` VALUES (174, 3, 174);
INSERT INTO `have` VALUES (175, 3, 175);
INSERT INTO `have` VALUES (176, 3, 176);
INSERT INTO `have` VALUES (177, 3, 177);
INSERT INTO `have` VALUES (178, 3, 178);
INSERT INTO `have` VALUES (179, 3, 179);
INSERT INTO `have` VALUES (180, 3, 180);
INSERT INTO `have` VALUES (181, 3, 181);
INSERT INTO `have` VALUES (182, 3, 182);
INSERT INTO `have` VALUES (183, 3, 183);
INSERT INTO `have` VALUES (184, 3, 184);
INSERT INTO `have` VALUES (185, 3, 185);
INSERT INTO `have` VALUES (186, 3, 186);
INSERT INTO `have` VALUES (187, 3, 187);
INSERT INTO `have` VALUES (188, 3, 188);
INSERT INTO `have` VALUES (189, 3, 189);
INSERT INTO `have` VALUES (190, 3, 190);
INSERT INTO `have` VALUES (191, 3, 191);
INSERT INTO `have` VALUES (192, 3, 192);
INSERT INTO `have` VALUES (193, 3, 193);
INSERT INTO `have` VALUES (194, 3, 194);
INSERT INTO `have` VALUES (195, 3, 195);
INSERT INTO `have` VALUES (196, 3, 196);
INSERT INTO `have` VALUES (197, 3, 197);
INSERT INTO `have` VALUES (198, 3, 198);
INSERT INTO `have` VALUES (199, 3, 199);
INSERT INTO `have` VALUES (200, 3, 200);
INSERT INTO `have` VALUES (201, 3, 201);
INSERT INTO `have` VALUES (202, 3, 202);
INSERT INTO `have` VALUES (203, 3, 203);
INSERT INTO `have` VALUES (204, 3, 204);
INSERT INTO `have` VALUES (205, 3, 205);
INSERT INTO `have` VALUES (206, 3, 206);
INSERT INTO `have` VALUES (207, 3, 207);
INSERT INTO `have` VALUES (208, 3, 208);
INSERT INTO `have` VALUES (209, 3, 209);
INSERT INTO `have` VALUES (210, 3, 210);
INSERT INTO `have` VALUES (211, 3, 211);
INSERT INTO `have` VALUES (212, 3, 212);
INSERT INTO `have` VALUES (213, 3, 213);
INSERT INTO `have` VALUES (214, 3, 214);
INSERT INTO `have` VALUES (215, 3, 215);
INSERT INTO `have` VALUES (216, 3, 216);
INSERT INTO `have` VALUES (217, 3, 217);
INSERT INTO `have` VALUES (218, 3, 218);
INSERT INTO `have` VALUES (219, 3, 219);
INSERT INTO `have` VALUES (220, 3, 220);
INSERT INTO `have` VALUES (221, 3, 221);
INSERT INTO `have` VALUES (222, 3, 222);
INSERT INTO `have` VALUES (223, 3, 223);
INSERT INTO `have` VALUES (224, 3, 224);
INSERT INTO `have` VALUES (225, 3, 225);
INSERT INTO `have` VALUES (226, 3, 226);
INSERT INTO `have` VALUES (227, 3, 227);
INSERT INTO `have` VALUES (228, 3, 228);
INSERT INTO `have` VALUES (229, 3, 229);
INSERT INTO `have` VALUES (230, 3, 230);
INSERT INTO `have` VALUES (231, 3, 231);
INSERT INTO `have` VALUES (232, 3, 232);
INSERT INTO `have` VALUES (233, 3, 233);
INSERT INTO `have` VALUES (234, 3, 234);
INSERT INTO `have` VALUES (235, 3, 235);
INSERT INTO `have` VALUES (236, 3, 236);
INSERT INTO `have` VALUES (237, 3, 237);
INSERT INTO `have` VALUES (238, 3, 238);
INSERT INTO `have` VALUES (239, 3, 239);
INSERT INTO `have` VALUES (240, 3, 240);
INSERT INTO `have` VALUES (241, 3, 241);
INSERT INTO `have` VALUES (242, 3, 242);
INSERT INTO `have` VALUES (243, 3, 243);
INSERT INTO `have` VALUES (244, 3, 244);
INSERT INTO `have` VALUES (245, 3, 245);
INSERT INTO `have` VALUES (246, 3, 246);
INSERT INTO `have` VALUES (247, 3, 247);
INSERT INTO `have` VALUES (248, 3, 248);
INSERT INTO `have` VALUES (249, 3, 249);
INSERT INTO `have` VALUES (250, 3, 250);
INSERT INTO `have` VALUES (251, 3, 251);
INSERT INTO `have` VALUES (252, 3, 252);
INSERT INTO `have` VALUES (253, 3, 253);
INSERT INTO `have` VALUES (254, 3, 254);
INSERT INTO `have` VALUES (255, 3, 255);
INSERT INTO `have` VALUES (256, 3, 256);
INSERT INTO `have` VALUES (257, 3, 257);
INSERT INTO `have` VALUES (258, 3, 258);
INSERT INTO `have` VALUES (259, 3, 259);
INSERT INTO `have` VALUES (260, 3, 260);
INSERT INTO `have` VALUES (261, 3, 261);
INSERT INTO `have` VALUES (262, 3, 262);
INSERT INTO `have` VALUES (263, 3, 263);
INSERT INTO `have` VALUES (264, 3, 264);
INSERT INTO `have` VALUES (265, 3, 265);
INSERT INTO `have` VALUES (266, 3, 266);
INSERT INTO `have` VALUES (267, 3, 267);
INSERT INTO `have` VALUES (268, 3, 268);
INSERT INTO `have` VALUES (269, 3, 269);
INSERT INTO `have` VALUES (270, 3, 270);
INSERT INTO `have` VALUES (271, 3, 271);
INSERT INTO `have` VALUES (272, 3, 272);
INSERT INTO `have` VALUES (273, 3, 273);
INSERT INTO `have` VALUES (274, 3, 274);
INSERT INTO `have` VALUES (275, 3, 275);
INSERT INTO `have` VALUES (276, 3, 276);
INSERT INTO `have` VALUES (277, 3, 277);
INSERT INTO `have` VALUES (278, 3, 278);
INSERT INTO `have` VALUES (279, 3, 279);
INSERT INTO `have` VALUES (280, 3, 280);
INSERT INTO `have` VALUES (281, 3, 281);
INSERT INTO `have` VALUES (282, 3, 282);
INSERT INTO `have` VALUES (283, 3, 283);
INSERT INTO `have` VALUES (284, 3, 284);
INSERT INTO `have` VALUES (285, 3, 285);
INSERT INTO `have` VALUES (286, 3, 286);
INSERT INTO `have` VALUES (287, 3, 287);
INSERT INTO `have` VALUES (288, 3, 288);
INSERT INTO `have` VALUES (289, 3, 289);
INSERT INTO `have` VALUES (290, 3, 290);
INSERT INTO `have` VALUES (291, 3, 291);
INSERT INTO `have` VALUES (292, 3, 292);
INSERT INTO `have` VALUES (293, 3, 293);
INSERT INTO `have` VALUES (294, 3, 294);
INSERT INTO `have` VALUES (295, 3, 295);
INSERT INTO `have` VALUES (296, 3, 296);
INSERT INTO `have` VALUES (297, 3, 297);
INSERT INTO `have` VALUES (298, 3, 298);
INSERT INTO `have` VALUES (299, 3, 299);
INSERT INTO `have` VALUES (300, 3, 300);

-- ----------------------------
-- Table structure for job
-- ----------------------------
DROP TABLE IF EXISTS `job`;
CREATE TABLE `job`  (
  `jid` int NOT NULL AUTO_INCREMENT,
  `jname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `jneed_age` int NULL DEFAULT NULL,
  `jneed_edu` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `jneed_other` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `jneed_year` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `hash_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`jid`) USING BTREE,
  INDEX `job_jid_5abccb_idx`(`jid` ASC) USING BTREE,
  INDEX `job_jname_b2fd94_idx`(`jname` ASC) USING BTREE,
  INDEX `job_hash_co_2b97bd_idx`(`hash_code` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of job
-- ----------------------------
INSERT INTO `job` VALUES (1, '产品运营', 0, '无', '岗位职责\n1.负责产品上线前后的线上、线下的运营方案和推广工作，协助项目负责人对接市场、产品开发等，完成个项目目标；\n2.负责产品运营中与线下的各种合作，配合完成商务推广，实施项目评估和监控，提升用户活跃度和忠诚度；\n3.负责研究行业竞争动态，定期拜访客户，维护重要客户关系发现客户的需求，引导客户的业务需求，根据自身产品制定产品营销策略，达成既定目标；\n4.负责分析和挖掘产品运营数据、用户行为数据等重要价值信息\n5.负责跟进和整理产品用户反馈，协同产品经理提出产品迭代方案。\n任职要求：\n1.2年及以上产品运营经验；\n2.主动性强，逻辑清晰，沟通能力强，能独立负责和落地运营项目能调动资源为运营目标服', '2年以上', '746fde40e011bc7c5db44ca2351908589a9f8aa16ed93d5fcd357c9df4df4b70');
INSERT INTO `job` VALUES (2, '平面设计师', 0, '大专', '岗位职责：\n1.负责公司公众号的维护和内容推送；\n2.短视频相关内容的文案脚本策划，视频制作及编辑。并结合公司宣传计划，不断优化视频内容；\n3.协助其他平面设计、视频编辑等内容。\n任职要求：\n1.大专及以上学历，1-2年相关工作经验；\n2.熟悉平面设计软件及视频剪辑等，设计感好；\n3.工作责任心强，沟通及理解能力强。', '1-2年', '14b7fa102b989cac3d2e71cbbc70adc9c14e1c73a77980cdcdc5f57f2b3c46cf');
INSERT INTO `job` VALUES (3, '财务', 0, '本科', '岗位职责：\n1.全面负责财务部的日常管理工作；\n2.组织制定财务方面的管理制度及有关规定，并监督执行；\n3.向公司提供各项财务报告和必要的财务分析；\n4.监控可能会对公司造成经济损失的重大经济合同；\n5.有独立处理账务和税务的能力者优先；\n6.有全盘账务处理，税务工作，年度汇算清缴能力者优先；\n7.公司资质和合同的归档保管工作；\n8.完成上级领导交代的其他日常工作任务。\n任职要求：\n1.本科及以上学历；\n2.通晓财会专业知识，熟悉国家有关财务、会计、税收政策和实务；\n3.有互联网行业相关经验优先；\n4.原则性强，沟通能力佳，有良好的团队协作意识。', '0', 'c5990ff4dd90f2e3d4addf90eef303ab749958ada12e25ee3404b8077c4506fa');
INSERT INTO `job` VALUES (4, '市场营销', 0, '本科', '岗位职责：\n1.根据公司发展方向及阶段性目标，制定品牌战略、推广策略等年度经营方案；\n2.参与各产品推广筹划方案的制定与执行；\n3.负责企业整体形象的定位与维护，建立完整的产品口碑营销方案及公司形象推广方案；\n4.负责与新媒体及知名媒体进行沟通，开展长期良好合作；\n5.负责制作与推广公司各类宣传资料，完善对外各类宣传通稿；\n6.负责为公司的知识产权、荣誉资质等进行申请、维护与宣传。\n职位要求：\n1.熟练使用办公软件，可以独立制作表格、PPT等；\n2.良好的沟通能力，善于维护客户关系；\n3.有拓展、策划经验能力者优先考虑。\n4.本科以上\n5.10年以上相关工作经验\n', '10', '653eff46ed0fa0c2221f93e2be6874abaac6a30c2840b0c82b8a7b17e2cf7437');
INSERT INTO `job` VALUES (5, '项目主管', 0, '本科', '岗位职责：\n1.责任项目的整体管理；\n2.项目的订单下单、样板配合；\n3.产品批量安装的现场、质量、进度、成本的管理；\n4.项目的沟通协调管理和售后维护工作；\n5.工程回款及安装款结算工作；\n6.安装队及文明生产的管理工作；\n7.项目管理的档案化建设与管理的工作。\n任职要求:\n1.熟练操作使用WORD/EXCEL/等办公软件；\n2.工作严谨、认真、细致，有良好的执行力；\n3.熟悉本行业的规范，具有良好沟通及协调能力；\n4.本科以上\n5.3年以上项目主管经验', '3年以上', 'd24cda8199eedeef01fe09de452256138452d15e6cd868d65f969397a5b5081e');
INSERT INTO `job` VALUES (6, '开发工程师', 0, '本科', '岗位职责：\n1.负责公司产品运营相关网站后端快速响应开发；\n2.负责公司运营支持相关系统开发；\n3.负责设计和开发一些内部工具，提高网站整体性开发效益，保证一定的质量；\n4.负责相关APP接口开发；\n5.配合移动部门与产品部门实现服务器端相关接口开发。\n任职要求:\n1.学历本科以上，计算机相关专业；\n2.3年以上软件开发经验；\n3.熟悉JAVA语言，有APP开发经验。\n', '0', 'e14ecf30ef29a4396f6e175a655da444ab803d40ac34af6f8288ddb5fb8a59df');
INSERT INTO `job` VALUES (7, '文员', 25, '大专', '岗位职责：\n1.接听、转接电话;接待来访人员；\n2.负责办公室的文秘、信息、机要和保密工作，做好办公室档案收集、整理工作；\n3.做好会议纪要；\n4.负责公司公文、信件、邮件、报刊杂志的分送；\n5.负责传真件的收发工作；\n6.负责办公室仓库的保管工作，做好物品出入库的登记；\n7.做好公司宣传专栏的组稿；\n8.按照公司印信管理规定，保管使用公章，并对其负责；\n任职要求:\n1.25岁以上，一年以上相关工作经验；\n2.大专以上学历:\n3.熟练使用办公软件，处理日常办公业务，管理施工档案，有装饰公司工作经验者优先；\n4.具有全面的工作计划、对外沟通及应变等能力；\n\n', '1年', 'b0b4648ec40b33a437ac26aff77bf8b391e7f4fb670b5a72cd5fad42e242d1c1');
INSERT INTO `job` VALUES (8, '电商运营', 0, '无', '岗位职责：\n1.负责每日各类日商品的挑品并制定各个品类商品的挑品标准；\n2.分析商品各项运营数据建立数据模型，并优化商品挑品标准；\n3.对各类目下商品内容的完整性和美观性负责；\n4.了解和研究其它购物平台商品选品的特性，研究各品类商品的用户喜好；\n5.编辑优选商品的推荐理由并对用户提交的推荐理由进行审核；\n6.和平台用户及商家的沟通；\n7.其它一些交待的工作任务。\n任职要求:\n1.2 年及以上电商运营工作阅历，例如天猫或者小程序电商 阅\n历\n2.较为完整的电商学问体系，缜密的分析规律力量以及完整 的电商思维框架\n3.执行力量强，优秀的沟通协调力量、书面表达力量、规律思维力量\n', '2年', 'a80312b5bf1632cc75be8237c997375ccd309b0dc2693e80cc572a87509de3a5');
INSERT INTO `job` VALUES (9, '人力资源管理', 0, '大专', '岗位职责：\n1.协助上级建立健全公司招聘、培训、工资、保险、福利、绩效考核等人力资源制度建设\n2.建立、维护人事档案，办理和更新劳动合同;\n3.执行人力资源管理各项实务的操作流程和各类规章制度的实施，配合其他业务部门工作；\n4.执行招聘工作流程，协调、办理员工招聘、入职、离职、调任、升职等手续\n5.协同开展新员工入职培训，业务培训，执行培训计划，联系组织外部培训以及培训效果的跟踪、反馈;\n6.负责员工工资结算和年度工资总额申报，办理相应的社会保险等8、帮助建立员工关系，协调员工与管理层的关系，组织员工的活动。\n任职要求:\n1.大专以上学历;\n2.两年以上人力资源工作经验;\n3.熟悉人力资源管理各项实务的操作流程,熟悉国家各项劳动人事法规政策,并能实际操作运用;\n', '2年', '35b327c3926473870b320da25542be27e5d9d177fa6286543d94825ce9b7eed9');
INSERT INTO `job` VALUES (10, '风控专员', 0, '硕士', '岗位职责：\n1、制定公司风险管理的目标，制度，流程。\n2、建立项目风险管理体系，推进公司内外部风险的全面防范与控制。 \n3、熟悉金融市场、房产市场、二手车买卖相关法律法规及信贷风险防范识别、监控、化解体系\n4、完成上级领导临时交办的其他任务。\n任职要求:\n1、熟悉各种汇率、期权的定义与应用\n2、熟悉境内外各银行理财产品操作:\n3、熟悉EXCEL操作，有数据统计和分析能力\n4、专业要求:金融、国际贸易.\n5、硕士以上\n6、5年以上相关工作经验\n', '5年', '09c033b069845bd9f6d37988ad1960a77cfdec3a6a65fbd1236c218388b8a928');

-- ----------------------------
-- Table structure for matchwork
-- ----------------------------
DROP TABLE IF EXISTS `matchwork`;
CREATE TABLE `matchwork`  (
  `minfo` int NOT NULL AUTO_INCREMENT,
  `wid` int NOT NULL,
  `jid` int NOT NULL,
  `match` double NOT NULL,
  PRIMARY KEY (`minfo`) USING BTREE,
  INDEX `matchwork_minfo_f384d1_idx`(`minfo` ASC) USING BTREE,
  INDEX `matchwork_wid_1120cb_idx`(`wid` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of matchwork
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `uid` int NOT NULL AUTO_INCREMENT,
  `hash_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`uid`) USING BTREE,
  UNIQUE INDEX `user_hash_code_2bc75cad_uniq`(`hash_code` ASC) USING BTREE,
  INDEX `user_uid_8f8462_idx`(`uid` ASC) USING BTREE,
  INDEX `user_hash_co_1ccebb_idx`(`hash_code` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '123');
INSERT INTO `user` VALUES (4, '18ffa8b2250e2cb15905d4b4e2e8e5ac025fbfbef2d2d122c69471c693b1cf2d');
INSERT INTO `user` VALUES (2, 'ab828b6d37e3dc89402d0ec2e406ae06cc9741a4c6720652763a7ec286abc5d3');
INSERT INTO `user` VALUES (3, 'd82494f05d6917ba02f7aaa29689ccb444bb73f20380876cb05d1f37537b7892');

-- ----------------------------
-- Table structure for worker
-- ----------------------------
DROP TABLE IF EXISTS `worker`;
CREATE TABLE `worker`  (
  `wid` int NOT NULL AUTO_INCREMENT,
  `worker_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `sex` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `age` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `phone_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `e_mail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `edu_school` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `edu_level` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `work_year` int NULL DEFAULT NULL,
  `statue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `urls` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `url_format` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `hash_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `fileid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`wid`) USING BTREE,
  UNIQUE INDEX `worker_hash_code_74c6d579_uniq`(`hash_code` ASC) USING BTREE,
  INDEX `worker_worker__60a34a_idx`(`worker_name` ASC) USING BTREE,
  INDEX `worker_wid_20c430_idx`(`wid` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 301 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of worker
-- ----------------------------
INSERT INTO `worker` VALUES (1, '张吉惟', '女', '24', '13899999999', 'zhangjiwei@163.com', '北京海淀区', '北京师范大学', '本科', 3, '党员', NULL, NULL, '46b563f82a8a740381f37ff123bba28df686af2a764ad2c5765f4b6d5fc4a076', '1');
INSERT INTO `worker` VALUES (2, '林国瑞', '男', '27', '13831088888', 'linguorui@qq.com', '北京', '中国传媒大学', '本科', 11, '党员', NULL, NULL, '809f9bffbd4ee8bbc2a3c48d235a41ee0640cbaeb6a6c20ab92a575f5386147c', '2');
INSERT INTO `worker` VALUES (3, '林玟书', '男', '31', '13801138023', 'linwenshu@qq.com', '广东省广州市', '南方科技大学', '本科', 6, '团员', NULL, NULL, 'da2b8b29f00fc93721feba036fa3def29cc7e422c1c9ce39bc4899afcadb3522', '3');
INSERT INTO `worker` VALUES (4, '林雅南', '男', '33', '13801138823', 'linyanan@qq.com', '广东省广州市海珠区', '华南师范大学', '本科', 3, '党员', NULL, NULL, '3c8fb1f2eba57d01c5314149d13b6db07e663311394f810aff7f9b18a7af9349', '4');
INSERT INTO `worker` VALUES (5, '江奕云', '男', '25', '13812138123', 'nesson@91muban.cn', '广东省广州市海珠区', '华南理工大学', '本科', 5, '党员', NULL, NULL, '22d6e619a561cb830c845f7a6ab1c49a51d60ff5fb5797c5edd043379c6f17e8', '5');
INSERT INTO `worker` VALUES (6, '刘柏宏', '男', '26', '13889138123', 'liubohong@qq.com', '广东省广州市海珠区', '广东师范专科学院', '大专', 9, '党员', NULL, NULL, 'ffe5dfa7eedf95d9d42d36f466c765f73f6be03f01e76ab766d3819c062feaf1', '6');
INSERT INTO `worker` VALUES (7, '阮建安', '女', '28', '13818138525', 'ruanjianna@qq.com', '广东省广州市海珠区', '奈森师范大学', '大专', 7, '党员', NULL, NULL, '4f1ae1bb3c059220d5a9ba20e6501078fd184477c69eb11b35d20bd221623e88', '7');
INSERT INTO `worker` VALUES (8, '林子帆', '女', '31', '13808138036', 'linzifan@qq.com', '广东省广州市海珠区', '阳江职业学院', '大专', 10, '党员', NULL, NULL, 'dec399045812ca0f73be25c4c905055e955565ee20c22df7ed292b487e05ba4f', '8');
INSERT INTO `worker` VALUES (9, '夏志豪', '女', '25', '13822138221', 'xiazhihao@qq.com', '广东省广州市海珠区', '广州文艺职业技术学院', '大专', 5, '党员', NULL, NULL, 'de91e18e6661de2709f0b59ec4e07b335e7d1df36c8a4f04f5158fb0eac0be56', '9');
INSERT INTO `worker` VALUES (10, '吉茹定', '女', '31', '13823138023', 'nesson@91muban.cn', '广东省广州市海珠区', '广州科学技术职业学院', '大专', 10, '党员', NULL, NULL, '24399e19a126cc1860ebbab15c41777305be8e119d8e987ea1b2a5c18cbca479', '10');
INSERT INTO `worker` VALUES (11, '李中冰', '女', '24', '13802131218', 'lizhongbing@qq.com', '广东省广州市海珠区', '顺德中专学校', '中专', 7, '党员', NULL, NULL, '04eb6fd7d4b1ac411f2241e254dff00ccb89750c19cb6ea6ba275bbae0de155a', '11');
INSERT INTO `worker` VALUES (12, '黄文隆', '女', '33', '13800138000', 'nesson@91muban.cn', '广东省广州市海珠区', '广东广播电视中等专业学校', '中专', 4, '党员', NULL, NULL, '61f4910576accddfb75d67899d757cb6acd609ea33c7fb3e20e1aa60f785176b', '12');
INSERT INTO `worker` VALUES (13, '谢彦文', '女', '25', '13800138000', 'nesson@91muban.cn', '东省广州市', '广州市财经职业学校', '中专', 3, '党员', NULL, NULL, 'ec09a0e04d5f146f2cc0d0dd402e2375c65e1488ea69719bc6d8b0a5803898b9', '13');
INSERT INTO `worker` VALUES (14, '傅智翔', '女', '29', '13800138000', 'nesson@91muban.cn', '广东省广州市', '广东第二商业中等专业学校', '中专', 5, '党员', NULL, NULL, 'f24205c6877a684fc1a47e3f71b857b35bd3bca7d622fb61227cd8d1fd638445', '14');
INSERT INTO `worker` VALUES (15, '洪振霞', '女', '26', '13800138000', 'nesson@91muban.cn', '广东省广州市海珠区', '深圳中专学校', '中专', 4, '党员', NULL, NULL, '56df363eb82098241b25ed6acc3cb1fda21ffc128d3f280ea710e11e2f447771', '15');
INSERT INTO `worker` VALUES (16, '刘姿婷', '女', '26', '13800138000', 'liuziting@qq.com', '湖北省武汉市', '武汉大学', '本科', 10, '党员', NULL, NULL, '3350ce26aecb48f62b1288426fc2014f9bef8a508f47b050b31174c059d646ed', '16');
INSERT INTO `worker` VALUES (17, '荣姿康', '女', '26', '13800138000', 'rongzikang@qq.com', '湖北省武汉市', '华中科技大学', '硕士', 11, '党员', NULL, NULL, 'eb26d95f83189e6067120069dcf2b27c958352cfdf26726f2e1479d2d383238a', '17');
INSERT INTO `worker` VALUES (18, '吕致盈', '女', '26', '13800138000', 'nesson@91muban.cn', '湖北省武汉市', '武汉理工大学', '本科', 8, '党员', NULL, NULL, '0d11fd0229cbb6ddf8719cd49c3218947feac4b50b997b62ca2b79255d83aa3a', '18');
INSERT INTO `worker` VALUES (19, '方一强', '女', '24', '13800138000', 'nesson@91muban.cn', '湖北省武汉市', '中南财经政法大学', '硕士', 13, '党员', NULL, NULL, 'e38b01e00bed8ae2f8376a18b13c72dfedb708b0e398c4d4a6817663951466f3', '19');
INSERT INTO `worker` VALUES (20, '黎芸贵', '女', '29', '13800138000', 'service@500d.me', '湖北省武汉市', '华中师范大学', '硕士', 14, '党员', NULL, NULL, 'c60f12373152d415cb8970c8299b6393ea1176a428ce896f185d071b155ea510', '20');
INSERT INTO `worker` VALUES (21, '郑伊雯', '女', '22', '13800138000', 'nesson@91muban.cn', '湖北省武汉市', '管理学院团委学生会', '硕士', 8, '党员', NULL, NULL, 'fd7d2725ca55770728554baf094d0824932fac246bd8ffb4772aa1e5992e6682', '21');
INSERT INTO `worker` VALUES (22, '雷进宝', '女', '23', '13800138000', 'nesson@91muban.cn', '湖北省武汉市', '中国地质大学', '硕士', 9, '党员', NULL, NULL, 'e0a8ba3d84cd36030c5cabc041bbd907728704a5b82d8974c494299e1b32bbbc', '22');
INSERT INTO `worker` VALUES (23, '吴美隆', '女', '32', '13800138000', 'service@500d.me', '湖北省武汉市', '湖南大学', '博士', 6, '党员', NULL, NULL, '85b7dcad2084e872bd69bd093455a853865e8672b1f5769289413671c9f10fd7', '23');
INSERT INTO `worker` VALUES (24, '吴心真', '女', '32', '13800138000', 'service@500d.me', '湖北省武汉市', '中南大学', '硕士', 7, '党员', NULL, NULL, '66e64d17938663dd3f08f92b262e70a756970ff8c71bdfbe87421048421099f7', '24');
INSERT INTO `worker` VALUES (25, '王美珠', '女', '23', '13800138000', 'service@500d.me', '湖北省武汉市', '湖南师范大学', '硕士', 4, '党员', NULL, NULL, 'cabcc19844811e209316498d4cc61b664697464a95ef5e9a8de91fe6833573c1', '25');
INSERT INTO `worker` VALUES (26, '郭芳天', '女', '23', '13800138000', 'service@500d.me', '上海浦东新区', '上海外国语大学', '本科', 6, '党员', NULL, NULL, '10b25a80efa7054a28e63b3ed0dd27d6fdb84cdf77c520127ec21894f7fb65a9', '26');
INSERT INTO `worker` VALUES (27, '李雅惠', '女', '29', '13912341210', 'xianqi@taobao.com', '在湖南省湘西自治州保靖县', '湖南大学', '本科', 8, '党员', NULL, NULL, '023a60ef21887e195cf310f9494f638c29a5b270eef7f1b3d1d08ca4bc6d82ed', '27');
INSERT INTO `worker` VALUES (28, '陈文婷', '女', '24', '13912341210', 'xianqi@taobao.com', '在湖南省湘西自治州保靖县', '东华大学', '本科', 6, '党员', NULL, NULL, 'd68881b8e65e806c03dbd0d1737a828ddb635b39a52d5217b2198cc6d8586ca9', '28');
INSERT INTO `worker` VALUES (29, '曹敏佑', '女', '33', '13212345678', 'caominyou@163.com', '山东', '山东大学', '本科', 6, '党员', NULL, NULL, 'b357b49fbf6fc2bc9593d5b4fbf5c8ef8941471f9a26f4f6d0f400bcde271807', '29');
INSERT INTO `worker` VALUES (30, '王依婷', '女', '23', '13124567890', '12345678@163.com', '上海', '浙江大学', '本科', 0, '党员', NULL, NULL, 'c6f8e87946b5043b1369a0c1ac59f79307eaab26cb6b06bc5f23799d2fc6e59f', '30');
INSERT INTO `worker` VALUES (31, '陈婉璇', '男', '23', '13123456789', '12345678@163.com', '上海', '浙江大学', '硕士', 6, '党员', NULL, NULL, '034d0be1db6d5e52366d64cda4c4952b682c14b3c3940e2c83d42833b570aa16', '31');
INSERT INTO `worker` VALUES (32, '吴美玉', '男', '33', '13912341234', '123456@163.com', '上海', '电子科技大学成都学院', '本科', 6, '党员', NULL, NULL, '8cdea021574b3cbadba9473d7997a158ab6b0bf545719e45281a7b4633177893', '32');
INSERT INTO `worker` VALUES (33, '蔡依婷', '男', '24', '13912345678', 'xianxian@taobao.com', '上海', '北京理工大学', '本科', 8, '党员', NULL, NULL, '5cd3f5332c592278826674e488f91826f67dfd41ed731781d1e4a986fee224f2', '33');
INSERT INTO `worker` VALUES (34, '杨欣宇', '男', '22', '13912345678', 'Hilisyoung@qq.com', '家庭地址', '北京理工大学', '本科', 4, '党员', NULL, NULL, '8d3c7c196dcf6e710a372f2803ca43d1d578de873e6f3daf45da5485b4be144a', '34');
INSERT INTO `worker` VALUES (35, '林家纶', '女', '32', '13912345678', '139123@163.com', '家庭地址', '上海交通大学', '本科', 3, '党员', NULL, NULL, 'a6d5f46a71efcd32d85f68c7bcf5d787773fc94d631e256f9aabcc7a8c043820', '35');
INSERT INTO `worker` VALUES (36, '郑昌梦', '女', '32', '13123456789', '12345678@163.com', '山东', '上海交通大学', '博士', 6, '党员', NULL, NULL, '31f45f41bfbaebf2b85dd864313dea065f5e2e0ef50aa07f58ce91059999be09', '36');
INSERT INTO `worker` VALUES (37, '张瑞群', '女', '27', '12345555', '+(0)12345555-邮箱：CONTACT@YOURDOMAIN.COM', '山东', '上海交通大学', '本科', 2, '党员', NULL, NULL, '9dc6a4dbefe95bc45b20ac75f2502dd9f270ee1d8ad820ca72edd3659a2a31a1', '37');
INSERT INTO `worker` VALUES (38, '洪紫芬', '女', '29', '13800138000', 'nesson@91muban.cn', '广东省广州市海珠区', '北京师范大学', '本科', 8, '党员', NULL, NULL, '2bd45bc46ccd481b1bd90b29021f49f9d47d48bd2362bc108b029a95cc1c0eb0', '38');
INSERT INTO `worker` VALUES (39, '邓家伟', '女', '29', '13500135000', 'service@500d.me', '广东省广州市', '北京师范大学', '本科', 3, '党员', NULL, NULL, 'cdbc61ff0cd3d28535beb3f0fb0d48d027d1a219c8912fce7b4c364a441471da', '39');
INSERT INTO `worker` VALUES (40, '谢佩', '女', '31', '13500135000', 'service@500d.me', '广东省广州市', '中国人民大学-市场营销', '本科', 2, '党员', NULL, NULL, '6579329476106a49ca529921f0a11a860997d82b9fdac46f6d38b8846dddef15', '40');
INSERT INTO `worker` VALUES (41, '任郁文', '女', '26', '13500135000', 'service@500d.me', '广东省广州市', '上海交通大学-市场营销', '硕士', 2, '党员', NULL, NULL, '34fd75bad5daab344f44c182f0801dba4b3957ca6a02146e8b80ec7d1fc64b92', '41');
INSERT INTO `worker` VALUES (42, '李治', '女', '25', '13500135000', 'service@500d.me', '广东省广州市', '同济大学', '本科', 8, '党员', NULL, NULL, 'f10f514a0a3e3a66911969abf69196aac598eb85afd2ee4a8bca6bceeeb5ddc2', '42');
INSERT INTO `worker` VALUES (43, '林石美', '女', '24', '13500135000', 'service@500d.me', '广东省广州市', '同济大学', '本科', 6, '党员', NULL, NULL, '98a8a17177f75a849f2cf332492ba9b48aac3bed483a6337c3a9e5b56356edb2', '43');
INSERT INTO `worker` VALUES (44, '郑雅茜', '女', '29', '13500000000', 'service@500d.me', '广东省广州市', '哈尔滨工业大学', '硕士', 6, '党员', NULL, NULL, '8b6a769b02fe64706a57b7fb9ebed74dc5e860ac16eb98b0746a00b70ea36dd8', '44');
INSERT INTO `worker` VALUES (45, '胡泰', '女', '31', '13500135000', 'service@500d.me', '广东省广州市', '中山大学', '本科', 10, '党员', NULL, NULL, 'b85defc7c5e90552ee62ba9e2ea8273420b66709195a3f1d9fefb9eb03e5d60e', '45');
INSERT INTO `worker` VALUES (46, '陈怡盈', '女', '32', '18800135000', 'service@500d.me', '广东省广州市', '中山大学', '本科', 6, '党员', NULL, NULL, '3c753817971bed22a193f4417f11957a71070d391f491cb89d70eb1ccee5db72', '46');
INSERT INTO `worker` VALUES (47, '石意', '女', '29', '1888888888', 'service@500d.me', '广东省广州市', '上海交通大学职业发展社', '本科', 3, '党员', NULL, NULL, 'b34e11c9514587de4960b445578fb35b275122cc291a104c93bd39448bb03a52', '47');
INSERT INTO `worker` VALUES (48, '林盈威', '女', '30', '18500135000', 'service@500d.me', '广东省广州市', '南开大学', '本科', 4, '党员', NULL, NULL, '01d224f969715e9e7de5124554919d712943cb0bf1a9063fd6d15e6d27a4f607', '48');
INSERT INTO `worker` VALUES (49, '林志嘉', '女', '23', '18500135000', 'service@500d.me', '广东省广州市', '金华职业技术学院职业发展社', '大专', 2, '党员', NULL, NULL, '91b1bac398663d61ed4b691faf0a694b1222d98f6569b9eeb0164ae1a84250d9', '49');
INSERT INTO `worker` VALUES (50, '李秀玲', '女', '32', '18500135000', 'service@500d.me', '广东省广州市', '金华职业技术学院职业发展社', '大专', 5, '党员', NULL, NULL, '2c383557974f32a3fa2e6191160716b35f0a043b6cce4d143590433fda139e16', '50');
INSERT INTO `worker` VALUES (51, '王彦霖', '女', '24', '18500135000', 'service@500d.me', '广东省广州市', '金华职业技术学院职业发展社', '大专', 3, '党员', NULL, NULL, 'd6eb26c1c9b32510d54492d90a4179e9432cc78672976bc90be80705c0324876', '51');
INSERT INTO `worker` VALUES (52, '叶惟芷', '女', '25', '13788886666', 'service@500d.me', '广东省广州市', '中国传媒大学', '本科', 2, '党员', NULL, NULL, '2fc44094011e42377291bc47b07b0b1b6ce59e3bbad0bd76c22d4a10e46c6933', '52');
INSERT INTO `worker` VALUES (53, '郑星钰', '女', '23', '13588888888', 'service@500d.me', '', '中国传媒大学', '大专', 1, '党员', NULL, NULL, '9e50bdcae5d40dbfc8367f21aa0d4fd893a595fc2d740841f06464cb6c3330e3', '53');
INSERT INTO `worker` VALUES (54, '邱贞伟', '女', '24', '13500135000', 'service@500d.me', '', '长沙民政职业技术学院', '大专', 4, '党员', NULL, NULL, '454960758cef0af26d4618e1f946f719d707e9f16e30c7f2e6830b3f21f99f39', '54');
INSERT INTO `worker` VALUES (55, '姚扬云', '女', '29', '18800000000', 'yaoyangyun@qq.con', '', '中山大学', '博士', 8, '党员', NULL, NULL, '0e6ed4c343c9d51e4e7b394c1908256e350622b9f9bc9e22f2cef16567cd40c3', '55');
INSERT INTO `worker` VALUES (56, '涂武盛', '女', '25', '18000000000', 'service@500d.me', '山东德州', '滨州职业学院', '博士', 3, '党员', NULL, NULL, '003cdc2b0f14d5030b0abe032f17937c1844d41585f0dda158271add4fa6a371', '56');
INSERT INTO `worker` VALUES (57, '王雅顺', '女', '33', '13800008888', 'service@500d,me', '广东广州', '江苏建筑职业技术学院', '博士', 5, '党员', NULL, NULL, '4a42ee39df9b55e0ea1b53433d1dc48f7b4df84790414990658bb7aa7586687d', '57');
INSERT INTO `worker` VALUES (58, '唐欣仪', '女', '22', '18888886666', 'service@500d,me', '广东广州', '河北工业职业技术学院', '博士', 8, '党员', NULL, NULL, 'c0e96c2e1f96e437d631d00d339ea376fd6221fe68349b6a09695e5f3bd3a39b', '58');
INSERT INTO `worker` VALUES (59, '陈政圣', '女', '26', '1888008000', 'service@500d.me', '上海市', '中山大学附属第三医院', '大专', 7, '党员', NULL, NULL, 'a7c3583f37134c3ce62cad0c62b028e99ef80c91bad3f5e9918c65f479efa976', '59');
INSERT INTO `worker` VALUES (60, '李淑淑', '女', '25', '18800000000', 'service@500d.me', '上海市', '福建船政交通职业学院', '大专', 0, '党员', NULL, NULL, '414425c8a4e9c9e94a36567c1a07948f7035bc8b5e8dec761aa45a2d8d84f5e2', '60');
INSERT INTO `worker` VALUES (61, '黄莉秋', '女', '31', '18800000000', 'service@500d.me', '上海', '中专', '中专', 5, '党员', NULL, NULL, '7670ab0c13eaa5735c3a502389c8cf17da7329647841aac7af29d423e3ccd88d', '61');
INSERT INTO `worker` VALUES (62, '林雅慧', '女', '27', '13500135000', 'Service@500d.me', '广东省广州市', '广州市轻工职业学校', '中专', 3, '党员', NULL, NULL, 'c576fd3e90a709a83c8aad2cfef7767469b2bcbebed579d31f46eac9de992955', '62');
INSERT INTO `worker` VALUES (63, '陈育福', '女', '24', '0011', 'office@microsoft.com', '广东省广州市', '中专', '中专', 0, '党员', NULL, NULL, '897a6f88f6974f41e6f051fd82f6691538e0d0fc3254293f73bcbabbcb6fbd6a', '63');
INSERT INTO `worker` VALUES (64, '吴惠雯', '女', '26', '13912345678', 'xianxian@taobao.com', '上海', '中专', '中专', 7, '党员', NULL, NULL, '200da8056c22deb36a4f99a08fa32cac90404b4ab2cacc393eb45e61a933e57b', '64');
INSERT INTO `worker` VALUES (65, '詹允坚', '女', '33', '13912345678', 'xianxian@taobao.com', '上海', '中专', '中专', 10, '党员', NULL, NULL, 'f1915b6c23f4cdcd52866179d2a4b98f1cf4b47f03fcc38c1173750f217519e8', '65');
INSERT INTO `worker` VALUES (66, '赖淑珍', '女', '31', '13912345678', 'xianxian@taobao.com', '上海', '中专', '中专', 0, '党员', NULL, NULL, 'd78c9d0632754e6127eadb83132774e9910ef80dfc1f431ab7c5d4b873f850a1', '66');
INSERT INTO `worker` VALUES (67, '李凯婷', '女', '33', '13912345678', '13912@163.com', '上海', '中专', '中专', 4, '党员', NULL, NULL, '7585e156b939d168cd27ca9f86f840b1c11e97fc5d55cd24d07f48432c6f3432', '67');
INSERT INTO `worker` VALUES (68, '林承辰', '女', '29', '135', '123456@.com', '赴山东省图书馆志愿者服务', '济南新技术应用学校', '中专', 8, '团员', NULL, NULL, 'd06145417f955cbe18ce6614916ab63f11b9f44c7b1b4ec9a2fecdbe2874b310', '68');
INSERT INTO `worker` VALUES (69, '刘亭宝', '女', '26', '13999999999', '1234567@123.com', '山东', '中专', '中专', 6, '团员', NULL, NULL, 'af27c66073641e8a9554ee919bd8b941ea62c213c8e150d0b62c038ee9d9ff81', '69');
INSERT INTO `worker` VALUES (70, '宋慧元', '女', '26', '13912345678', 'Yourname@163. com', '山东', '中专', '中专', 13, '团员', NULL, NULL, 'ddd65f04a52d96d51d1c27ec116de689b1a4685f9061b966ab344d34e9f6a8d6', '70');
INSERT INTO `worker` VALUES (71, '赖俊军', '女', '27', '15888888888', '123456@qq.com', '上海宝山', '上海交通大学', '本科', 4, '团员', NULL, NULL, '6873c88c25c4f6879340c6fdc5e2a42b4fbc896ead845f139723291ed392d96c', '71');
INSERT INTO `worker` VALUES (72, '荆彦璋', '女', '29', '13800138080', '123456@qq.com', '山东省日照市', '中国石油大学学生会', '本科', 4, '团员', NULL, NULL, '2def4e4bca185b765f1af875edf6cc315dbbc8572cc4b643ce8aa2c45f31c300', '72');
INSERT INTO `worker` VALUES (73, '白怡均', '女', '26', '1380000020', '4564646@qq.com', '山东省日照市', '中国海洋大学本科', '本科', 8, '团员', NULL, NULL, '331607cedb0a1eef63e38006b6c90ccf8184e083627af322bbd4797c244ef8ea', '73');
INSERT INTO `worker` VALUES (74, '林姿辛', '女', '31', '13500135000', 'linzixing@163.com', '广东省广州市海珠区滨江东路', '上海复旦大学', '本科', 5, '党员', NULL, NULL, '089d9e6f3bb3c18bc07602ba291a14ec67991170b0c0b5197b23dd635d0549ca', '74');
INSERT INTO `worker` VALUES (75, '连书忠', '女', '31', '13700008888', 'service@500d.me', '广东省上海市海珠区滨江东路', '中山大学-本科', '本科', 5, '党员', NULL, NULL, '66e1907eeaee396175967c5b59954455ee20a318028122f91027d581bff17614', '75');
INSERT INTO `worker` VALUES (76, '余仪礼', '女', '30', '18880013500', 'service@500d.me', '广东省广州市', '中山大学-本科', '本科', 6, '党员', NULL, NULL, '2dd3975e083ce52900edb4d21c0936cceaa95c6a648529143ac6484b396befe6', '76');
INSERT INTO `worker` VALUES (77, '袁哲仪', '女', '33', '13700008888', '500d@139.com', '广东省广州市', '南开大学', '本科', 6, '党员', NULL, NULL, '7931301835fb363dce51648d83677b2e344fb0f58d66a40602502144382f397b', '77');
INSERT INTO `worker` VALUES (78, '叶怡财', '女', '26', '18800145000', 'service@500d.me', '广东佛山', '天津大学', '本科', 8, '党员', NULL, NULL, '3381cfa8e1a4ee696727e75f856ed8801663285e6af0b7521e0b93e6f59d2730', '78');
INSERT INTO `worker` VALUES (79, '冯雅筑', '女', '25', '18888888888', 'nesson.com', '广东佛山', '郑州大学', '本科', 8, '党员', NULL, NULL, 'df1973f9ebfdf67f9a69c06972dc6d5f2eee88ce48e204a9b55b89ebdb3c91b3', '79');
INSERT INTO `worker` VALUES (80, '吴惠美', '女', '23', '13912345678', 'you@hotmail.com', '山东', '郑州大学', '本科', 2, '党员', NULL, NULL, 'dda78c7d0085c16aaca7a606a0f38170327c8b05cbc6c0f8e46d4819d92ceb5a', '80');
INSERT INTO `worker` VALUES (81, '何佳慧', '男', '30', '1888888000', 'naisen.com', '上海市', '中国人民大学', '本科', 4, '党员', NULL, NULL, 'da3ba6dec513e60a26461016b871802c12830db60d3f8dad4e61015fb71934a9', '81');
INSERT INTO `worker` VALUES (82, '李伦圣', '男', '30', '1888888000', '12345@docer.com', '家庭住址', '中国人民大学', '本科', 3, '党员', NULL, NULL, '106c6d2a42f4c1994f6f7ea89b03acf22b632d065b952191c71a41abaad316d8', '82');
INSERT INTO `worker` VALUES (83, '彭正仁', '男', '27', '12345678901', '12498118@qq.com', '广东省韶关市', '华中科技大学', '本科', 1, '党员', NULL, NULL, '9b2824480ff8dae9e71a125af65a21abc36bbcb1ea4fff7a9a4a1809217e731d', '83');
INSERT INTO `worker` VALUES (84, '刘小紫', '男', '24', '13800000000', '13800@qq.com', '广东省韶关市', '东南大学院校联络部', '学历', 7, '党员', NULL, NULL, '80f898ee4a11c501e63842ab0a1dad852edba3b2763b7e6de373788e1c739253', '84');
INSERT INTO `worker` VALUES (85, '温燕达', '男', '25', '13988888888', '888888@163.com', '浙江省杭州市滨江区', '苏州大学校园大使', '本科', 3, '党员', NULL, NULL, '2d7443757071b65d4c21f2d6354eb3e8535e613023cce6ba381fd051ed3c2e45', '85');
INSERT INTO `worker` VALUES (86, '刘佳雨', '男', '23', '18091898568', '53555893@qq.com', '浙江省杭州市滨江区', '陕西工业职业技术学院', '本科', 5, '党员', NULL, NULL, '71e66f64d63b424974c2c6d4ac6620d8b3d37b65bded454c1559b47e45b4f530', '86');
INSERT INTO `worker` VALUES (87, '林怡紫', '男', '27', '137397777777', '@healthyyang2', '浙江省杭州市滨江区', '陕西工业职业技术学院', '硕士', 9, '党员', NULL, NULL, '1cfb8cb0046d68caa6be65fb0cc632de0985bb302b80a943deee45c86325370e', '87');
INSERT INTO `worker` VALUES (88, '吴婷婷', '男', '29', '137397777777', '@12345', '住址', '中央财经大学', '硕士', 3, '党员', NULL, NULL, '72d78fe2f1f51f923388ba742ab120121a0efdabe61de9eaa0f06f0980d8cf38', '88');
INSERT INTO `worker` VALUES (89, '杨怡君', '男', '23', '13912345678', 'xianxian@taobao.com', '上海', '北京清华大学', '本科', 3, '党员', NULL, NULL, 'd34f46b376b3bd65ba0ce06e10fc6580fbc76213de1a747bf1dc995f7064d6ae', '89');
INSERT INTO `worker` VALUES (90, '黄康刚', '男', '25', '17345678900', '12345@123.com', '上海', '北京科技大学', '本科', 5, '党员', NULL, NULL, 'dc7c57b7f418dae7c669d4ea46a137329bbd67eb2a6152a28fba9401d1c4e4bf', '90');
INSERT INTO `worker` VALUES (91, '林辰', '男', '24', '13910345678', 'yourname@163.cm', '上海', '西安电子科技大学', '本科', 9, '党员', NULL, NULL, '5f2ba67950392a6504ea86eea259c29df2c5b3875be19ba8bc9a77757cb50a73', '91');
INSERT INTO `worker` VALUES (92, '沈慧美', '男', '24', '13912220080', 'myemail@163.com', '上海', '上海海洋大学', '本科', 6, '党员', NULL, NULL, '3340eaf8bfd2c8ff8185ec2da3815d006dff62d902a2b86427636921432db648', '92');
INSERT INTO `worker` VALUES (93, '吴佩霖', '男', '27', '13912220080', 'yourname@163.com', '湖南', '湖南中医药大学', '本科', 0, '党员', NULL, NULL, 'd0b867eefb7373d99727ab3b59f93bf865f7e024c89a29a6c4bf5635324d49de', '93');
INSERT INTO `worker` VALUES (94, '张伟杰', '男', '23', '15031019999', '123456qq.com', '湖南', '湖南中医药大学', '硕士', 4, '党员', NULL, NULL, '6184698a85227d814c46cb5ccb0035fddb2d79785dec4ff00b571020780221af', '94');
INSERT INTO `worker` VALUES (95, '刘友淳', '男', '25', '15031019999', '22448900@qq.com', '湖南', '东城区第三中学分校', '本科', 6, '党员', NULL, NULL, '6931c3041778503e9c69fefd6dcb9a25782ee5364062c0980a04231ec880cdfe', '95');
INSERT INTO `worker` VALUES (96, '套背景', '女', '30', '电话/18010001000', '微博/@微软Office PLUS', '籍贯/北京', '东城区第三中学分校', '本科', 5, '党员', NULL, NULL, '50c7abce4c99adda796397dcfc400ae316b2003605e9b54fd0373c497db53453', '96');
INSERT INTO `worker` VALUES (97, '潘孝东', '女', '29', '13899999999', 'xiaohen@189.com', '籍贯/北京', '中央戏曲学院', '本科', 10, '团员', NULL, NULL, 'c861c6013eb1bb4c7e2d67171a5fa4f7396b97397b6d47ec8421186cea055f8a', '97');
INSERT INTO `worker` VALUES (98, '周志合', '女', '24', '1350013500', 'service@163.com', '广东省广州市', '深圳大学', '本科', 3, '团员', NULL, NULL, '566f54d3e2f41de0c81d8627c0e04700724babc331605460ce151927aaafc634', '98');
INSERT INTO `worker` VALUES (99, '刘力霞', '男', '23', '1350013500', 'eplus@micros', '籍贯北京', '深圳大学', '本科', 2, '团员', NULL, NULL, '194a2d5618f3dfbaa668cd08bc351fb0ae66028c80836ee4df2870da1feeebe7', '99');
INSERT INTO `worker` VALUES (100, '林钰婷', '男', '27', '联系各大媒体对新闻事件的集中报道；', 'zxj2015@gmail.com', '籍贯北京', '北京师范大学', '本科', 8, '团员', NULL, NULL, '8d8f750b24597e4629529cff1bcdb013a6b822100b6e4a5b3542fd0b255a0b7d', '100');
INSERT INTO `worker` VALUES (101, '蔡于纬', '男', '23', '13511223344', 'service@500d.me', '广东省广州市', '高中', '本科', 0, '团员', NULL, NULL, '677ddf8107c5e3b406df33a6ef82e62983bbce299e4daed64c20b570f7807c35', '101');
INSERT INTO `worker` VALUES (102, '林俊凯', '男', '25', '13500135000', 'shixi@shixiseng.com', '广东省广州市', '高中', '本科', 5, '团员', NULL, NULL, 'b353b05b31bf6940fae3d93e35006abf3803536ddb5cd80b9079739c55fe0222', '102');
INSERT INTO `worker` VALUES (103, '蔡雅惠', '男', '26', '13912345678', 'Caiyahui@123.com', '山东', '高中', '高中', 6, '团员', NULL, NULL, 'e48e7374af5ba03b087a7adf08c6225f630fb09b04bd53bd4a0069a028aabbc0', '103');
INSERT INTO `worker` VALUES (104, '汪喜祥', '男', '31', '13800138000', '224438888@qq.com', '广东省广州市', '高中', '高中', 11, '团员', NULL, NULL, 'fe552df763f2ad6dd7b9533aa5c67078dbf86c47c29510d7c0a9d72692d31bb0', '104');
INSERT INTO `worker` VALUES (105, '陈铭', '女', '33', '18122334455', 'Chenming@qq.com', '广东省广州市', '兰州交通大学', '本科', 12, '团员', NULL, NULL, 'bf0de69199feef3d7ed45d67378f7a1014dab0c6a17e0ce87664ae5ee37f082b', '105');
INSERT INTO `worker` VALUES (106, '郭子珠', '女', '30', '熟练运用 Microsoft Office (ppt/excel/word)办公软件、 Premiere、 Photoshop等专业视', 'Chenming@qq.com', '辽宁省辽阳市民政局', '人民公安大学学生会', '本科', 7, '团员', NULL, NULL, 'd111801c8322d587b9fe856a2852dbacb1b4f9f069abc441a09ae368730245d9', '106');
INSERT INTO `worker` VALUES (107, '许伦吉', '女', '23', '1308310002', '456481343@qq.com', '广东省广州市', '人民公安大学学生会', '本科', 5, '团员', NULL, NULL, 'ad7d42cd205f247ba6906a2b0fbd7f3b75ea6d268e0da0e6610292d1bcef839b', '107');
INSERT INTO `worker` VALUES (108, '陈佳雨', '女', '30', '>负责手机客户端产品GUI的整体风格设计，应用工具的相关菜单', '24546326@163.com', '湖南省长沙市', '怀化职业技术学院艺术设计', '大专', 7, '团员', NULL, NULL, 'b5615653b37b52b773269cb39af7c64d1e5073cfa5c3047695f6bb06cdcf64ff', '108');
INSERT INTO `worker` VALUES (109, '赖英贤', '女', '26', '>负责手机客户端产品GUI的整体风格设计，应用工具的相关菜单', 'office@microsoft.com/箱', '湖南省长沙市', '怀化职业技术学院艺术设计', '硕士', 2, '团员', NULL, NULL, 'a128444f1ae56b1475e48395dc5512e3c756a8a46a03cdc8f61ff536ca67def3', '109');
INSERT INTO `worker` VALUES (110, '吴嘉茹', '女', '23', '13912345678', 'wujiaru@123.com', '湖南省长沙市', '高中', '硕士', 3, '团员', NULL, NULL, '5a383e344289bc3064415d8d99d4739546af7c4fafbbf6c241b16efdd959a606', '110');
INSERT INTO `worker` VALUES (111, '陈永桂', '女', '29', '13700008888', '3254465@qq.com', '湖南省长沙市', '高中', '本科', 7, '团员', NULL, NULL, '15cbc0b377c823aabd2b3283683a9de18dc108dad1397b3ef46bc1b8bbfaef86', '111');
INSERT INTO `worker` VALUES (112, '张裕忠', '女', '31', '15966583333', 'dafs@qq.com', '广东省广州市', '华南科技大学市场营销本科', '本科', 8, '团员', NULL, NULL, 'b1fc34b970af2ffa814c4b0c2f5783f491d5b6c0b55c1e7dad9a06fe6224a870', '112');
INSERT INTO `worker` VALUES (113, '石春紫', '女', '23', '电话/18010001000', '箱/officeplus@microsoft.com', '籍贯/北京', '北京联合大学', '学历', 7, '团员', NULL, NULL, '028147440c52655f93c9183c5bc1bb6759d8970a003de250167952cb5416815f', '113');
INSERT INTO `worker` VALUES (114, '方美君', '女', '31', '13500135000', 'Service@500d.me', '广东省广州市', '中国传媒大学MBA', '硕士', 8, '团员', NULL, NULL, '61b310b6e4dddf93f64908432fb44c92b95733bde3ab7c06004a75d43a8e3951', '114');
INSERT INTO `worker` VALUES (115, '潘右博', '女', '26', '13500135000', 'panyoubo@qq.com', '上海', '北京工业大学', '本科', 0, '团员', NULL, NULL, 'ff1da58b73a23e62f715c2b1fbdcb857453c5971291022000623b9d8c4a9e0ff', '115');
INSERT INTO `worker` VALUES (116, '俞星如', '女', '27', '18686660000', '186866@qq.com', '上海', '厦门大学-硕士', '硕士', 3, '团员', NULL, NULL, '7c5077ff71b0119fe0d8e0e11b6ac6963130fa04c98d522ff56702f0770852c5', '116');
INSERT INTO `worker` VALUES (117, '张冠杰', '女', '32', '18123456789', 'office@microsoft.com', '上海', '厦门大学-硕士', '本科', 5, '团员', NULL, NULL, '1813ee0458f26e49de01488b88f0610fe234c0264712f9cd521c27e69134f2c9', '117');
INSERT INTO `worker` VALUES (118, '钟庭玮', '女', '25', '18123456789', ' office@microsoft.com', '上海', '厦门大学-硕士', '本科', 0, '团员', NULL, NULL, '6bfa6fba0e412f81f8ed5fa4f3092741159c5968e959aa8752e050ea7032cbba', '118');
INSERT INTO `worker` VALUES (119, '叶茜', '女', '27', '13500000000', 'Yeqian@163.com', '上海', '北京师范大学', '本科', 4, '团员', NULL, NULL, '8107294d25aa186e131bddce01e045971423b65b3c03c557f966800e49093ec3', '119');
INSERT INTO `worker` VALUES (120, '陈伯薇', '女', '32', '15031088898', 'chenbowei@qq.com', '北京', '中国科学院大学', '本科', 9, '团员', NULL, NULL, 'abcb39da17332642fe0cf8b8f7d3ed4f2a8ccc49f394945ec48c9086edd4f00c', '120');
INSERT INTO `worker` VALUES (121, '陈昭祥', '女', '30', '131415161', '151515@126.com', '北京', '湖北工业大学学生会', '校级三好学生、系级三好学生、优秀学生干部、优秀主持人', 6, '团员', NULL, NULL, '0a7f610c8587a0ae75d2c307cd99041a8cdf621243d9284d3e6558149d8a0dc3', '121');
INSERT INTO `worker` VALUES (122, '陈伟伦', '女', '30', '13888888888', 'service@500d.me', '广东省广州市', '中南林业科技大学', '校级三好学生、系级三好学生、优秀学生干部、优秀主持人', 8, '团员', NULL, NULL, 'f5df426095448db1bd37ff8ef09ba74a212e2e6abb695831977b5dc302fc3a90', '122');
INSERT INTO `worker` VALUES (123, '黄雅慧', '女', '24', '13500135000', 'service@d.me', '广东省广州市', '淮南师范学院', '本科', 3, '团员', NULL, NULL, 'e1f0577f5ccdfe8ccc502bd8da3c3a4d0383c2b6f9cb56f4e8b81125a43bc971', '123');
INSERT INTO `worker` VALUES (124, '郭子豪', '女', '28', '18088888088', 'Zyq1998@163.com', '广东省广州市', '南京师范大学', '本科', 2, '团员', NULL, NULL, '662fe12742e7c36ad4482a03573ee514c1951cff497d01050cc8ecc326727e1e', '124');
INSERT INTO `worker` VALUES (125, '黄彦霖', '女', '31', '13656547899', '123456789@qq.com', '上海市静安区', '秦皇岛外国语大学', '大专', 5, '团员', NULL, NULL, '6b9038bac7ef4a18d0e9c619b9c4f09cdf0b36a1892158a0400621a05b8f7fb5', '125');
INSERT INTO `worker` VALUES (126, '宋合', '女', '27', '15812344321', 'songhe@qq.com', '广州', '广州白云学院', '大专', 6, '团员', NULL, NULL, '6d3fe746e6a58525e4f625b9e43d5dd7cbd7da058d3415e26bf57c157a5a0522', '126');
INSERT INTO `worker` VALUES (127, '许雅婷', '女', '29', '15000000000', '458434@qq.com', '广州', '宁波工程学院', '本科', 10, '团员', NULL, NULL, 'ac54f3ba788be37d331072e956bad23f256f0c84db03387597f48c60f7123382', '127');
INSERT INTO `worker` VALUES (128, '王圣如', '女', '30', '13800000000', '235664@qq.com', '浙江省台州市黄岩新前卫生院', '广州医科大学', '本科', 6, '党员', NULL, NULL, '886a77fbb45ae946985af98d1668fb70927ac984289e5c342bea3b318102c08c', '128');
INSERT INTO `worker` VALUES (129, '何伶元', '女', '29', '15800000000', 'halingyuan@qq.com', '浙江省台州市黄岩新前卫生院', '武汉大学', '文学学士', 6, '党员', NULL, NULL, '4cd460a81d4de3706d0ce5a8670f425f52df589357fb1477498d0c9b328e724d', '129');
INSERT INTO `worker` VALUES (130, '钟伦军', '女', '31', '13800000800', '1380454@qq.com', '浙江省台州市黄岩新前卫生院', '浙江大学', '文学学士', 5, '党员', NULL, NULL, '7fa5de4930d46ed93513f4ac132c200f304fa9446a38995119618aac76609745', '130');
INSERT INTO `worker` VALUES (131, '蔡佳蓉', '女', '31', '13588888888', 'caijiarong@qq.com', '广东广州', '汕头大学本科', '本科', 8, '党员', NULL, NULL, 'c4b27be6548572dd7ec98fa1968e5352289390fc08aa1f7c72e7cd114d364b05', '131');
INSERT INTO `worker` VALUES (132, '薄康柔', '女', '26', '13000000000', '5464654@qq.com', '广东广州', '南昌大学艺术设计本科', '本科', 4, '党员', NULL, NULL, 'd1fdaba82e3b44a57c633672df430823bd404b5cd71f989d0713f3af7e7dd563', '132');
INSERT INTO `worker` VALUES (133, '冯成轩', '女', '31', '13000000000', '5464654@qq.com', '现居地址', '合肥工业大学', '本科', 10, '团员', NULL, NULL, 'a99afd89765ba8118e6814a76e0035817091e739a38916a28e427060439533bd', '133');
INSERT INTO `worker` VALUES (134, '高成彦', '女', '28', '13500000000', 'zxj2015@gmai.com', '地址', '北京师范大学本科', '本科', 5, '团员', NULL, NULL, '62ef6cffecb0261b8f3a196002609a6a0a1311f7102fd8eafb09826a2f3bb4f5', '134');
INSERT INTO `worker` VALUES (135, '徐采伶', '女', '27', '13500135000', 'service@500d.me', '广东省广州市', '华南科技大学', '本科', 8, '团员', NULL, NULL, '5447563b205dacda3048220459635809cc17505bf8deae3e7cd4bc413f320332', '135');
INSERT INTO `worker` VALUES (136, '杨雪', '女', '31', '15031088888', '123456@qq.com', '北京', '北京协和医学院', '本科', 7, '团员', NULL, NULL, '152cbdedbf882cec8b4427871e2c28c8e9188d32d5cf1b35c3bba8024152b72d', '136');
INSERT INTO `worker` VALUES (137, '林彦韦', '女', '29', '15886888688', '123456@qq.com', '北京', '清华大学大学夏令营', '本科', 5, '党员', NULL, NULL, '422eb835b4510bf3de1b62bbc8c84f65674815bf4cc175e1856767456dae7821', '137');
INSERT INTO `worker` VALUES (138, '李毓', '女', '24', '13800138000', '123456@qq.com', '广东省广州市', '清华大学大学夏令营', '本科', 8, '党员', NULL, NULL, '4b8229028ff866ee2c6917b8d49e746bc8ca08d2e7afe4a763be591abd65949d', '138');
INSERT INTO `worker` VALUES (139, '邱宜瑶', '女', '28', '13800138000', 'office@microsoft.com', '广东省广州市', '清华大学大学夏令营', '本科', 0, '党员', NULL, NULL, 'b4509514317bfdf6e156b78244cab7b7c404a7fd5308309f2d099ec933aaccab', '139');
INSERT INTO `worker` VALUES (140, '陈政文', '女', '26', '13800138000', 'me@shixiseng.com', '北京', '清华大学大学夏令营', '本科', 10, '团员', NULL, NULL, '71af0aba632c4f9ab3f25bdd9e3f0ef8e43d91f6c9eef93b9cd459139a1b84ce', '140');
INSERT INTO `worker` VALUES (141, '李宜豪', '女', '31', '18600000000', '1051566620@qq.com', '北京', '上海财经大学', '本科', 9, '团员', NULL, NULL, 'b9500db311dc17e6b3dced2ebfc569a26ec54da0215724cd4e35332ca6f6704b', '141');
INSERT INTO `worker` VALUES (142, '陈宜宁', '女', '25', '18010001000', '@微软', '北京', '北京工商大学', '本科', 8, '团员', NULL, NULL, '3443a66069deb78920be164c390bea27aa0fcd606e5484431dacea2dc49fe873', '142');
INSERT INTO `worker` VALUES (143, '陈志宏', '男', '23', '13103456789', '131234@163.com', '北京', '北京建筑大学', '本科', 8, '党员', NULL, NULL, '37387368900fdc6f42847d31a841f796fa8adb846b58cba925da0168d479a17c', '143');
INSERT INTO `worker` VALUES (144, '阮柔治', '男', '27', '15031019999', '邮寄杂志，并邮件告知会员杂志已寄出，随时记录并采纳会员们的反馈意见', '江苏省传媒艺术研究会', '公共管理学院', '硕士', 7, '党员', NULL, NULL, 'e8e3edde52ca450636c761bc1c8f77d7c149f4b538731c803666c91b937ccb39', '144');
INSERT INTO `worker` VALUES (145, '林乐', '男', '32', '15031019999', 'linle@qq.com', '江苏省传媒艺术研究会', '公共管理学院', '本科', 4, '党员', NULL, NULL, 'ec76cfbfef593cfa9a0d94273ef0a2f77ce1a3146ed9f9fca086c395d9d4016e', '145');
INSERT INTO `worker` VALUES (146, '简健昀', '男', '24', '15031088888', '123456@qq.com', '北京', '公共管理学院', '本科', 7, '党员', NULL, NULL, '78358335787d4bbdaec962006a8c0e4c44984470dc73de930a6774b9f1c1f852', '146');
INSERT INTO `worker` VALUES (147, '廖雅君', '男', '30', '15031088888', 'service@500d.mme', '上海', '苏州大学', '学士学位', 5, '党员', NULL, NULL, 'ae0dc41d52a3188d18274e6318a6ed81db4c27fbe2d870f348dc44f26ebe468c', '147');
INSERT INTO `worker` VALUES (148, '梁佩芬', '男', '28', '18071404', '909096@qq.com', '湖南', '长沙理工大学', '学士学位', 4, '党员', NULL, NULL, 'f56160f00597db5f0702f406effc8c697b5773a2f19ba9364108ea4e1fc568a9', '148');
INSERT INTO `worker` VALUES (149, '苏玮伦', '男', '24', '城警察》电视专题栏目及负责联系各大媒体对新闻事件的集中报道；', 'suweilun@qq.com', '湖南', '湖南师范大学', '本科', 12, '党员', NULL, NULL, '68d463c0bedb16c1cca9f1962a27fc23bb3a0bd4d1bb664fdf00d90e2d9da1c3', '149');
INSERT INTO `worker` VALUES (150, '秦娇真', '男', '25', '13888888888', 'service@500d.me', '湖北省武汉市', '湖北经济学院-本科', '本科', 8, '党员', NULL, NULL, '8bdd88baec0ceedf04eae885edf7be360e5a475e3ea64a8187a140eb51010837', '150');
INSERT INTO `worker` VALUES (151, '李仁杰', '男', '31', '13888888888', 'lirenjie@qq.com', '', '北京市清华大学', '本科', 8, '团员', NULL, NULL, 'e8ad989b6b60bb473a0d75c0d8b6735a7e87c8ec0511f64d4028ede1540e2e30', '151');
INSERT INTO `worker` VALUES (152, '谢佳雯', '男', '30', '13888888888', 'Youremail@gmail.com', '籍贯', '山东建筑大学', '本科', 12, '团员', NULL, NULL, '118230d8b2480d3fddc860e023564b6194eb5b1222580174708b729e0a95290d', '152');
INSERT INTO `worker` VALUES (153, '李佳', '男', '23', '13888888888', '123456789@qq.com', '山东烟台', '山东理工大学', '本科', 5, '党员', NULL, NULL, '0c6c04018cd897032d9a35a0c2457f68ee1e844048f860df5814206c4c73ade9', '153');
INSERT INTO `worker` VALUES (154, '郭贤青', '男', '31', '13888888888', '45325578@qq.com', '', '暨南大学', '本科', 6, '党员', NULL, NULL, '10de88e6b94e7da6f0bfbe8effb77796b746b4cfb4c319e7db8c08492cc75dc2', '154');
INSERT INTO `worker` VALUES (155, '吴怡伶', '男', '28', '配合每期公益电影活动的宣传，并负责联系场地策划电影展；', 'zhangxiaojie@gmail.com', '', '北京师范大学', '本科', 7, '党员', NULL, NULL, '9a47c8ee2a6b3745199b7240a60bef8e40c46a51f0043c65d483cc4a4b25f4b0', '155');
INSERT INTO `worker` VALUES (156, '陈怡婷', '男', '23', '配合每期公益电影活动的宣传，并负责联系场地策划电影展；', 'zhangxiaojie@gmail.com', '广东省广州市', '英国爱丁堡大学', '硕士', 7, '党员', NULL, NULL, '1518f8152d54289c5507d037724adfed98fb14fd0acc05b831f1ef654b75de02', '156');
INSERT INTO `worker` VALUES (157, '阮晴桦', '女', '32', '配合每期公益电影活动的宣传，并负责联系场地策划电影展；', 'xiaochen@qq.com', '河北省唐山市古冶区', '浙江传媒学院', '本科', 4, '团员', NULL, NULL, '5fc0d4de66d1c71c1da867f92b327a76089e4382c29b7192f1ff990fa10ec7c9', '157');
INSERT INTO `worker` VALUES (158, '林孟富', '女', '31', '配合每期公益电影活动的宣传，并负责联系场地策划电影展；', 'viv2010@163.com', '河北省唐山市古冶区', '中央民族大学', '本科', 5, '团员', NULL, NULL, '64a58069aca69e5aab3ef67fab030e9bfb2c2ef628c0a06a3d2e215cd53424d8', '158');
INSERT INTO `worker` VALUES (159, '刘美', '女', '23', '18888888808', '868898999@qq.com', '河北省唐山市古冶区', '大学应用英语A1级', '本科', 3, '团员', NULL, NULL, '043fa87896051a6f9b73172cb41cc7258f1221d4e4d382b6e16bcb5fedfd1341', '159');
INSERT INTO `worker` VALUES (160, '金蝶', '女', '30', '18888888808', '123456789@qq.com', '浙江省', '中国美术学院', '大专', 4, '党员', NULL, NULL, 'cf3972dd95a455961414a1917efa50947d21f2a55bc664c780ecc1e916ad893f', '160');
INSERT INTO `worker` VALUES (161, '白凯修', '女', '24', '12345678900', '**@163.com', '浙江省', '高级中学教师资格证', '本科', 9, '党员', NULL, NULL, 'a4f42aa5dfa75ac346e282d6ac4c4c1139a4a7012cd1fe2d95c0d508f63152a8', '161');
INSERT INTO `worker` VALUES (162, '黄蓉芳', '女', '25', '13808138036', 'huangrongfang@qq.com', '广东省广州市海珠区', '阳江职业学院', '大专', 9, '党员', NULL, NULL, '150176d3ce522e1b5da29272bca5918dafa5041b69df286f1fdfa394dd62e691', '162');
INSERT INTO `worker` VALUES (163, '赵吟琪', '女', '30', '13800138000', 'zhaoyinqi@qq.com', '广东省广州市海珠区', '沧州工贸学校', '中专', 4, '党员', NULL, NULL, 'ee236a0643dc9c329a9b78d43220058cb2a002b909cefde92959499e26f53862', '163');
INSERT INTO `worker` VALUES (164, '陈嘉惠', '女', '30', '13588888888', 'service@500d.me', '深圳', '深圳职业学院', '大专', 3, '党员', NULL, NULL, 'e3b4c3ff1425c9a3d4d5505029053492651eee32e02fad5095b3d68462aa7c90', '164');
INSERT INTO `worker` VALUES (165, '吴惠劲', '女', '27', '1888008000', 'service@500d.me', '上海市', '中山大学附属第三医院', '大专', 7, '党员', NULL, NULL, 'ae9677f498f9a43ef6931e9e298df291105effb9a473e0f177f70f0630a0e453', '165');
INSERT INTO `worker` VALUES (166, '谢健铭', '女', '27', '13800008888', 'service@500d,me', '广东广州', '江苏建筑职业技术学院', '大专', 9, '党员', NULL, NULL, '78de55326fe0ccf304527692714307bed0d513f2ea5661f366610a996ddf564c', '166');
INSERT INTO `worker` VALUES (167, '林怡婷', '女', '24', '13822138221', 'xiazhihao@qq.com', '广东省广州市海珠区', '广东邮电职业技术学院', '大专', 5, '党员', NULL, NULL, '53193ab97c12d9dcf18dddb30753c49f2be73d256d8e2b93265ef2f312e873da', '167');
INSERT INTO `worker` VALUES (168, '廖佳蓉', '女', '30', '13823138023', 'nesson@91muban.cn', '广东省广州市海珠区', '广东建设职业技术学院', '大专', 10, '党员', NULL, NULL, 'c61582fb965599749a387715adb7f9856b416286b5536b8cfe3de19a39cf0616', '168');
INSERT INTO `worker` VALUES (169, '李佩', '女', '31', '188888000', 'service@500d.me', '上海市', '清远职业技术学院', '大专', 9, '党员', NULL, NULL, 'ea7c09b73becf5b404ac73b5121096050035eadd4a47d3f385f8abbd08ec278b', '169');
INSERT INTO `worker` VALUES (170, '何甄', '女', '30', '188888000', 'service@500d.me', '上海', '中专', '中专', 5, '党员', NULL, NULL, 'b57cfe661bc9295dd95b7315f3ed1d21c45ce57c72e46b19bc976b6bdad1e3fa', '170');
INSERT INTO `worker` VALUES (171, '谢晓玲', '女', '28', '0011', 'office@microsoft.com', '上海', '中专', '中专', 0, '党员', NULL, NULL, '59917e2620770eb85c197723001bac915fa32776b72f56d840f047195ebcb9e9', '171');
INSERT INTO `worker` VALUES (172, '李礼娇', '女', '23', '13122345678', 'lilijiao@qq.com', '广东省广州市', '中专', '本科', 7, '党员', NULL, NULL, 'f26e4198d82d329918563ecae1f7a202d4caac466f750755a5080bfe8b70c307', '172');
INSERT INTO `worker` VALUES (173, '沈阳市', '女', '26', '13111234455', 'liyixiao@qq.com', '上海', '中专', '本科', 7, '党员', NULL, NULL, '2427805ec32cc8b8c9f1c43caaa160841279abec6e739a1d0dffc4f0c965b8a4', '173');
INSERT INTO `worker` VALUES (174, '黄静雯', '女', '28', '13112344321', 'hjw@qq.com', '上海市浦东新区', '上海财经大学', '本科', 11, '党员', NULL, NULL, '756eda6b36bcc33c12a0002e7c01e418433b408edee3df35e219c361857190bc', '174');
INSERT INTO `worker` VALUES (175, '陈淳宝', '女', '25', '13522334567', 'chenchunbao@qq.com', '上海市浦东新区', '上海财经大学', '本科', 0, '党员', NULL, NULL, 'bf84a5d4ed412566fed04f2ffeceb29f9fd709ecd3d1c3336a07849ce7a4f668', '175');
INSERT INTO `worker` VALUES (176, '李文育', '女', '23', '13112344321', 'liwenyu@qq.com', '广东省广州市', '湖北工业大学', '本科', 6, '党员', NULL, NULL, 'd7cd715f7ce6f156ed1e0b0508c506a7c5622aa59d1112227f77d77322bcf80e', '176');
INSERT INTO `worker` VALUES (177, '林佳蓉', '女', '24', '', 'linjiarong@qq. com', '广东省广州市', '上海南湖职业技术学院', '大专', 7, '党员', NULL, NULL, 'f71f99d765e73827b9ed8a6a7c76e739e2b0857ed19c60c4cbdf7d5d110a8406', '177');
INSERT INTO `worker` VALUES (178, '罗依茂', '女', '23', '13112233445', 'luoyimao@qq.com', '上海市浦东新区', '苏州工艺美术职业技术学院', '大专', 12, '党员', NULL, NULL, '60bd12e0e1d71fca1e16127b48e9809b9da4ca5d901c52d141f3168ee034d19e', '178');
INSERT INTO `worker` VALUES (179, '李淑佩', '女', '28', '2', 'luoyimao@qq.com', '上海市浦东新区', '无锡职业技术学院', '中专', 9, '党员', NULL, NULL, 'a695fbb80be1a2fd8f07ac10046df78af8437f45bbbacc1b954b5927c1d52292', '179');
INSERT INTO `worker` VALUES (180, '谢怡君', '女', '29', '通过网络及电话咨询并收集各行各业的潜在商户信息，并分析其合作潜力，协助部门经', 'luoyimao@qq.com', '上海市浦东新区', '北京大学', '本科', 8, '党员', NULL, NULL, '7f61465b356e8b8c90c3ae73c029da7d3502286c3ff14b85717bbcacb25cff74', '180');
INSERT INTO `worker` VALUES (181, '王美玲', '女', '30', '13500135000', 'wangmeiling@qq.com', '广东省广州市海珠区滨江东路', '上海复旦大学', '本科', 10, '党员', NULL, NULL, '823d5851c60aad929a0c72fcb75be1c107cd297aa99b7d0bfc70c7b97b94ab34', '181');
INSERT INTO `worker` VALUES (182, '黄慧学', '女', '28', '15123456789', 'huanghuiyu@qq.com', '广东深圳', '清华大学', '硕士', 4, '党员', NULL, NULL, 'f21f0e28335083eab9cb416a458ac32ffe4c5a067a8cee9dc3c1b971a2083da7', '182');
INSERT INTO `worker` VALUES (183, '邓幸韵', '女', '28', '13800138080', 'dengxingyun@qq.com', '广东省广州市', '西南大学', '本科', 4, '团员', NULL, NULL, '1d3da0402fc4ffb2ea7add5530c325d6fbb8914a259051a48488bfd085fbe028', '183');
INSERT INTO `worker` VALUES (184, '陈秀', '女', '30', '13800138000', 'Chenxiu@163.com', '广东省广州市', '北京师范大学', '本科', 13, '团员', NULL, NULL, 'bb0ca41ea945cadd94d43a1b047188af2ab4b7312c37dc9fa500d26c3d9d3140', '184');
INSERT INTO `worker` VALUES (185, '许平', '女', '30', '13500135000', 'Service@500d.me', '广东省广州市', '广东金融学院', '本科', 8, '团员', NULL, NULL, '7ca9bb9ebccdf0971c1dc61b3bb28a96cefbe44148124e4c9bb2c153f258a68c', '185');
INSERT INTO `worker` VALUES (186, '许爱礼', '女', '23', '13111223344', 'xuaili@qq.com', '上海市浦东新区', '上海工艺美术职业学院', '大专', 9, '团员', NULL, NULL, '7b84d7093033fd02dcf39d424c9f68329a783821c40fb41e3e3966eafaadde19', '186');
INSERT INTO `worker` VALUES (187, '谢一忠', '男', '29', '13888888888', '888pic.com', '上海', '北京大学', '大专', 9, '团员', NULL, NULL, '9a4d5f077567858b9fd6b1fa974ac764c988fe390dff97c5e46feecbee93a95d', '187');
INSERT INTO `worker` VALUES (188, '简志雪', '男', '25', '13112344567', 'jianzhixue@qq.com', '上海市浦东新区', '上海南湖职业技术学院', '大专', 7, '团员', NULL, NULL, 'feb658b045fb71d2741b93b9f9bac95d35e6820e224d5147e430aaf3fa41ae78', '188');
INSERT INTO `worker` VALUES (189, '赵若喜', '女', '25', '1308310002', '456481343@qq.com', '广东省广州市', '上海南湖职业技术学院', '本科', 5, '团员', NULL, NULL, '98345f475502188f7cc227722d5942db5d40b7a8d3171027d67b5aa1bc27418d', '189');
INSERT INTO `worker` VALUES (190, '许承翰', '女', '33', '>负责手机客户端产品GUI的整体风格设计，应用工具的相关菜单', '24546326@163.com', '湖南省长沙市', '上海南湖职业技术学院', '大专', 7, '团员', NULL, NULL, '589f5fe8ce01d26d59ec59a02db0c25ebf4c8c05b7f9c415cebf33fb55f8ca26', '190');
INSERT INTO `worker` VALUES (191, '姚哲维', '女', '35', '18800135000', '24546326@163.com', '广东省广州市', '上海南湖职业技术学院', '本科', 7, '团员', NULL, NULL, '6b2cd6e159ae4a15fd4fd06be4c14318208a7ed00138b39e45dbc6ecab21d30a', '191');
INSERT INTO `worker` VALUES (192, '苏俊安', '女', '28', '18800135000', '24546326@163.com', '广东省广州市', '广州番禺职业技术学院', '大专', 4, '团员', NULL, NULL, '656f89dc17a2e0913c4e8e62bf3f4cb8c56019e8ddf7bf2c3b4fccb82d2c5946', '192');
INSERT INTO `worker` VALUES (193, '郭礼钰', '女', '28', '13588888888', 'service@500d.me', '江西省南昌市', '广州番禺职业技术学院', '大专', 5, '党员', NULL, NULL, '77b70f440bbc7ec872ea8e87ba9223bc2f5319b4d77e090a86101280d57a7eca', '193');
INSERT INTO `worker` VALUES (194, '姜佩珊', '女', '25', '13500135000', 'Service@500d.me', '广东省广州市', '广州市信息技术职业学校', '中专', 3, '党员', NULL, NULL, 'f485e7fe431d1e65b02c50ef20df4c8f704afeea0fbc068bc0098e7bb2fae91f', '194');
INSERT INTO `worker` VALUES (195, '张鸿信', '女', '25', '13912345678', '13912@163.com', '北京', '中专', '中专', 4, '党员', NULL, NULL, 'aa240e34de3efc2acf09db42f9f3b696c468f7a30d7ea8d95fd86e81d8fb0232', '195');
INSERT INTO `worker` VALUES (196, '秦欣瑜', '女', '26', '13912345678', '13912@163.com', '北京', '中山大学', '博士', 15, '党员', NULL, NULL, '5227109e1e679ca267c390216fe3ebdce80f11cbe2b4f44ec44c8238243461d8', '196');
INSERT INTO `worker` VALUES (197, '李旺劲', '女', '24', '13512344321', 'liwangjing@qq.com', '赴江苏省图书馆志愿者服务', '上海燎原中等专业学校', '中专', 9, '团员', NULL, NULL, '07bf99bf820976fb68635d3277b4bae4cd10863fd76384efe117fa8b19f75eab', '197');
INSERT INTO `worker` VALUES (198, '吴惠美', '女', '28', '13912345678', 'you@hotmail.com', '山东', '上海燎原中等专业学校', '本科', 2, '团员', NULL, NULL, 'f5cb79f9df67656c91eabfe33b0bd8a1b53a0e6d5b3b22fdee727f8c834020f1', '198');
INSERT INTO `worker` VALUES (199, '陈秀德', '女', '27', '13912345678', 'you@hotmail.com', '广东省广州市', '上海燎原中等专业学校', '大专', 4, '团员', NULL, NULL, 'd6546bb5fe7c0b6aa0b5b70f9eafa9f57fbc6e53855e50d13c6c2d490d7002f0', '199');
INSERT INTO `worker` VALUES (200, '张佳伶', '女', '29', '13788886666', 'service@500d.me', '黑龙江省牡丹江市', '牡丹江大学', '大专', 0, '团员', NULL, NULL, 'c495c81ed3defe220fb4955094957f7b01d3ff9af60456515e29900c9fe011a2', '200');
INSERT INTO `worker` VALUES (201, '郑凯婷', '女', '31', '18888886666', 'service@500d.me', '黑龙江省牡丹江市', '广东松山职业技术学院', '大专', 15, '团员', NULL, NULL, 'bbf6e36cee32475a7bfe076a2b7ba999d9abc648ae0fc17067762da64c63c683', '201');
INSERT INTO `worker` VALUES (202, '郑雅仁', '女', '30', '13912345678', 'xianxian@taobao.com', '上海', '中专', '中专', 8, '团员', NULL, NULL, '92a03ce41472555855fa0034f5a0eb355b8abc4c32d3427249c469d9c202359f', '202');
INSERT INTO `worker` VALUES (203, '黄姝', '女', '25', '13511223344', '12343345@qq.com', '上海', '湖南工商大学', '硕士', 3, '团员', NULL, NULL, '5a312ae6977239488214a374cf6465d82ecc25eb942de3beda63f981923caf00', '203');
INSERT INTO `worker` VALUES (204, '林芳江', '女', '28', '13999999999', '1234567@123.com', '上海', '中专', '中专', 6, '团员', NULL, NULL, 'b28e80971f2d88f4a2936747ed5e756d5c1f6cc2c71c6b42dd6b9bffe3ce2eae', '204');
INSERT INTO `worker` VALUES (205, '江骏生', '女', '27', '13999999999', '1234567@123.com', '上海', '重庆科技学院', '本科', 8, '团员', NULL, NULL, '009c561f50d80689128b62433f38b6082be3e44ebb66a64660374f8c98dacc7b', '205');
INSERT INTO `worker` VALUES (206, '黄儒纯', '女', '31', '13122334455', '12345678@qq.com', '上海', '上海城建职业学院', '大专', 10, '团员', NULL, NULL, 'd4717c01ef30cc532dcbee55f7592ee9a26cd352639d9b76b58db4509ba78c3c', '206');
INSERT INTO `worker` VALUES (207, '王培伦', '女', '27', '13912345678', 'Yourname@163. com', '河南', '中专', '中专', 13, '团员', NULL, NULL, '3dab5347f898e65f1d44a0525610face448488f74912f77b659d650e5571e055', '207');
INSERT INTO `worker` VALUES (208, '陈蕙纶', '女', '27', '13500135000', 'service@500d.me', '广东佛山', '广东金融学院', '本科', 6, '党员', NULL, NULL, 'eec63bba6066122c6b57483a4bfb3934d40d75ef9d07ee18e78148d53dacbdd6', '208');
INSERT INTO `worker` VALUES (209, '蔡宜', '男', '24', '13144556677', '1311123456@qq.com', '湖北省武汉市', '广东金融学院', '本科', 0, '党员', NULL, NULL, '917febe0ee3a7510e810a339d6df16c8cce945a0c4ba4b66606b49cb20bba1e9', '209');
INSERT INTO `worker` VALUES (210, '陈信意', '女', '22', '1888888000', 'chenxinyi@qq.com', '上海市', '上海商学院', '本科', 7, '党员', NULL, NULL, '770e29bfbf4708f6dd8008567f64f319c4d1b70ccabf4e51f7a219866dcb8ffc', '210');
INSERT INTO `worker` VALUES (211, '陈惠雯', '女', '31', '13112344321', 'chenxinyi@qq.com', '上海市', '上海师范大学', '本科', 8, '党员', NULL, NULL, '23ae599fb0fc190d6ee087bdaef71eed7d573a3c50a444d6802341912d091ea4', '211');
INSERT INTO `worker` VALUES (212, '张秀', '女', '32', '13912345678', 'Zhangxiu@123.com', '山东', '高中', '高中', 6, '党员', NULL, NULL, '4266b7f67791aa6c66c623317bfa0f6e0f62edc3cb480fe8a14b0a4cf11245bd', '212');
INSERT INTO `worker` VALUES (213, '黄碧仪', '女', '32', '13822334455', '17818322267@qq.com', '广东省广州市', '广州市第二中学', '高中', 8, '党员', NULL, NULL, 'aeb193ba80da9ba8cebed0535c63a537f36fcc1f509574f7b8b3c1aaa6b87ed5', '213');
INSERT INTO `worker` VALUES (214, '陈志文', '女', '27', '18233445566', 'Chenzhiwen@qq.com', '广东省广州市', '华中科技大学', '本科', 12, '党员', NULL, NULL, '87cd2c98322efedecb4557f66a10a5b2c8c04e3b76ef6af63e4141e56f384303', '214');
INSERT INTO `worker` VALUES (215, '谢懿富', '女', '26', '熟练运用Microsoft Office (ppt/excel/word)办公软件、 Premiere、 Photoshop等专业视', 'Chenzhiwen@qq.com', '广东省广州市', '中国政法大学学生会', '本科', 7, '团员', NULL, NULL, 'ed97e0c942a88aeea96258174d210e92e02f5c60ad8881c9556be0ac3cd8acc4', '215');
INSERT INTO `worker` VALUES (216, '杨凡靖', '女', '30', '熟练运用Microsoft Office (ppt/excel/word)办公软件、 Premiere、 Photoshop等专业视', '123456789@qq.com', '', '中央美术学院', '本科', 8, '团员', NULL, NULL, '06a2ce19904becedb609753150cc7ceb461b81bd3059fcbe3059d2e0c0387325', '216');
INSERT INTO `worker` VALUES (217, '蔡秀琴', '女', '32', '13444332211', '123456789@qq.com', '上海', '上海财经大学', '本科', 0, '团员', NULL, NULL, 'a2b7880e6aef0c0aa291557377cded81b4747f7dc46b28f85c1800a80b674773', '217');
INSERT INTO `worker` VALUES (218, '温惠玲', '女', '22', '13122334455', 'wenhuiling@139.com', '上海市浦东新', '江苏科技大学', '本科', 10, '团员', NULL, NULL, '35a62ec7c415a54eb29810a486b71af95fc9dc580f050ac6ebdf6c99856a1778', '218');
INSERT INTO `worker` VALUES (219, '林宗其', '女', '32', '13122334455', '123456789@qq.com', '上海市浦东新', '中国社会科学院大学', '本科', 7, '团员', NULL, NULL, '22379c7df5d239f5b221f219bc9d3178f0b098fd853efd1725288ca7f07fa9ff', '219');
INSERT INTO `worker` VALUES (220, '林绍泰', '女', '32', '13324567890', '1234567@qq.com', '上海市浦东新', '湖北大学', '本科', 6, '团员', NULL, NULL, 'f78faee204dd1e6b25cd0b622409ea2b1c95fea5d21fb9d34ff4aae1ae45b975', '220');
INSERT INTO `worker` VALUES (221, '蔡辰纶', '女', '29', '·接听电话、接待来访人员、安排会议工作，负责会议纪要', '·出入库工作，各类公文、信件、邮件、传真的分发和登记。', '上海市浦东新', '西安交通大学', '本科', 6, '党员', NULL, NULL, 'e12658c469d140360416e8f2000b4d4df0933f5d744e21501e961b5c3ae56f4a', '221');
INSERT INTO `worker` VALUES (222, '王雅雯', '女', '32', '13111223344', 'wangyawen@139.com', '上海市浦东新区', '吉林大学', '本科', 6, '党员', NULL, NULL, 'bdc2ecb86272013c23b7d39ea424fef8d604a7590ea75bec85330f72e0307d2e', '222');
INSERT INTO `worker` VALUES (223, '黄丽昆', '女', '25', '18122223344', '1.负责公司日常行政管理的运作（运送安排、邮件和固定的供给等）；', '上海市浦东新区', '华南理工大学', '本科', 6, '团员', NULL, NULL, '68eba18849f792c6ad01086e1dfc70d62aa023b81b127994523cd8ad2164e0f2', '223');
INSERT INTO `worker` VALUES (224, '李育泉', '女', '33', '18122223344', '1.负责公司日常行政管理的运作（运送安排、邮件和固定的供给等）；', '上海市浦东新区', '湖北工业大学', '本科', 6, '团员', NULL, NULL, 'fd0df670d48185df1915679725e7a57cc20b94f1f31b79aea240ed2d0ff29d51', '224');
INSERT INTO `worker` VALUES (225, '黄芸欢', '女', '26', '15877665544', '1233344@139.com', '深圳', '广西科技大学', '本科', 7, '党员', NULL, NULL, '00e632def33c413841f4539a2dc74461cf9d082e0c4daa8fa3ab394833c79791', '225');
INSERT INTO `worker` VALUES (226, '吴韵如', '女', '31', '18022335252', '1456789@qq.com', '深圳', '学院青年志愿者协会财务部', '本科', 6, '党员', NULL, NULL, '5b098d18d6fb42dcca1acaebb8222ba113dd54560cf446bbb270cfb6bf8e3dc3', '226');
INSERT INTO `worker` VALUES (227, '李肇芬', '女', '24', '18022335252', '123454321@qq.com', '深圳', '江南大学院学生会', '本科', 4, '党员', NULL, NULL, '895b83ca376b57a5f669bf6aae972eaeb3d5376957f246a3e1631ef0ca8c4cb5', '227');
INSERT INTO `worker` VALUES (228, '卢木仲', '女', '28', '13112345678', '2233445@qq.com', '上海市浦东新区', '上海大学', '本科', 7, '党员', NULL, NULL, 'c2e668724316d289180a01e20b767009980903799b26f5425329c4aa27e562b4', '228');
INSERT INTO `worker` VALUES (229, '李成白', '女', '29', '1582233455', '136567899@qq.com', '广州', '华南师范大学', '硕士', 15, '党员', NULL, NULL, '6f1544d93a4527772a600a0ae407a6c26f221588ec546d1a3dc836905c3cdb76', '229');
INSERT INTO `worker` VALUES (230, '方兆玉', '女', '25', '13800138000', '44332256@qq126.com', '广州', '上海东华大学', '本科', 7, '党员', NULL, NULL, '86eea26fe99c2a96402bef14fa47b85aa9327ba4fbb4a6c7a0fc1089707d6592', '230');
INSERT INTO `worker` VALUES (231, '刘翊惠', '女', '31', '20', '15678965@qq.com', '上海市浦东', '上海工艺美术职业学院', '大专', 10, '党员', NULL, NULL, '33a14aa76a63764ea345f0d2a2e92f5ddee4e9e445f949bbc94b3dfbedf7689f', '231');
INSERT INTO `worker` VALUES (232, '丁汉臻', '女', '31', '20', '15678965@qq.com', '上海市浦东', '上海海事大学', '硕士', 7, '党员', NULL, NULL, '5a64f92f4aa56260058149907e421329fc398626e7938447633c8d5e6c29d9ae', '232');
INSERT INTO `worker` VALUES (233, '吴佳瑞', '女', '23', '20', '12345678@qq.com', '上海市浦东', '广州财经大学', '本科', 5, '党员', NULL, NULL, '6a7e87f935c1e41d82083c340296231e8c639ba24a210294fe4b7107a5ad2f8b', '233');
INSERT INTO `worker` VALUES (234, '舒现', '女', '32', '13344556677', 'shuxian@163.com', '上海市浦东', '大学期间', '本科', 7, '党员', NULL, NULL, '7f045c19b3d54581c23737387f9b9220621c48cb27606fc82ae927e3c39a09a6', '234');
INSERT INTO `worker` VALUES (235, '周白芷', '女', '32', '13122343344', 'zhoubaizhi@139.com', '上海市浦东', '上海理工大学', '本科', 6, '党员', NULL, NULL, 'fd80faa0158fdba02a919bc8f0cd6b42e1294a6e66e45290c09902523b3f67cd', '235');
INSERT INTO `worker` VALUES (236, '张姿好', '女', '28', '13533445566', 'zhangzihao@139.com', '上海市浦东', '南京艺术学院', '本科', 7, '党员', NULL, NULL, '08e1bbd1ec4ba7c7a1720f57519b1c039693d010d21768741ce2594309d3880d', '236');
INSERT INTO `worker` VALUES (237, '张虹伦', '男', '28', '0013', 'zhonghonglun@139.com', '天津', '天津大学', '硕士', 12, '党员', NULL, NULL, '0b16718ef2e10edb1064297bf24bcd6443f4500524c2751f455d85cb8202f32b', '237');
INSERT INTO `worker` VALUES (238, '周琼玫', '男', '32', '13134566543', '1234@ibaotu.com', '天津', '河北大学', '本科', 6, '党员', NULL, NULL, '274980af8e4fd2b438960e93ae1607836cad120af530cc2baabefe3090cddd5c', '238');
INSERT INTO `worker` VALUES (239, '倪怡芳', '男', '26', '13134566543', '123456@139.com', '天津', '广东第二师范学院', '本科', 4, '党员', NULL, NULL, 'fbde4703bd86e457236b20ab630eb361e52b743a610ef04581e1afd2432e6c3e', '239');
INSERT INTO `worker` VALUES (240, '郭佩芳', '女', '31', '13522334567', 'guopeifang@139.com', '成都', '西华大学', '本科', 8, '党员', NULL, NULL, '7772e82596ea2416926ab65b85ac2adfc405eac139c37a676b861ed3ac92759b', '240');
INSERT INTO `worker` VALUES (241, '黄文旺', '女', '33', '13588888888', 'huangwenwang@139.com', '江西', '江西财经大学职业发展社', '本科', 8, '党员', NULL, NULL, 'a2898a5f3f7d664c4377c1e59b35064497159553bd7ebbbe6a6c3a4dbf2b52c8', '241');
INSERT INTO `worker` VALUES (242, '郑丽青', '女', '23', '13588888888', '123346372@qq.me', '广东广州', '广东工业大学硕士', '硕士', 12, '党员', NULL, NULL, '00b88f3dee3b81f59f6ee358881fb3e06aa02c2af485654b38f4ae25261b3586', '242');
INSERT INTO `worker` VALUES (243, '许智云', '女', '34', '13500135000', 'xuzhiuyun@163.com', '广东省广州市', '华南理工大学-本科', '本科', 6, '党员', NULL, NULL, '2b782794714926d553216d0ada0052f5aad69258e309bad815220c50e8a6e3ac', '243');
INSERT INTO `worker` VALUES (244, '张孟涵', '女', '23', '13999999999', '2345768@qq.com', '籍贯', '大学期间', '本科', 2, '党员', NULL, NULL, '7aff4cb012a4d31c937cea2b1ba4493f44f916bf86c0aaabc1a7bcb2a7391b1e', '244');
INSERT INTO `worker` VALUES (245, '李小爱', '女', '25', '13156788765', '21384795@qq.com', '籍贯', '浙江传媒学院', '本科', 3, '党员', NULL, NULL, 'd1ee6002740a8d13f9cbdd69e5c9d986fd841112dc58285df15fd81061e69e34', '245');
INSERT INTO `worker` VALUES (246, '王恩龙', '女', '30', '13112344321', 'wangenlong@139.com', '浙江宁波', '宁波大学', '本科', 7, '党员', NULL, NULL, '6c1973abd8eb74e962377f7a0a9dae9d0dc03cf392fadd9c10f65f2e0c5411ba', '246');
INSERT INTO `worker` VALUES (247, '朱政廷', '女', '25', '13512344321', '83317396@qq.com', '广东省珠海市', '深圳技术大学', '本科', 9, '党员', NULL, NULL, 'be01b1c779eeef1302a299de8ea8e4a257e84e4ca49a78d0d7f5262e070bcb19', '247');
INSERT INTO `worker` VALUES (248, '邓诗涵', '女', '33', '13554322345', '83317396@qq.com', '广东省珠海市', '南方科技大学', '本科', 7, '党员', NULL, NULL, '84ca71271ddaef6987e8033ffc4931448467b419b7df7595be3ccc6668e4faba', '248');
INSERT INTO `worker` VALUES (249, '黄盛玫', '女', '31', '18833445566', '83317396@qq.com', '广东省珠海市', '南方科技大学', '硕士', 3, '党员', NULL, NULL, 'fd1dd61201502319de1ab80d0634e68ecdcfcbb3e6c2bc47c0a7b778c9926d11', '249');
INSERT INTO `worker` VALUES (250, '陈政倩', '女', '31', '18833445566', '18666@qq.com', '广东省珠海市', '学院青年志愿者协会财务部', '本科', 9, '党员', NULL, NULL, '8da7906844fb91e9ff2276b27c4b10e14fdc76118619385942ca2defa9fd9300', '250');
INSERT INTO `worker` VALUES (251, '吴俊伯', '女', '27', '18833445566', '12306@qq.com', '湖北武汉', '湖北中医药大学学生会', '本科', 7, '党员', NULL, NULL, 'ad9506d92c2d83b3a54756cd0edfd0ecc8f69f9ab195154b844f06d8bea10b49', '251');
INSERT INTO `worker` VALUES (252, '阮馨学', '女', '24', '18899998888', 'ruanxinxue@163.com', '湖北武汉', '大学期间', '硕士', 8, '党员', NULL, NULL, '6d269e399926b5ecf50a53309cf05383b2c988c37f684c73cde30722bb98342e', '252');
INSERT INTO `worker` VALUES (253, '翁惠珠', '女', '26', '18899998888', '12306@qq.com', '上海', '上海中医药大学学生会', '本科', 7, '党员', NULL, NULL, '71b512ee99eb9e663e38e588f776d101236b8f390e2ccf81ba76079a7d37672a', '253');
INSERT INTO `worker` VALUES (254, '吴思翰', '女', '28', '13533445678', '123456@qq.com', '上海', '上海对外经贸大学', '本科', 4, '党员', NULL, NULL, '890670c721e81d1bb698d6c18bb57dc9cf7168e2d9ec94da92d9281f795c0c21', '254');
INSERT INTO `worker` VALUES (255, '林佩玲', '女', '25', '6655', 'Linpeilin@163.com', '上海', '北京青年政治学院', '大专', 5, '党员', NULL, NULL, '8f6f7ba34e19e71d3e1b7d29721d6e5dbaa2daebca47b5260f620107d370c798', '255');
INSERT INTO `worker` VALUES (256, '邓海来', '女', '29', '写以及线下联系各单位工作。', ' 1345888@qq. com', '上海', '安徽工业大学', '本科', 6, '党员', NULL, NULL, 'ad03db27849ea80a2ea50590a4a8a56be79a6baf9cb527c97e1b2787060ab357', '256');
INSERT INTO `worker` VALUES (257, '陈翊依', '女', '32', '18045678090', '3543637@qq.com', '上海', '湖北工业大学', '本科', 5, '党员', NULL, NULL, 'fdf8850ab4321b95157b104fce6c2521cfd75a8be31a717e97861733ce455f89', '257');
INSERT INTO `worker` VALUES (258, '李建智', '女', '27', '以及线下联系各单位工作。', '3453468@qq.com', '上海', '湖北工业大学', '本科', 7, '党员', NULL, NULL, '01909e5865ed46ddb11bb925dcf88c9dafebf46a82560f29592f6f27c14cfee3', '258');
INSERT INTO `worker` VALUES (259, '张仪湖', '女', '31', '17056787070', '5674587@qq.com', '上海', '学院青年志愿者协会财务部', '本科', 6, '党员', NULL, NULL, 'fc23f4cb03126a2712bf2b082ca2ecd88af8719450bce3af7d9811ce8e0bdbd7', '259');
INSERT INTO `worker` VALUES (260, '王俊民', '女', '31', '13134568899', '2452626@qq.com', '上海', '天津师范大学', '本科', 4, '党员', NULL, NULL, 'defe76a101e0a53c383ce8650f5ae438e4859732c0c3a92c39d11a6ed1541c6f', '260');
INSERT INTO `worker` VALUES (261, '张诗刚', '女', '28', '13134567890', '4365364@qq.com', '上海', '海南大学老乡会', '本科', 3, '党员', NULL, NULL, '8c0846b33d4c18e2fd80466d41048deb47de10daf12e93229e34294f73dcbae2', '261');
INSERT INTO `worker` VALUES (262, '林慧颖', '女', '29', '13645676655', '4365364@qq.com', '上海', '广东财经大学', '本科', 7, '党员', NULL, NULL, 'abd7929e80dde4eb38de461700f39c1632c594935d653b400d05950c41574459', '262');
INSERT INTO `worker` VALUES (263, '沈俊君', '女', '26', '13405678901', ' 24234543@qq.com', '河南', '广东财经大学', '本科', 5, '党员', NULL, NULL, '15f72206560bd36d3db654a931cbf5b7c4947cff1431ff722c1f5b2a76e33356', '263');
INSERT INTO `worker` VALUES (264, '武淑芬', '女', '32', '13123456789', '43252345@qq.com', '广东省广州市', '广东财经大学', '本科', 3, '党员', NULL, NULL, '95507eb5b2339dd52417d66fb83ff7845a7cdcaf02eb576f621bae83606e1d32', '264');
INSERT INTO `worker` VALUES (265, '金雅琪', '女', '29', '13133445566', '3456436@qq.com', '山西太原', '广东财经大学', '本科', 4, '党员', NULL, NULL, '3d083e9c6cb6d9ad223fbe46882d2b3da562d9d0396e50e099237779938be603', '265');
INSERT INTO `worker` VALUES (266, '赖怡宜', '女', '24', '13564356789', '3456436@qq.com', '山西太原', '吉林财经大学', '本科', 7, '党员', NULL, NULL, 'bb26567fc0ce1db3572254506052bee995f6b50fd032b94106c7e638c22ab708', '266');
INSERT INTO `worker` VALUES (267, '李姿伶', '女', '25', '13455667788', '15634287@qq.com', '山西太原', '肯德基学院店', '本科', 6, '党员', NULL, NULL, 'a192e49d058f6f4fa7fab0de52cc7746f3360fcdc13066c277286a4a1ae84643', '267');
INSERT INTO `worker` VALUES (268, '康复学', '女', '22', '13156782345', '43125234@qq.com', '广州', '广州医科大学', '本科', 6, '党员', NULL, NULL, '7c2527cf9e23bd5b5abf011c1c47d192707b8f4a4f4b4180ddaf3612e0d19f05', '268');
INSERT INTO `worker` VALUES (269, '陈淑好', '女', '30', '15857685678', '1428364@qq.com', '广州', '广州医科大学', '本科', 1, '党员', NULL, NULL, '8824223c97f91370cc3443026b0125dba9f2c755fb068887370f87373643646b', '269');
INSERT INTO `worker` VALUES (270, '高咏钰', '女', '31', '15857685678', '4325653486@qq.com', '上海', '广州医科大学', '本科', 0, '党员', NULL, NULL, 'b556465c1dd5863a241a65b23f34af1071d5e89c69df293de383f7991c7a7df2', '270');
INSERT INTO `worker` VALUES (271, '黄彦宜', '女', '29', '13134256789', 'huangyanyi@139.com', '上海', '承德医学院', '本科', 6, '党员', NULL, NULL, '4221b6ee32140ad1b2f4186e4ff48ada34ad2ebbbf0211e0e46ce787844660df', '271');
INSERT INTO `worker` VALUES (272, '周孟儒', '女', '27', '13127364859', '36473829@qq.com', '上海', '承德医学院', '本科', 8, '党员', NULL, NULL, 'ae9f10d6d81528a53da05036f98b23dd7cf20ae937b30ae815ca7d730b5fa254', '272');
INSERT INTO `worker` VALUES (273, '潘欣臻', '女', '28', '13118857649', '54654743@qq.com', '广东省广州市', '承德医学院', '大专', 0, '党员', NULL, NULL, '7527c3fc9b7a25385113ed3eb1e5c554b4030590a8269551f4412f00ecf4cd3b', '273');
INSERT INTO `worker` VALUES (274, '李祯韵', '女', '23', '13125364758', '15364758@qq.com', '广东省广州市', '东莞理工学院', '本科', 2, '党员', NULL, NULL, '085175058ba2741c28766f859d6b847c5181e3a066d3450cd081c92bb072e56f', '274');
INSERT INTO `worker` VALUES (275, '叶洁', '女', '27', '13126475839', '15364758@qq.com', '广东省梅州市', '嘉应学院', '', 8, '党员', NULL, NULL, 'f1c143be149e3a95f0e3ce39fd1d4ab0b303266f4e5d7284099d8ab39f084784', '275');
INSERT INTO `worker` VALUES (276, '梁哲宇', '女', '23', '13135462718', '364758392@qq.com', '广东省广州市', '五邑大学', '本科', 10, '党员', NULL, NULL, 'ebc0d986f650c8350ab9476dec8f71a268913f7a98d6ba5a6b6ef3b982828fc2', '276');
INSERT INTO `worker` VALUES (277, '黄晓萍', '女', '31', '13185746352', '42362626@qq.com', '广东省广州市', '西南大学', '本科', 8, '党员', NULL, NULL, 'd19a99fac8d4487bb0f955229972ce588fedaccbbca16076d6cab220903f7954', '277');
INSERT INTO `worker` VALUES (278, '杨雅萍', '女', '23', '13137482910', 'yangyaping@139.com', '广东省广州市', '广西科技师范学院', '', 14, '党员', NULL, NULL, '9606ff1a8ddf538b14ac4f093ad9209f13592bf0790a4e50fa3d20e80f03f421', '278');
INSERT INTO `worker` VALUES (279, '卢志铭', '女', '24', '13184736482', 'Luzhiming@163.com', '广西省南宁市', '广西科技师范学院', '本科', 7, '党员', NULL, NULL, 'a8d5490ee5e5b9357f9769dd4293729bcf80da9d5efd6831ba1f89d839a85449', '279');
INSERT INTO `worker` VALUES (280, '张茂以', '女', '23', '13145362718', '364758291@qq.com', '广西省南宁市', '广西科技师范学院', '本科', 6, '党员', NULL, NULL, 'f1029b2acd45c1bcc09062e75b53e226b0934600632d97fb1a2ae7dfd19e9193', '280');
INSERT INTO `worker` VALUES (281, '林婉婷', '女', '31', '13164537281', '364758291@qq.com', '广西省南宁市', '范大学“军训先进个人', '本科', 6, '党员', NULL, NULL, 'df3f8f9e268c13e9582d091806ed847c7253594c2408f093f9c764ceff2648ec', '281');
INSERT INTO `worker` VALUES (282, '蔡宜芸', '女', '29', '18275849320', 'office@caiyiyun.com', '北京', '北京大学商学院学生会宣传部', '本科', 8, '团员', NULL, NULL, 'ddf8428c0a0c636dc0b019bcb6ee42dbd2c4f0afb117e58f9e4e9fe9ddf4a8db', '282');
INSERT INTO `worker` VALUES (283, '林现瑜', '女', '29', '13516745389', '436536345@qq.com', '广州市', '龙岩学院', '本科', 10, '团员', NULL, NULL, '4fc52a17a883bdf426adae29400f111c353066a6c8c4e1f253553d67ba5035ab', '283');
INSERT INTO `worker` VALUES (284, '黄柏仪', '女', '25', '13516745389', '34526526@qq.com', '广州市', '龙岩学院', '本科', 0, '团员', NULL, NULL, 'ebd057cf4f62eef0b9904d4f0e6b4859bdc99218e7317dd5dd5bd6f00acdb55a', '284');
INSERT INTO `worker` VALUES (285, '周逸', '女', '30', '13134567893', '536541856@qq.com', '广东省广州市', '南京审计大学', '本科', 8, '团员', NULL, NULL, '3907eff5d227f2798b331dbb396b5a691d6e7f91adec73b0ac74803721ff99fc', '285');
INSERT INTO `worker` VALUES (286, '夏雅惠', '女', '30', '13127364859', '1738492887@qq.com', '住址', '上海外国语大学', '本科', 0, '团员', NULL, NULL, 'f2e85d793c50c1535233f3aea2311ec6a0b71e4470cdae2d76c7f4a2cb854b42', '286');
INSERT INTO `worker` VALUES (287, '王采现', '女', '26', '13127364859', '23425244@qq.com', '住址', '重庆工商大学', '本科', 7, '团员', NULL, NULL, '7c0968f26432d648f5d3d66355d5466ebc38018f1d2b560814dea9026c4eeff6', '287');
INSERT INTO `worker` VALUES (288, '林孟霖', '女', '32', '13167237434', 'Linger@139.com', '广东省广州市', '湖南文理学院', '本科', 5, '团员', NULL, NULL, 'e18de044009bdb9747e19a215ae6dcb23ba7c29e689260bcc9bfa2e3718c5505', '288');
INSERT INTO `worker` VALUES (289, '林竹水', '女', '28', '13154568797', 'Linger@139.com', '广东省广州市', '经济学院”先进个人“', '本科', 6, '团员', NULL, NULL, '085c7cca5eba4fe6b452a77e60afefef6bd7838cbb4ddfe37ed152d613f5b228', '289');
INSERT INTO `worker` VALUES (290, '王怡乐', '女', '33', '13175648392', '84673528@qq.com', '广东省广州市', '2016-2020湘南学院', '本科', 4, '团员', NULL, NULL, '95c683e066d19196bb581840e1c0f97179c7310d572a1a0500da49792d0f6f6d', '290');
INSERT INTO `worker` VALUES (291, '王爱乐', '女', '22', '13175648392', '342562455@qq.com', '广东省广州市', '云南大学获国家', '本科', 4, '团员', NULL, NULL, 'f03cd30f1f0acd162afaca58f45478d06a773bf688171e7f7304686a771b22bb', '291');
INSERT INTO `worker` VALUES (292, '金佳蓉', '女', '31', '13545678765', '123456@qq.com', '江西省高校联盟', '艺术与设计学院', '本科', 8, '团员', NULL, NULL, '951848f2fd266dafe7dc95fcf688a58322a31b569d8b9e7ee34bc456a9e3326d', '292');
INSERT INTO `worker` VALUES (293, '韩健毓', '女', '26', '13565456343', '12345456@qq.com', '吉林省/长春市', '长春大学', '本科', 8, '团员', NULL, NULL, 'a68a0db08f2dc888c46bb3ea815370e7c61d5618fbf116199dfe374f232ddf64', '293');
INSERT INTO `worker` VALUES (294, '李士杰', '女', '22', '13565456343', '12345456@qq.com', '吉林省/长春市', '吉林大学', '本科', 0, '团员', NULL, NULL, '5f9e4196d44d345cdeb47a654e2e80fae9fb36093ff80c0b709b873560008177', '294');
INSERT INTO `worker` VALUES (295, '陈萱珍', '女', '25', '13144556789', '43234325@qq.com', '河北省邢台市', '邢台医学高等专科学校', '大专', 0, '团员', NULL, NULL, 'f5ac52349adac3b2e3b1a599563cff28e525637322dfa9f763bd1b3a688b1fc7', '295');
INSERT INTO `worker` VALUES (296, '苏姿婷', '女', '24', '13534567898', '5342637@qq.com', '浙江省绍兴市', '绍兴文理学院', '本科', 10, '团员', NULL, NULL, 'e9737b3ba44436b368d3eec5a59b40a1eb0b31e2e3fb9b34f1dfcdc3542ce999', '296');
INSERT INTO `worker` VALUES (297, '张政霖', '女', '23', '131912345667', '4324654@qq.com', '上海市浦东新区', '南京航空航天大学', '本科', 6, '团员', NULL, NULL, 'bd0e8b79918b173bbdb8f44564fe6aa659cd350273ddcfe8a09e783ec908bcc2', '297');
INSERT INTO `worker` VALUES (298, '李志宏', '女', '23', '13877665544', '123123@qq.com', '地址', '华东政法大学', '本科', 3, '团员', NULL, NULL, '3e6118298a835a79a27f96452194a15a9d0a461646c98b0a626d8e6dd83fcba8', '298');
INSERT INTO `worker` VALUES (299, '陈素达', '女', '24', '13119876543', '12343556@qq.com', '地址', '哈尔滨工程大学', '本科', 9, '团员', NULL, NULL, '3cdd1471578c68c13e9db710ffea46f1000ac098cc22bd0b0b8a205ee3abdc3e', '299');
INSERT INTO `worker` VALUES (300, '陈虹荣', '女', '29', '13144556677', '23243545@qq.com', '广东省广州市', '深圳技术大学', '本科', 6, '团员', NULL, NULL, '15c5837afe02fc2dc8421825bf2e79b422f704fb1fd6d3670710aac30c9d1b19', '300');

SET FOREIGN_KEY_CHECKS = 1;
