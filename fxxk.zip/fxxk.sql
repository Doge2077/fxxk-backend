/*
 Navicat Premium Data Transfer

 Source Server         : MySql
 Source Server Type    : MySQL
 Source Server Version : 80032 (8.0.32)
 Source Host           : localhost:3306
 Source Schema         : fxxk

 Target Server Type    : MySQL
 Target Server Version : 80032 (8.0.32)
 File Encoding         : 65001

 Date: 13/07/2023 17:12:18
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for auth_group
-- ----------------------------
DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_group
-- ----------------------------

-- ----------------------------
-- Table structure for auth_group_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_group_permissions_group_id_permission_id_0cd325b0_uniq`(`group_id` ASC, `permission_id` ASC) USING BTREE,
  INDEX `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm`(`permission_id` ASC) USING BTREE,
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_group_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for auth_permission
-- ----------------------------
DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_permission_content_type_id_codename_01ab375a_uniq`(`content_type_id` ASC, `codename` ASC) USING BTREE,
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 45 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_permission
-- ----------------------------
INSERT INTO `auth_permission` VALUES (1, 'Can add log entry', 1, 'add_logentry');
INSERT INTO `auth_permission` VALUES (2, 'Can change log entry', 1, 'change_logentry');
INSERT INTO `auth_permission` VALUES (3, 'Can delete log entry', 1, 'delete_logentry');
INSERT INTO `auth_permission` VALUES (4, 'Can view log entry', 1, 'view_logentry');
INSERT INTO `auth_permission` VALUES (5, 'Can add permission', 2, 'add_permission');
INSERT INTO `auth_permission` VALUES (6, 'Can change permission', 2, 'change_permission');
INSERT INTO `auth_permission` VALUES (7, 'Can delete permission', 2, 'delete_permission');
INSERT INTO `auth_permission` VALUES (8, 'Can view permission', 2, 'view_permission');
INSERT INTO `auth_permission` VALUES (9, 'Can add group', 3, 'add_group');
INSERT INTO `auth_permission` VALUES (10, 'Can change group', 3, 'change_group');
INSERT INTO `auth_permission` VALUES (11, 'Can delete group', 3, 'delete_group');
INSERT INTO `auth_permission` VALUES (12, 'Can view group', 3, 'view_group');
INSERT INTO `auth_permission` VALUES (13, 'Can add user', 4, 'add_user');
INSERT INTO `auth_permission` VALUES (14, 'Can change user', 4, 'change_user');
INSERT INTO `auth_permission` VALUES (15, 'Can delete user', 4, 'delete_user');
INSERT INTO `auth_permission` VALUES (16, 'Can view user', 4, 'view_user');
INSERT INTO `auth_permission` VALUES (17, 'Can add content type', 5, 'add_contenttype');
INSERT INTO `auth_permission` VALUES (18, 'Can change content type', 5, 'change_contenttype');
INSERT INTO `auth_permission` VALUES (19, 'Can delete content type', 5, 'delete_contenttype');
INSERT INTO `auth_permission` VALUES (20, 'Can view content type', 5, 'view_contenttype');
INSERT INTO `auth_permission` VALUES (21, 'Can add session', 6, 'add_session');
INSERT INTO `auth_permission` VALUES (22, 'Can change session', 6, 'change_session');
INSERT INTO `auth_permission` VALUES (23, 'Can delete session', 6, 'delete_session');
INSERT INTO `auth_permission` VALUES (24, 'Can view session', 6, 'view_session');
INSERT INTO `auth_permission` VALUES (25, 'Can add user', 7, 'add_user');
INSERT INTO `auth_permission` VALUES (26, 'Can change user', 7, 'change_user');
INSERT INTO `auth_permission` VALUES (27, 'Can delete user', 7, 'delete_user');
INSERT INTO `auth_permission` VALUES (28, 'Can view user', 7, 'view_user');
INSERT INTO `auth_permission` VALUES (29, 'Can add worker', 8, 'add_worker');
INSERT INTO `auth_permission` VALUES (30, 'Can change worker', 8, 'change_worker');
INSERT INTO `auth_permission` VALUES (31, 'Can delete worker', 8, 'delete_worker');
INSERT INTO `auth_permission` VALUES (32, 'Can view worker', 8, 'view_worker');
INSERT INTO `auth_permission` VALUES (33, 'Can add have', 9, 'add_have');
INSERT INTO `auth_permission` VALUES (34, 'Can change have', 9, 'change_have');
INSERT INTO `auth_permission` VALUES (35, 'Can delete have', 9, 'delete_have');
INSERT INTO `auth_permission` VALUES (36, 'Can view have', 9, 'view_have');
INSERT INTO `auth_permission` VALUES (37, 'Can add job', 10, 'add_job');
INSERT INTO `auth_permission` VALUES (38, 'Can change job', 10, 'change_job');
INSERT INTO `auth_permission` VALUES (39, 'Can delete job', 10, 'delete_job');
INSERT INTO `auth_permission` VALUES (40, 'Can view job', 10, 'view_job');
INSERT INTO `auth_permission` VALUES (41, 'Can add matchwork', 11, 'add_matchwork');
INSERT INTO `auth_permission` VALUES (42, 'Can change matchwork', 11, 'change_matchwork');
INSERT INTO `auth_permission` VALUES (43, 'Can delete matchwork', 11, 'delete_matchwork');
INSERT INTO `auth_permission` VALUES (44, 'Can view matchwork', 11, 'view_matchwork');

-- ----------------------------
-- Table structure for auth_user
-- ----------------------------
DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE `auth_user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `last_login` datetime(6) NULL DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `first_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `last_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(254) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_user
-- ----------------------------

-- ----------------------------
-- Table structure for auth_user_groups
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE `auth_user_groups`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_groups_user_id_group_id_94350c0c_uniq`(`user_id` ASC, `group_id` ASC) USING BTREE,
  INDEX `auth_user_groups_group_id_97559544_fk_auth_group_id`(`group_id` ASC) USING BTREE,
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_user_groups
-- ----------------------------

-- ----------------------------
-- Table structure for auth_user_user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE `auth_user_user_permissions`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq`(`user_id` ASC, `permission_id` ASC) USING BTREE,
  INDEX `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm`(`permission_id` ASC) USING BTREE,
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_user_user_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for django_admin_log
-- ----------------------------
DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `object_repr` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `action_flag` smallint UNSIGNED NOT NULL,
  `change_message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `content_type_id` int NULL DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `django_admin_log_content_type_id_c4bce8eb_fk_django_co`(`content_type_id` ASC) USING BTREE,
  INDEX `django_admin_log_user_id_c564eba6_fk_auth_user_id`(`user_id` ASC) USING BTREE,
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `django_admin_log_chk_1` CHECK (`action_flag` >= 0)
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_admin_log
-- ----------------------------

-- ----------------------------
-- Table structure for django_content_type
-- ----------------------------
DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `model` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `django_content_type_app_label_model_76bd3d3b_uniq`(`app_label` ASC, `model` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_content_type
-- ----------------------------
INSERT INTO `django_content_type` VALUES (1, 'admin', 'logentry');
INSERT INTO `django_content_type` VALUES (3, 'auth', 'group');
INSERT INTO `django_content_type` VALUES (2, 'auth', 'permission');
INSERT INTO `django_content_type` VALUES (4, 'auth', 'user');
INSERT INTO `django_content_type` VALUES (5, 'contenttypes', 'contenttype');
INSERT INTO `django_content_type` VALUES (6, 'sessions', 'session');
INSERT INTO `django_content_type` VALUES (9, 'UserCenter', 'have');
INSERT INTO `django_content_type` VALUES (10, 'UserCenter', 'job');
INSERT INTO `django_content_type` VALUES (11, 'UserCenter', 'matchwork');
INSERT INTO `django_content_type` VALUES (7, 'UserCenter', 'user');
INSERT INTO `django_content_type` VALUES (8, 'UserCenter', 'worker');

-- ----------------------------
-- Table structure for django_migrations
-- ----------------------------
DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_migrations
-- ----------------------------
INSERT INTO `django_migrations` VALUES (1, 'UserCenter', '0001_initial', '2023-07-01 11:28:26.127654');
INSERT INTO `django_migrations` VALUES (2, 'UserCenter', '0002_auto_20230606_1950', '2023-07-01 11:28:26.151797');
INSERT INTO `django_migrations` VALUES (3, 'UserCenter', '0003_auto_20230606_2029', '2023-07-01 11:28:26.178803');
INSERT INTO `django_migrations` VALUES (4, 'UserCenter', '0004_auto_20230606_2100', '2023-07-01 11:28:26.258774');
INSERT INTO `django_migrations` VALUES (5, 'UserCenter', '0005_auto_20230611_2028', '2023-07-01 11:28:26.293659');
INSERT INTO `django_migrations` VALUES (6, 'UserCenter', '0006_auto_20230611_2055', '2023-07-01 11:28:26.307663');
INSERT INTO `django_migrations` VALUES (7, 'UserCenter', '0007_worker_fileid', '2023-07-01 11:28:26.323464');
INSERT INTO `django_migrations` VALUES (8, 'contenttypes', '0001_initial', '2023-07-01 11:28:26.341957');
INSERT INTO `django_migrations` VALUES (9, 'auth', '0001_initial', '2023-07-01 11:28:26.555356');
INSERT INTO `django_migrations` VALUES (10, 'admin', '0001_initial', '2023-07-01 11:28:26.613634');
INSERT INTO `django_migrations` VALUES (11, 'admin', '0002_logentry_remove_auto_add', '2023-07-01 11:28:26.620635');
INSERT INTO `django_migrations` VALUES (12, 'admin', '0003_logentry_add_action_flag_choices', '2023-07-01 11:28:26.626636');
INSERT INTO `django_migrations` VALUES (13, 'contenttypes', '0002_remove_content_type_name', '2023-07-01 11:28:26.667007');
INSERT INTO `django_migrations` VALUES (14, 'auth', '0002_alter_permission_name_max_length', '2023-07-01 11:28:26.689562');
INSERT INTO `django_migrations` VALUES (15, 'auth', '0003_alter_user_email_max_length', '2023-07-01 11:28:26.707145');
INSERT INTO `django_migrations` VALUES (16, 'auth', '0004_alter_user_username_opts', '2023-07-01 11:28:26.713179');
INSERT INTO `django_migrations` VALUES (17, 'auth', '0005_alter_user_last_login_null', '2023-07-01 11:28:26.738194');
INSERT INTO `django_migrations` VALUES (18, 'auth', '0006_require_contenttypes_0002', '2023-07-01 11:28:26.740180');
INSERT INTO `django_migrations` VALUES (19, 'auth', '0007_alter_validators_add_error_messages', '2023-07-01 11:28:26.749481');
INSERT INTO `django_migrations` VALUES (20, 'auth', '0008_alter_user_username_max_length', '2023-07-01 11:28:26.778487');
INSERT INTO `django_migrations` VALUES (21, 'auth', '0009_alter_user_last_name_max_length', '2023-07-01 11:28:26.812554');
INSERT INTO `django_migrations` VALUES (22, 'auth', '0010_alter_group_name_max_length', '2023-07-01 11:28:26.829683');
INSERT INTO `django_migrations` VALUES (23, 'auth', '0011_update_proxy_permissions', '2023-07-01 11:28:26.836684');
INSERT INTO `django_migrations` VALUES (24, 'auth', '0012_alter_user_first_name_max_length', '2023-07-01 11:28:26.867692');
INSERT INTO `django_migrations` VALUES (25, 'sessions', '0001_initial', '2023-07-01 11:28:26.912468');

-- ----------------------------
-- Table structure for django_session
-- ----------------------------
DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session`  (
  `session_key` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `session_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`) USING BTREE,
  INDEX `django_session_expire_date_a5c62663`(`expire_date` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_session
-- ----------------------------

-- ----------------------------
-- Table structure for have
-- ----------------------------
DROP TABLE IF EXISTS `have`;
CREATE TABLE `have`  (
  `hid` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL,
  `wid` int NOT NULL,
  PRIMARY KEY (`hid`) USING BTREE,
  INDEX `have_hid_92aeaf_idx`(`hid` ASC) USING BTREE,
  INDEX `have_uid_41684d_idx`(`uid` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 301 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of have
-- ----------------------------
INSERT INTO `have` VALUES (1, 3, 1);
INSERT INTO `have` VALUES (2, 3, 2);
INSERT INTO `have` VALUES (3, 3, 3);
INSERT INTO `have` VALUES (4, 3, 4);
INSERT INTO `have` VALUES (5, 3, 5);
INSERT INTO `have` VALUES (6, 3, 6);
INSERT INTO `have` VALUES (7, 3, 7);
INSERT INTO `have` VALUES (8, 3, 8);
INSERT INTO `have` VALUES (9, 3, 9);
INSERT INTO `have` VALUES (10, 3, 10);
INSERT INTO `have` VALUES (11, 3, 11);
INSERT INTO `have` VALUES (12, 3, 12);
INSERT INTO `have` VALUES (13, 3, 13);
INSERT INTO `have` VALUES (14, 3, 14);
INSERT INTO `have` VALUES (15, 3, 15);
INSERT INTO `have` VALUES (16, 3, 16);
INSERT INTO `have` VALUES (17, 3, 17);
INSERT INTO `have` VALUES (18, 3, 18);
INSERT INTO `have` VALUES (19, 3, 19);
INSERT INTO `have` VALUES (20, 3, 20);
INSERT INTO `have` VALUES (21, 3, 21);
INSERT INTO `have` VALUES (22, 3, 22);
INSERT INTO `have` VALUES (23, 3, 23);
INSERT INTO `have` VALUES (24, 3, 24);
INSERT INTO `have` VALUES (25, 3, 25);
INSERT INTO `have` VALUES (26, 3, 26);
INSERT INTO `have` VALUES (27, 3, 27);
INSERT INTO `have` VALUES (28, 3, 28);
INSERT INTO `have` VALUES (29, 3, 29);
INSERT INTO `have` VALUES (30, 3, 30);
INSERT INTO `have` VALUES (31, 3, 31);
INSERT INTO `have` VALUES (32, 3, 32);
INSERT INTO `have` VALUES (33, 3, 33);
INSERT INTO `have` VALUES (34, 3, 34);
INSERT INTO `have` VALUES (35, 3, 35);
INSERT INTO `have` VALUES (36, 3, 36);
INSERT INTO `have` VALUES (37, 3, 37);
INSERT INTO `have` VALUES (38, 3, 38);
INSERT INTO `have` VALUES (39, 3, 39);
INSERT INTO `have` VALUES (40, 3, 40);
INSERT INTO `have` VALUES (41, 3, 41);
INSERT INTO `have` VALUES (42, 3, 42);
INSERT INTO `have` VALUES (43, 3, 43);
INSERT INTO `have` VALUES (44, 3, 44);
INSERT INTO `have` VALUES (45, 3, 45);
INSERT INTO `have` VALUES (46, 3, 46);
INSERT INTO `have` VALUES (47, 3, 47);
INSERT INTO `have` VALUES (48, 3, 48);
INSERT INTO `have` VALUES (49, 3, 49);
INSERT INTO `have` VALUES (50, 3, 50);
INSERT INTO `have` VALUES (51, 3, 51);
INSERT INTO `have` VALUES (52, 3, 52);
INSERT INTO `have` VALUES (53, 3, 53);
INSERT INTO `have` VALUES (54, 3, 54);
INSERT INTO `have` VALUES (55, 3, 55);
INSERT INTO `have` VALUES (56, 3, 56);
INSERT INTO `have` VALUES (57, 3, 57);
INSERT INTO `have` VALUES (58, 3, 58);
INSERT INTO `have` VALUES (59, 3, 59);
INSERT INTO `have` VALUES (60, 3, 60);
INSERT INTO `have` VALUES (61, 3, 61);
INSERT INTO `have` VALUES (62, 3, 62);
INSERT INTO `have` VALUES (63, 3, 63);
INSERT INTO `have` VALUES (64, 3, 64);
INSERT INTO `have` VALUES (65, 3, 65);
INSERT INTO `have` VALUES (66, 3, 66);
INSERT INTO `have` VALUES (67, 3, 67);
INSERT INTO `have` VALUES (68, 3, 68);
INSERT INTO `have` VALUES (69, 3, 69);
INSERT INTO `have` VALUES (70, 3, 70);
INSERT INTO `have` VALUES (71, 3, 71);
INSERT INTO `have` VALUES (72, 3, 72);
INSERT INTO `have` VALUES (73, 3, 73);
INSERT INTO `have` VALUES (74, 3, 74);
INSERT INTO `have` VALUES (75, 3, 75);
INSERT INTO `have` VALUES (76, 3, 76);
INSERT INTO `have` VALUES (77, 3, 77);
INSERT INTO `have` VALUES (78, 3, 78);
INSERT INTO `have` VALUES (79, 3, 79);
INSERT INTO `have` VALUES (80, 3, 80);
INSERT INTO `have` VALUES (81, 3, 81);
INSERT INTO `have` VALUES (82, 3, 82);
INSERT INTO `have` VALUES (83, 3, 83);
INSERT INTO `have` VALUES (84, 3, 84);
INSERT INTO `have` VALUES (85, 3, 85);
INSERT INTO `have` VALUES (86, 3, 86);
INSERT INTO `have` VALUES (87, 3, 87);
INSERT INTO `have` VALUES (88, 3, 88);
INSERT INTO `have` VALUES (89, 3, 89);
INSERT INTO `have` VALUES (90, 3, 90);
INSERT INTO `have` VALUES (91, 3, 91);
INSERT INTO `have` VALUES (92, 3, 92);
INSERT INTO `have` VALUES (93, 3, 93);
INSERT INTO `have` VALUES (94, 3, 94);
INSERT INTO `have` VALUES (95, 3, 95);
INSERT INTO `have` VALUES (96, 3, 96);
INSERT INTO `have` VALUES (97, 3, 97);
INSERT INTO `have` VALUES (98, 3, 98);
INSERT INTO `have` VALUES (99, 3, 99);
INSERT INTO `have` VALUES (100, 3, 100);
INSERT INTO `have` VALUES (101, 3, 101);
INSERT INTO `have` VALUES (102, 3, 102);
INSERT INTO `have` VALUES (103, 3, 103);
INSERT INTO `have` VALUES (104, 3, 104);
INSERT INTO `have` VALUES (105, 3, 105);
INSERT INTO `have` VALUES (106, 3, 106);
INSERT INTO `have` VALUES (107, 3, 107);
INSERT INTO `have` VALUES (108, 3, 108);
INSERT INTO `have` VALUES (109, 3, 109);
INSERT INTO `have` VALUES (110, 3, 110);
INSERT INTO `have` VALUES (111, 3, 111);
INSERT INTO `have` VALUES (112, 3, 112);
INSERT INTO `have` VALUES (113, 3, 113);
INSERT INTO `have` VALUES (114, 3, 114);
INSERT INTO `have` VALUES (115, 3, 115);
INSERT INTO `have` VALUES (116, 3, 116);
INSERT INTO `have` VALUES (117, 3, 117);
INSERT INTO `have` VALUES (118, 3, 118);
INSERT INTO `have` VALUES (119, 3, 119);
INSERT INTO `have` VALUES (120, 3, 120);
INSERT INTO `have` VALUES (121, 3, 121);
INSERT INTO `have` VALUES (122, 3, 122);
INSERT INTO `have` VALUES (123, 3, 123);
INSERT INTO `have` VALUES (124, 3, 124);
INSERT INTO `have` VALUES (125, 3, 125);
INSERT INTO `have` VALUES (126, 3, 126);
INSERT INTO `have` VALUES (127, 3, 127);
INSERT INTO `have` VALUES (128, 3, 128);
INSERT INTO `have` VALUES (129, 3, 129);
INSERT INTO `have` VALUES (130, 3, 130);
INSERT INTO `have` VALUES (131, 3, 131);
INSERT INTO `have` VALUES (132, 3, 132);
INSERT INTO `have` VALUES (133, 3, 133);
INSERT INTO `have` VALUES (134, 3, 134);
INSERT INTO `have` VALUES (135, 3, 135);
INSERT INTO `have` VALUES (136, 3, 136);
INSERT INTO `have` VALUES (137, 3, 137);
INSERT INTO `have` VALUES (138, 3, 138);
INSERT INTO `have` VALUES (139, 3, 139);
INSERT INTO `have` VALUES (140, 3, 140);
INSERT INTO `have` VALUES (141, 3, 141);
INSERT INTO `have` VALUES (142, 3, 142);
INSERT INTO `have` VALUES (143, 3, 143);
INSERT INTO `have` VALUES (144, 3, 144);
INSERT INTO `have` VALUES (145, 3, 145);
INSERT INTO `have` VALUES (146, 3, 146);
INSERT INTO `have` VALUES (147, 3, 147);
INSERT INTO `have` VALUES (148, 3, 148);
INSERT INTO `have` VALUES (149, 3, 149);
INSERT INTO `have` VALUES (150, 3, 150);
INSERT INTO `have` VALUES (151, 3, 151);
INSERT INTO `have` VALUES (152, 3, 152);
INSERT INTO `have` VALUES (153, 3, 153);
INSERT INTO `have` VALUES (154, 3, 154);
INSERT INTO `have` VALUES (155, 3, 155);
INSERT INTO `have` VALUES (156, 3, 156);
INSERT INTO `have` VALUES (157, 3, 157);
INSERT INTO `have` VALUES (158, 3, 158);
INSERT INTO `have` VALUES (159, 3, 159);
INSERT INTO `have` VALUES (160, 3, 160);
INSERT INTO `have` VALUES (161, 3, 161);
INSERT INTO `have` VALUES (162, 3, 162);
INSERT INTO `have` VALUES (163, 3, 163);
INSERT INTO `have` VALUES (164, 3, 164);
INSERT INTO `have` VALUES (165, 3, 165);
INSERT INTO `have` VALUES (166, 3, 166);
INSERT INTO `have` VALUES (167, 3, 167);
INSERT INTO `have` VALUES (168, 3, 168);
INSERT INTO `have` VALUES (169, 3, 169);
INSERT INTO `have` VALUES (170, 3, 170);
INSERT INTO `have` VALUES (171, 3, 171);
INSERT INTO `have` VALUES (172, 3, 172);
INSERT INTO `have` VALUES (173, 3, 173);
INSERT INTO `have` VALUES (174, 3, 174);
INSERT INTO `have` VALUES (175, 3, 175);
INSERT INTO `have` VALUES (176, 3, 176);
INSERT INTO `have` VALUES (177, 3, 177);
INSERT INTO `have` VALUES (178, 3, 178);
INSERT INTO `have` VALUES (179, 3, 179);
INSERT INTO `have` VALUES (180, 3, 180);
INSERT INTO `have` VALUES (181, 3, 181);
INSERT INTO `have` VALUES (182, 3, 182);
INSERT INTO `have` VALUES (183, 3, 183);
INSERT INTO `have` VALUES (184, 3, 184);
INSERT INTO `have` VALUES (185, 3, 185);
INSERT INTO `have` VALUES (186, 3, 186);
INSERT INTO `have` VALUES (187, 3, 187);
INSERT INTO `have` VALUES (188, 3, 188);
INSERT INTO `have` VALUES (189, 3, 189);
INSERT INTO `have` VALUES (190, 3, 190);
INSERT INTO `have` VALUES (191, 3, 191);
INSERT INTO `have` VALUES (192, 3, 192);
INSERT INTO `have` VALUES (193, 3, 193);
INSERT INTO `have` VALUES (194, 3, 194);
INSERT INTO `have` VALUES (195, 3, 195);
INSERT INTO `have` VALUES (196, 3, 196);
INSERT INTO `have` VALUES (197, 3, 197);
INSERT INTO `have` VALUES (198, 3, 198);
INSERT INTO `have` VALUES (199, 3, 199);
INSERT INTO `have` VALUES (200, 3, 200);
INSERT INTO `have` VALUES (201, 3, 201);
INSERT INTO `have` VALUES (202, 3, 202);
INSERT INTO `have` VALUES (203, 3, 203);
INSERT INTO `have` VALUES (204, 3, 204);
INSERT INTO `have` VALUES (205, 3, 205);
INSERT INTO `have` VALUES (206, 3, 206);
INSERT INTO `have` VALUES (207, 3, 207);
INSERT INTO `have` VALUES (208, 3, 208);
INSERT INTO `have` VALUES (209, 3, 209);
INSERT INTO `have` VALUES (210, 3, 210);
INSERT INTO `have` VALUES (211, 3, 211);
INSERT INTO `have` VALUES (212, 3, 212);
INSERT INTO `have` VALUES (213, 3, 213);
INSERT INTO `have` VALUES (214, 3, 214);
INSERT INTO `have` VALUES (215, 3, 215);
INSERT INTO `have` VALUES (216, 3, 216);
INSERT INTO `have` VALUES (217, 3, 217);
INSERT INTO `have` VALUES (218, 3, 218);
INSERT INTO `have` VALUES (219, 3, 219);
INSERT INTO `have` VALUES (220, 3, 220);
INSERT INTO `have` VALUES (221, 3, 221);
INSERT INTO `have` VALUES (222, 3, 222);
INSERT INTO `have` VALUES (223, 3, 223);
INSERT INTO `have` VALUES (224, 3, 224);
INSERT INTO `have` VALUES (225, 3, 225);
INSERT INTO `have` VALUES (226, 3, 226);
INSERT INTO `have` VALUES (227, 3, 227);
INSERT INTO `have` VALUES (228, 3, 228);
INSERT INTO `have` VALUES (229, 3, 229);
INSERT INTO `have` VALUES (230, 3, 230);
INSERT INTO `have` VALUES (231, 3, 231);
INSERT INTO `have` VALUES (232, 3, 232);
INSERT INTO `have` VALUES (233, 3, 233);
INSERT INTO `have` VALUES (234, 3, 234);
INSERT INTO `have` VALUES (235, 3, 235);
INSERT INTO `have` VALUES (236, 3, 236);
INSERT INTO `have` VALUES (237, 3, 237);
INSERT INTO `have` VALUES (238, 3, 238);
INSERT INTO `have` VALUES (239, 3, 239);
INSERT INTO `have` VALUES (240, 3, 240);
INSERT INTO `have` VALUES (241, 3, 241);
INSERT INTO `have` VALUES (242, 3, 242);
INSERT INTO `have` VALUES (243, 3, 243);
INSERT INTO `have` VALUES (244, 3, 244);
INSERT INTO `have` VALUES (245, 3, 245);
INSERT INTO `have` VALUES (246, 3, 246);
INSERT INTO `have` VALUES (247, 3, 247);
INSERT INTO `have` VALUES (248, 3, 248);
INSERT INTO `have` VALUES (249, 3, 249);
INSERT INTO `have` VALUES (250, 3, 250);
INSERT INTO `have` VALUES (251, 3, 251);
INSERT INTO `have` VALUES (252, 3, 252);
INSERT INTO `have` VALUES (253, 3, 253);
INSERT INTO `have` VALUES (254, 3, 254);
INSERT INTO `have` VALUES (255, 3, 255);
INSERT INTO `have` VALUES (256, 3, 256);
INSERT INTO `have` VALUES (257, 3, 257);
INSERT INTO `have` VALUES (258, 3, 258);
INSERT INTO `have` VALUES (259, 3, 259);
INSERT INTO `have` VALUES (260, 3, 260);
INSERT INTO `have` VALUES (261, 3, 261);
INSERT INTO `have` VALUES (262, 3, 262);
INSERT INTO `have` VALUES (263, 3, 263);
INSERT INTO `have` VALUES (264, 3, 264);
INSERT INTO `have` VALUES (265, 3, 265);
INSERT INTO `have` VALUES (266, 3, 266);
INSERT INTO `have` VALUES (267, 3, 267);
INSERT INTO `have` VALUES (268, 3, 268);
INSERT INTO `have` VALUES (269, 3, 269);
INSERT INTO `have` VALUES (270, 3, 270);
INSERT INTO `have` VALUES (271, 3, 271);
INSERT INTO `have` VALUES (272, 3, 272);
INSERT INTO `have` VALUES (273, 3, 273);
INSERT INTO `have` VALUES (274, 3, 274);
INSERT INTO `have` VALUES (275, 3, 275);
INSERT INTO `have` VALUES (276, 3, 276);
INSERT INTO `have` VALUES (277, 3, 277);
INSERT INTO `have` VALUES (278, 3, 278);
INSERT INTO `have` VALUES (279, 3, 279);
INSERT INTO `have` VALUES (280, 3, 280);
INSERT INTO `have` VALUES (281, 3, 281);
INSERT INTO `have` VALUES (282, 3, 282);
INSERT INTO `have` VALUES (283, 3, 283);
INSERT INTO `have` VALUES (284, 3, 284);
INSERT INTO `have` VALUES (285, 3, 285);
INSERT INTO `have` VALUES (286, 3, 286);
INSERT INTO `have` VALUES (287, 3, 287);
INSERT INTO `have` VALUES (288, 3, 288);
INSERT INTO `have` VALUES (289, 3, 289);
INSERT INTO `have` VALUES (290, 3, 290);
INSERT INTO `have` VALUES (291, 3, 291);
INSERT INTO `have` VALUES (292, 3, 292);
INSERT INTO `have` VALUES (293, 3, 293);
INSERT INTO `have` VALUES (294, 3, 294);
INSERT INTO `have` VALUES (295, 3, 295);
INSERT INTO `have` VALUES (296, 3, 296);
INSERT INTO `have` VALUES (297, 3, 297);
INSERT INTO `have` VALUES (298, 3, 298);
INSERT INTO `have` VALUES (299, 3, 299);
INSERT INTO `have` VALUES (300, 3, 300);

-- ----------------------------
-- Table structure for job
-- ----------------------------
DROP TABLE IF EXISTS `job`;
CREATE TABLE `job`  (
  `jid` int NOT NULL AUTO_INCREMENT,
  `jname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `jneed_age` int NULL DEFAULT NULL,
  `jneed_edu` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `jneed_other` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `jneed_year` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `hash_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`jid`) USING BTREE,
  INDEX `job_jid_5abccb_idx`(`jid` ASC) USING BTREE,
  INDEX `job_jname_b2fd94_idx`(`jname` ASC) USING BTREE,
  INDEX `job_hash_co_2b97bd_idx`(`hash_code` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of job
-- ----------------------------
INSERT INTO `job` VALUES (1, '产品运营', 0, '无', '岗位职责\n1.负责产品上线前后的线上、线下的运营方案和推广工作，协助项目负责人对接市场、产品开发等，完成个项目目标；\n2.负责产品运营中与线下的各种合作，配合完成商务推广，实施项目评估和监控，提升用户活跃度和忠诚度；\n3.负责研究行业竞争动态，定期拜访客户，维护重要客户关系发现客户的需求，引导客户的业务需求，根据自身产品制定产品营销策略，达成既定目标；\n4.负责分析和挖掘产品运营数据、用户行为数据等重要价值信息\n5.负责跟进和整理产品用户反馈，协同产品经理提出产品迭代方案。\n任职要求：\n1.2年及以上产品运营经验；\n2.主动性强，逻辑清晰，沟通能力强，能独立负责和落地运营项目能调动资源为运营目标服', '2年以上', '746fde40e011bc7c5db44ca2351908589a9f8aa16ed93d5fcd357c9df4df4b70');
INSERT INTO `job` VALUES (2, '平面设计师', 0, '大专', '岗位职责：\n1.负责公司公众号的维护和内容推送；\n2.短视频相关内容的文案脚本策划，视频制作及编辑。并结合公司宣传计划，不断优化视频内容；\n3.协助其他平面设计、视频编辑等内容。\n任职要求：\n1.大专及以上学历，1-2年相关工作经验；\n2.熟悉平面设计软件及视频剪辑等，设计感好；\n3.工作责任心强，沟通及理解能力强。', '1-2年', '14b7fa102b989cac3d2e71cbbc70adc9c14e1c73a77980cdcdc5f57f2b3c46cf');
INSERT INTO `job` VALUES (3, '财务', 0, '本科', '岗位职责：\n1.全面负责财务部的日常管理工作；\n2.组织制定财务方面的管理制度及有关规定，并监督执行；\n3.向公司提供各项财务报告和必要的财务分析；\n4.监控可能会对公司造成经济损失的重大经济合同；\n5.有独立处理账务和税务的能力者优先；\n6.有全盘账务处理，税务工作，年度汇算清缴能力者优先；\n7.公司资质和合同的归档保管工作；\n8.完成上级领导交代的其他日常工作任务。\n任职要求：\n1.本科及以上学历；\n2.通晓财会专业知识，熟悉国家有关财务、会计、税收政策和实务；\n3.有互联网行业相关经验优先；\n4.原则性强，沟通能力佳，有良好的团队协作意识。', '0', 'c5990ff4dd90f2e3d4addf90eef303ab749958ada12e25ee3404b8077c4506fa');
INSERT INTO `job` VALUES (4, '市场营销', 0, '本科', '岗位职责：\n1.根据公司发展方向及阶段性目标，制定品牌战略、推广策略等年度经营方案；\n2.参与各产品推广筹划方案的制定与执行；\n3.负责企业整体形象的定位与维护，建立完整的产品口碑营销方案及公司形象推广方案；\n4.负责与新媒体及知名媒体进行沟通，开展长期良好合作；\n5.负责制作与推广公司各类宣传资料，完善对外各类宣传通稿；\n6.负责为公司的知识产权、荣誉资质等进行申请、维护与宣传。\n职位要求：\n1.熟练使用办公软件，可以独立制作表格、PPT等；\n2.良好的沟通能力，善于维护客户关系；\n3.有拓展、策划经验能力者优先考虑。\n4.本科以上\n5.10年以上相关工作经验\n', '10', '653eff46ed0fa0c2221f93e2be6874abaac6a30c2840b0c82b8a7b17e2cf7437');
INSERT INTO `job` VALUES (5, '项目主管', 0, '本科', '岗位职责：\n1.责任项目的整体管理；\n2.项目的订单下单、样板配合；\n3.产品批量安装的现场、质量、进度、成本的管理；\n4.项目的沟通协调管理和售后维护工作；\n5.工程回款及安装款结算工作；\n6.安装队及文明生产的管理工作；\n7.项目管理的档案化建设与管理的工作。\n任职要求:\n1.熟练操作使用WORD/EXCEL/等办公软件；\n2.工作严谨、认真、细致，有良好的执行力；\n3.熟悉本行业的规范，具有良好沟通及协调能力；\n4.本科以上\n5.3年以上项目主管经验', '3年以上', 'd24cda8199eedeef01fe09de452256138452d15e6cd868d65f969397a5b5081e');
INSERT INTO `job` VALUES (6, '开发工程师', 0, '本科', '岗位职责：\n1.负责公司产品运营相关网站后端快速响应开发；\n2.负责公司运营支持相关系统开发；\n3.负责设计和开发一些内部工具，提高网站整体性开发效益，保证一定的质量；\n4.负责相关APP接口开发；\n5.配合移动部门与产品部门实现服务器端相关接口开发。\n任职要求:\n1.学历本科以上，计算机相关专业；\n2.3年以上软件开发经验；\n3.熟悉JAVA语言，有APP开发经验。\n', '0', 'e14ecf30ef29a4396f6e175a655da444ab803d40ac34af6f8288ddb5fb8a59df');
INSERT INTO `job` VALUES (7, '文员', 25, '大专', '岗位职责：\n1.接听、转接电话;接待来访人员；\n2.负责办公室的文秘、信息、机要和保密工作，做好办公室档案收集、整理工作；\n3.做好会议纪要；\n4.负责公司公文、信件、邮件、报刊杂志的分送；\n5.负责传真件的收发工作；\n6.负责办公室仓库的保管工作，做好物品出入库的登记；\n7.做好公司宣传专栏的组稿；\n8.按照公司印信管理规定，保管使用公章，并对其负责；\n任职要求:\n1.25岁以上，一年以上相关工作经验；\n2.大专以上学历:\n3.熟练使用办公软件，处理日常办公业务，管理施工档案，有装饰公司工作经验者优先；\n4.具有全面的工作计划、对外沟通及应变等能力；\n\n', '1年', 'b0b4648ec40b33a437ac26aff77bf8b391e7f4fb670b5a72cd5fad42e242d1c1');
INSERT INTO `job` VALUES (8, '电商运营', 0, '无', '岗位职责：\n1.负责每日各类日商品的挑品并制定各个品类商品的挑品标准；\n2.分析商品各项运营数据建立数据模型，并优化商品挑品标准；\n3.对各类目下商品内容的完整性和美观性负责；\n4.了解和研究其它购物平台商品选品的特性，研究各品类商品的用户喜好；\n5.编辑优选商品的推荐理由并对用户提交的推荐理由进行审核；\n6.和平台用户及商家的沟通；\n7.其它一些交待的工作任务。\n任职要求:\n1.2 年及以上电商运营工作阅历，例如天猫或者小程序电商 阅\n历\n2.较为完整的电商学问体系，缜密的分析规律力量以及完整 的电商思维框架\n3.执行力量强，优秀的沟通协调力量、书面表达力量、规律思维力量\n', '2年', 'a80312b5bf1632cc75be8237c997375ccd309b0dc2693e80cc572a87509de3a5');
INSERT INTO `job` VALUES (9, '人力资源管理', 0, '大专', '岗位职责：\n1.协助上级建立健全公司招聘、培训、工资、保险、福利、绩效考核等人力资源制度建设\n2.建立、维护人事档案，办理和更新劳动合同;\n3.执行人力资源管理各项实务的操作流程和各类规章制度的实施，配合其他业务部门工作；\n4.执行招聘工作流程，协调、办理员工招聘、入职、离职、调任、升职等手续\n5.协同开展新员工入职培训，业务培训，执行培训计划，联系组织外部培训以及培训效果的跟踪、反馈;\n6.负责员工工资结算和年度工资总额申报，办理相应的社会保险等8、帮助建立员工关系，协调员工与管理层的关系，组织员工的活动。\n任职要求:\n1.大专以上学历;\n2.两年以上人力资源工作经验;\n3.熟悉人力资源管理各项实务的操作流程,熟悉国家各项劳动人事法规政策,并能实际操作运用;\n', '2年', '35b327c3926473870b320da25542be27e5d9d177fa6286543d94825ce9b7eed9');
INSERT INTO `job` VALUES (10, '风控专员', 0, '硕士', '岗位职责：\n1、制定公司风险管理的目标，制度，流程。\n2、建立项目风险管理体系，推进公司内外部风险的全面防范与控制。 \n3、熟悉金融市场、房产市场、二手车买卖相关法律法规及信贷风险防范识别、监控、化解体系\n4、完成上级领导临时交办的其他任务。\n任职要求:\n1、熟悉各种汇率、期权的定义与应用\n2、熟悉境内外各银行理财产品操作:\n3、熟悉EXCEL操作，有数据统计和分析能力\n4、专业要求:金融、国际贸易.\n5、硕士以上\n6、5年以上相关工作经验\n', '5年', '09c033b069845bd9f6d37988ad1960a77cfdec3a6a65fbd1236c218388b8a928');

-- ----------------------------
-- Table structure for matchwork
-- ----------------------------
DROP TABLE IF EXISTS `matchwork`;
CREATE TABLE `matchwork`  (
  `minfo` int NOT NULL AUTO_INCREMENT,
  `wid` int NOT NULL,
  `jid` int NOT NULL,
  `match` double NOT NULL,
  PRIMARY KEY (`minfo`) USING BTREE,
  INDEX `matchwork_minfo_f384d1_idx`(`minfo` ASC) USING BTREE,
  INDEX `matchwork_wid_1120cb_idx`(`wid` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of matchwork
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `uid` int NOT NULL AUTO_INCREMENT,
  `hash_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`uid`) USING BTREE,
  UNIQUE INDEX `user_hash_code_2bc75cad_uniq`(`hash_code` ASC) USING BTREE,
  INDEX `user_uid_8f8462_idx`(`uid` ASC) USING BTREE,
  INDEX `user_hash_co_1ccebb_idx`(`hash_code` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '123');
INSERT INTO `user` VALUES (4, '18ffa8b2250e2cb15905d4b4e2e8e5ac025fbfbef2d2d122c69471c693b1cf2d');
INSERT INTO `user` VALUES (2, 'ab828b6d37e3dc89402d0ec2e406ae06cc9741a4c6720652763a7ec286abc5d3');
INSERT INTO `user` VALUES (3, 'd82494f05d6917ba02f7aaa29689ccb444bb73f20380876cb05d1f37537b7892');

-- ----------------------------
-- Table structure for worker
-- ----------------------------
DROP TABLE IF EXISTS `worker`;
CREATE TABLE `worker`  (
  `wid` int NOT NULL AUTO_INCREMENT,
  `worker_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `sex` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `age` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `phone_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `e_mail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `edu_school` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `edu_level` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `work_year` int NULL DEFAULT NULL,
  `statue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `urls` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `url_format` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `hash_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `fileid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`wid`) USING BTREE,
  UNIQUE INDEX `worker_hash_code_74c6d579_uniq`(`hash_code` ASC) USING BTREE,
  INDEX `worker_worker__60a34a_idx`(`worker_name` ASC) USING BTREE,
  INDEX `worker_wid_20c430_idx`(`wid` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 301 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of worker
-- ----------------------------
INSERT INTO `worker` VALUES (1, '张吉惟', '女', '29', '13899999999', 'zhangjiwei@163.com', '北京海淀区', '北京师范大学', '本科', 3, '党员', NULL, NULL, 'a3c64561a75aa63d12fbcf752c1963fe9b7edaa279df3333a6dcf2f5d59c5af2', '1');
INSERT INTO `worker` VALUES (2, '林国瑞', '男', '29', '13831088888', 'linguorui@qq.com', '北京', '中国传媒大学', '本科', 11, '群众', NULL, NULL, '7cfd7c1ca56535bb6451a3c81aa11f1d4d670ea0ffad48ef59228c8fb3fb5cd8', '2');
INSERT INTO `worker` VALUES (3, '林玟书', '男', '30', '13801138023', 'linwenshu@qq.com', '广东省广州市', '南方科技大学', '本科', 6, '团员', NULL, NULL, 'c60377f1dbcbced5059ae10d40895d8587f93caf40ce7d6ed2c2e0c1a8e1799b', '3');
INSERT INTO `worker` VALUES (4, '林雅南', '男', '22', '13801138823', 'linyanan@qq.com', '广东省广州市海珠区', '华南师范大学', '本科', 3, '党员', NULL, NULL, 'f31bbf3e2cc5934456ecc247cb2031e19e6666548a33ce24263cede67aabc61b', '4');
INSERT INTO `worker` VALUES (5, '江奕云', '男', '23', '13812138123', 'nesson@91muban.cn', '广东省广州市海珠区', '华南理工大学', '本科', 5, '群众', NULL, NULL, 'ece11f5ef53d171121b87ef0b8c78c73f9b885fcae435f728e8adfa72eccef85', '5');
INSERT INTO `worker` VALUES (6, '刘柏宏', '男', '24', '13889138123', 'liubohong@qq.com', '广东省广州市海珠区', '广东师范专科学院', '大专', 9, '党员', NULL, NULL, 'e0f6e68c364d47eca60af705e4bb7a0d4f90ea506ae6f12928a4b438cd25dd24', '6');
INSERT INTO `worker` VALUES (7, '阮建安', '女', '28', '13818138525', 'ruanjianna@qq.com', '广东省广州市海珠区', '奈森师范大学', '大专', 7, '党员', NULL, NULL, '4f1ae1bb3c059220d5a9ba20e6501078fd184477c69eb11b35d20bd221623e88', '7');
INSERT INTO `worker` VALUES (8, '林子帆', '女', '27', '13808138036', 'linzifan@qq.com', '广东省广州市海珠区', '阳江职业学院', '大专', 10, '党员', NULL, NULL, '9de456abce1a6173de88b5ca5002992fc9c5e5932a1632c96580936fb5398999', '8');
INSERT INTO `worker` VALUES (9, '夏志豪', '男', '29', '13822138221', 'xiazhihao@qq.com', '广东省广州市海珠区', '广州文艺职业技术学院', '大专', 5, '群众', NULL, NULL, '9d8914127dbd31c769772d339c9c69020d0b06152985ca04ff8698bc9810f9f6', '9');
INSERT INTO `worker` VALUES (10, '吉茹定', '男', '30', '13823138023', 'nesson@91muban.cn', '广东省广州市海珠区', '广州科学技术职业学院', '大专', 10, '群众', NULL, NULL, 'fb91b5e4d40298a122543987b828bbbaf09b06f8ec53de449c18d1e7d7f1fddb', '10');
INSERT INTO `worker` VALUES (11, '李中冰', '男', '22', '13802131218', 'lizhongbing@qq.com', '广东省广州市海珠区', '顺德中专学校', '中专', 7, '党员', NULL, NULL, '26ba2ca26cf94565e12aa3ec656bbae64045c07eca31f87e31516ebdc9b7546f', '11');
INSERT INTO `worker` VALUES (12, '黄文隆', '女', '30', '13800138000', 'nesson@91muban.cn', '广东省广州市海珠区', '广东广播电视中等专业学校', '中专', 4, '党员', NULL, NULL, 'dc0fc58fbc3e31a9baa6ebad5f54113f1b8f0c53193113c616797e88ed751434', '12');
INSERT INTO `worker` VALUES (13, '谢彦文', '男', '29', '13800138000', 'nesson@91muban.cn', '东省广州市', '广州市财经职业学校', '中专', 3, '群众', NULL, NULL, '35f7a7b462b74daa1668c44a2a3f56585a2c65387ac9247a4f34ba3e358350cd', '13');
INSERT INTO `worker` VALUES (14, '傅智翔', '男', '26', '13800138000', 'nesson@91muban.cn', '广东省广州市', '广东第二商业中等专业学校', '中专', 5, '群众', NULL, NULL, '100f158c9363f97488f0e14be7d266927ef79b35fa93ae260d74a86c079511ba', '14');
INSERT INTO `worker` VALUES (15, '洪振霞', '男', '23', '13800138000', 'nesson@91muban.cn', '广东省广州市海珠区', '深圳中专学校', '中专', 4, '党员', NULL, NULL, '0fd0973089f58d0b9a518335fa35923b850e7a58f45705fe02b7f8559bd1480e', '15');
INSERT INTO `worker` VALUES (16, '刘姿婷', '女', '28', '13800138000', 'liuziting@qq.com', '湖北省武汉市', '武汉大学', '本科', 10, '党员', NULL, NULL, 'df3d5a2cd41882c6e66351add02464dde2121e3dc1c6bae694d4442050ddf16f', '16');
INSERT INTO `worker` VALUES (17, '荣姿康', '男', '29', '13800138000', 'rongzikang@qq.com', '', '华中科技大学', '硕士', 11, '群众', NULL, NULL, '639bde5d11513d01538d13347b3e78856574b18584a0fd9b5f80b38943d6152f', '17');
INSERT INTO `worker` VALUES (18, '吕致盈', '男', '22', '', 'nesson@91muban.cn', '', '武汉理工大学', '本科', 8, '群众', NULL, NULL, '2f152f6a55fab7fd84d5465360320e039fbb7f58e9a26f98e9ee34c75f16dda5', '18');
INSERT INTO `worker` VALUES (19, '方一强', '男', '33', '13800138000', 'nesson@91muban.cn', '湖北省武汉市', '中南财经政法大学', '硕士', 13, '群众', NULL, NULL, 'cb79d6f7e55898255dc381f53993fd2ad70480ef04834e87994b28a57b70217d', '19');
INSERT INTO `worker` VALUES (20, '黎芸贵', '男', '25', '13800138000', 'service@500d.me', '湖北省武汉市', '华中师范大学', '硕士', 14, '群众', NULL, NULL, '48671c19709682156d7e09be28cd48bb21642fbbf8124760571aa8564e2ffcca', '20');
INSERT INTO `worker` VALUES (21, '郑伊雯', '男', '32', '13800138000', 'nesson@91muban.cn', '湖北省武汉市', '管理学院团委学生会', '硕士', 8, '党员', NULL, NULL, '406505aea9617a70c348f54f9dfbcfa2a2fac0b7abacdf85a93cd3591c35f8ea', '21');
INSERT INTO `worker` VALUES (22, '雷进宝', '男', '25', '', 'nesson@91muban.cn', '湖北省武汉市', '中国地质大学', '硕士', 9, '群众', NULL, NULL, '1ab23389ad9d85dcd35cb7b33f420f60109ab079f369211b61213125eca8940a', '22');
INSERT INTO `worker` VALUES (23, '吴美隆', '男', '28', '13800138000', 'service@500d.me', '湖北省武汉市', '湖南大学', '博士', 6, '党员', NULL, NULL, '7038c21cc7acd2b8448f3c618b6425b0f18ef72edb5caf2b1d448b92106abed3', '23');
INSERT INTO `worker` VALUES (24, '吴心真', '女', '23', '13800138000', 'service@500d.me', '湖北省武汉市', '中南大学', '硕士', 7, '党员', NULL, NULL, '7594643b34c9fdc90df1b71ae397a0e91943355da59ed9729c0853cab937c5f3', '24');
INSERT INTO `worker` VALUES (25, '王美珠', '男', '30', '13800138000', 'service@500d.me', '湖北省武汉市', '湖南师范大学', '硕士', 4, '群众', NULL, NULL, '6abf2e45420828dba7261839d5079abd2833f9ca00c6bc932c954374ac69de8c', '25');
INSERT INTO `worker` VALUES (26, '郭芳天', '男', '24', '13800138000', 'service@500d.me', '上海浦东新区', '上海外国语大学', '本科', 6, '群众', NULL, NULL, 'bd5029991c86d0fab69ed5403c53947b2f343d52fda41fb014f614e4b0e9669b', '26');
INSERT INTO `worker` VALUES (27, '李雅惠', '男', '31', '13912341210', 'xianqi@taobao.com', '在湖南省湘西自治州保靖县', '湖南大学', '本科', 8, '党员', NULL, NULL, '6d66936c1fa18e6907642d3f936775ee6a019938b0828a01b2d54f141ef3a843', '27');
INSERT INTO `worker` VALUES (28, '陈文婷', '男', '23', '13912341210', 'xianqi@taobao.com', '', '东华大学', '本科', 6, '党员', NULL, NULL, '7779ad896f9096934ecff98feb1c1f86f35e1f782bd3846fda35152ea6cf63fc', '28');
INSERT INTO `worker` VALUES (29, '曹敏佑', '男', '23', '13212345678', 'caominyou@163.com', '山东', '山东大学', '本科', 6, '群众', NULL, NULL, '3e307727d8b2b34f8d4909cf0e8117fdc9507c398818c34dfba831399c0277ba', '29');
INSERT INTO `worker` VALUES (30, '王依婷', '男', '29', '13124567890', '12345678@163.com', '上海', '浙江大学', '本科', 0, '党员', NULL, NULL, '210534a3fdc5da60f73ca485ee1014f432aff0c85b2672c7429c1abd22e982ac', '30');
INSERT INTO `worker` VALUES (31, '陈婉璇', '男', '22', '13123456789', '12345678@163.com', '', '浙江大学', '硕士', 6, '党员', NULL, NULL, '0eaf5aa7831dc3995325a85e0d612e87a8b1677ea78af2d670dfbca678cf7fdd', '31');
INSERT INTO `worker` VALUES (32, '吴美玉', '男', '30', '13912341234', '123456@163.com', '上海', '电子科技大学成都学院', '本科', 6, '群众', NULL, NULL, '90f99c79c7c3d9a4d38ba2d4ba02c0dd46b2a9b15624ee38ee348baa258559d1', '32');
INSERT INTO `worker` VALUES (33, '蔡依婷', '男', '28', '13912345678', 'xianxian@taobao.com', '上海', '北京理工大学', '本科', 8, '群众', NULL, NULL, '9e3564889a7a69a1052a48fab179665de670c6d683b63942127a1d0d00d740e5', '33');
INSERT INTO `worker` VALUES (34, '杨欣宇', '男', '30', '', 'Hilisyoung@qq.com', '家庭地址', '', '本科', 4, '群众', NULL, NULL, 'd5677835474df95cf0f3ced956cd63f91dfb2401c228db422eb52dd6e7048e7e', '34');
INSERT INTO `worker` VALUES (35, '林家纶', '女', '22', '13912345678', '139123@163.com', '', '上海交通大学', '本科', 3, '党员', NULL, NULL, '56bc2b8ff129ab3605c1f62d5c4c32c245304f9d22a58baf758ac8ca404c7d6e', '35');
INSERT INTO `worker` VALUES (36, '郑昌梦', '男', '26', '13123456789', '12345678@163.com', '山东', '', '博士', 6, '群众', NULL, NULL, 'cb073f6ae1f6c74be84ac8aa03b9fbbf729ca5d95eff2a2f637919cf030a9d89', '36');
INSERT INTO `worker` VALUES (37, '张瑞群', '男', '23', '12345555', '+(0)12345555-邮箱：CONTACT@YOURDOMAIN.COM', '', '', '本科', 2, '群众', NULL, NULL, '9f125bf069fab69e083ee7bf8662dfbe9e4d4e30897b237c8b91ad22d8c2a942', '37');
INSERT INTO `worker` VALUES (38, '洪紫芬', '男', '30', '13800138000', 'nesson@91muban.cn', '广东省广州市海珠区', '北京师范大学', '本科', 8, '群众', NULL, NULL, 'cd0dee9a870aace28bcfef107f5d621e9c8946ce8b297700f10068d460ed4f7a', '38');
INSERT INTO `worker` VALUES (39, '邓家伟', '男', '25', '13500135000', 'service@500d.me', '广东省广州市', '', '本科', 3, '群众', NULL, NULL, '312819621ac6a0b54dfe53d393c12a7281efccf72e754d02f5c0d50ca687d719', '39');
INSERT INTO `worker` VALUES (40, '谢佩', '男', '22', '13500135000', 'service@500d.me', '广东省广州市', '中国人民大学-市场营销', '本科', 2, '群众', NULL, NULL, '7e2f55a638652cf1e229617b06b8099aeabd1c8af5cd81d0bd2d1ca896fa5ef9', '40');
INSERT INTO `worker` VALUES (41, '任郁文', '男', '27', '13500135000', 'service@500d.me', '', '上海交通大学-市场营销', '硕士', 2, '群众', NULL, NULL, '907df1b6aa08d9279fd1779406a27a3b619f73fb4567901bdd0d6cabe53958f7', '41');
INSERT INTO `worker` VALUES (42, '李治', '男', '32', '13500135000', 'service@500d.me', '', '同济大学', '本科', 8, '群众', NULL, NULL, '71ffff58edaeea35bde4ccf686cf835743cfeacc83fc4a7a74381fcaf1224a7e', '42');
INSERT INTO `worker` VALUES (43, '林石美', '男', '29', '13500135000', 'service@500d.me', '广东省广州市', '', '本科', 6, '群众', NULL, NULL, '87de2c9f85fd92757c6b2564c4e0fb36a988b9be0151468cacf38ab9fa870fc0', '43');
INSERT INTO `worker` VALUES (44, '郑雅茜', '男', '30', '13500000000', 'service@500d.me', '广东省广州市', '哈尔滨工业大学', '硕士', 6, '群众', NULL, NULL, '04df27b9ce732bd3897fabb3bbea8fc765cfca582e39ff1c08e931cf51e5fafa', '44');
INSERT INTO `worker` VALUES (45, '胡泰', '男', '24', '13500135000', 'service@500d.me', '', '中山大学', '本科', 10, '党员', NULL, NULL, '569036d885aabe80f9ee1718a4d9c75bacbfda5746ef11283d10984e77e89624', '45');
INSERT INTO `worker` VALUES (46, '陈怡盈', '男', '29', '18800135000', 'service@500d.me', '广东省广州市', '', '本科', 6, '群众', NULL, NULL, '8af76c15b68489907b23a9456f1f37a5030475eede8ea538227bcca121b9d93e', '46');
INSERT INTO `worker` VALUES (47, '石意', '男', '25', '1888888888', 'service@500d.me', '广东省广州市', '上海交通大学职业发展社', '本科', 3, '群众', NULL, NULL, '9f861d9815b998732c2efb401cf13cfd67cf6c47c87914652a8bff6e7a786939', '47');
INSERT INTO `worker` VALUES (48, '林盈威', '男', '27', '18500135000', 'service@500d.me', '广东省广州市', '南开大学', '本科', 4, '群众', NULL, NULL, 'a922e8d878fbf25e4accf22b4b213d889fef0710f39ac256b2faca1d86308186', '48');
INSERT INTO `worker` VALUES (49, '林志嘉', '男', '26', '', 'service@500d.me', '广东省广州市', '金华职业技术学院职业发展社', '大专', 2, '群众', NULL, NULL, '3b0ac367beb23791dbd7478f0dffb65162c64818bbfc2c8942b0c5d3091c3e94', '49');
INSERT INTO `worker` VALUES (50, '李秀玲', '男', '23', '', 'service@500d.me', '', '', '', 10, '群众', NULL, NULL, '805551b202bef50efdf9d0127f54f1d7996e26cd2174f6e0764b8b26a4f354c8', '50');
INSERT INTO `worker` VALUES (51, '王彦霖', '男', '28', '', 'service@500d.me', '广东省广州市', '', '大专', 3, '群众', NULL, NULL, '3da871f2ee74e49de9a6a5177fae0f81b18c4f595d45a58dcedfb48ab0707ff4', '51');
INSERT INTO `worker` VALUES (52, '叶惟芷', '男', '28', '13788886666', 'service@500d.me', '', '中国传媒大学', '本科', 2, '群众', NULL, NULL, '936693ce156443816e30debbec2767e034134298fb241a816a66a06053772606', '52');
INSERT INTO `worker` VALUES (53, '郑星钰', '男', '32', '13588888888', 'service@500d.me', '', '', '大专', 1, '党员', NULL, NULL, '821189faea910eaaf81dbee08a7707474c91797aeaf268e4f81e24485affe5e5', '53');
INSERT INTO `worker` VALUES (54, '邱贞伟', '男', '22', '13500135000', 'service@500d.me', '', '长沙民政职业技术学院', '大专', 4, '群众', NULL, NULL, '5c4625e326edc36c36193ed7ec31008fb2da8d8ea2cc7abc9516df9b67d9ba96', '54');
INSERT INTO `worker` VALUES (55, '姚扬云', '男', '33', '18800000000', 'yaoyangyun@qq.con', '', '中山大学', '博士', 8, '群众', NULL, NULL, 'ffa57b0b304d0ca3a40637dfb74bef4a7a5a1bdc9b9f27daf114781ae2412691', '55');
INSERT INTO `worker` VALUES (56, '涂武盛', '男', '25', '18000000000', 'service@500d.me', '山东德州', '滨州职业学院', '', 3, '党员', NULL, NULL, 'c06cecf95436786327a6a384246e2c31a211e627365d691f32297592c9e3dc52', '56');
INSERT INTO `worker` VALUES (57, '王雅顺', '男', '31', '13800008888', 'service@500d,me', '广东广州', '江苏建筑职业技术学院', '', 5, '党员', NULL, NULL, '4d31adb61b13cefe736611ef1b5c9eea0690fa6ae98ae442564735db7ef98a05', '57');
INSERT INTO `worker` VALUES (58, '唐欣仪', '男', '26', '18888886666', 'service@500d,me', '', '河北工业职业技术学院', '', 8, '群众', NULL, NULL, 'aedd1df879654d5c0235358a6249b32c7a72ceb19de4b574586f918d07d6ea4c', '58');
INSERT INTO `worker` VALUES (59, '陈政圣', '男', '26', '1888008000', 'service@500d.me', '上海市', '中山大学附属第三医院', '大专', 7, '群众', NULL, NULL, 'ba9afb83a6252412a6b8440791038031c4418694b2630ee31bbcb8eaef01bc4c', '59');
INSERT INTO `worker` VALUES (60, '李淑淑', '男', '27', '18800000000', 'service@500d.me', '上海市', '福建船政交通职业学院', '大专', 0, '党员', NULL, NULL, '5f8080bcc6e526911cb9f903ae7c85fcafa9f108db7705b44326843df0117f57', '60');
INSERT INTO `worker` VALUES (61, '黄莉秋', '男', '24', '', 'service@500d.me', '上海', '中专', '中专', 5, '群众', NULL, NULL, 'b1aedd7244b5f88ab7b405f9a5193c19f2c131060c708a32d5b97f2f73c8af38', '61');
INSERT INTO `worker` VALUES (62, '林雅慧', '男', '24', '13500135000', 'Service@500d.me', '广东省广州市', '广州市轻工职业学校', '中专', 3, '群众', NULL, NULL, '663be27ae73161dd536918e5796bdd2a4053deee0aa1dc269b86997ecdb1fadd', '62');
INSERT INTO `worker` VALUES (63, '陈育福', '男', '32', '13800111000', 'office@microsoft.com', '', '中专', '中专', 0, '群众', NULL, NULL, '8d059d03d71ff8c79fde7f5ebbec6af2378acd32fb08b0f06a5aa93d287b1cf9', '63');
INSERT INTO `worker` VALUES (64, '吴惠雯', '男', '23', '13912345678', 'xianxian@taobao.com', '上海', '中专', '中专', 7, '群众', NULL, NULL, 'a8e07863f48cb9f740e15dfad59eb97c65b25d9ed61ed9922f821184c8ad5f02', '64');
INSERT INTO `worker` VALUES (65, '詹允坚', '男', '31', '13912345678', 'xianxian@taobao.com', '上海', '中专', '中专', 10, '群众', NULL, NULL, '48a349c1f9c1bb519344a0cb87a5f08e9b38d2ee8cb185b2c1bedfa0f7bfcfc9', '65');
INSERT INTO `worker` VALUES (66, '赖淑珍', '男', '25', '13912345678', 'xianxian@taobao.com', '上海', '中专', '中专', 0, '党员', NULL, NULL, 'b497183e6872ecb029a16649d27da1736bccde4feb19c2db1a46319fe731b85a', '66');
INSERT INTO `worker` VALUES (67, '李凯婷', '男', '32', '13912345678', '13912@163.com', '上海', '中专', '中专', 4, '群众', NULL, NULL, '2b0b0d434a509c3ed488fdf2a3f0e789e39e8ea437b403fcfc5fff80123281d0', '67');
INSERT INTO `worker` VALUES (68, '林承辰', '男', '25', '135', '123456@.com', '赴山东省图书馆志愿者服务', '济南新技术应用学校', '中专', 8, '团员', NULL, NULL, '295f7eba7ddf6fbbefc9d151ce77d8bbc51447e7c2e03dde2cd0ccd91ac743b8', '68');
INSERT INTO `worker` VALUES (69, '刘亭宝', '男', '25', '13999999999', '1234567@123.com', '山东', '中专', '中专', 6, '群众', NULL, NULL, '57e3945c520d668f63afc3dc287f843c8da3af909d055450495ab6a9c77fb1cb', '69');
INSERT INTO `worker` VALUES (70, '宋慧元', '男', '28', '13912345678', 'Yourname@163. com', '山东', '中专', '中专', 13, '群众', NULL, NULL, '8d6cbb10e0e6377957cc943961757c4dc555ba06bb8a803548585726f91fa9a7', '70');
INSERT INTO `worker` VALUES (71, '赖俊军', '男', '24', '15888888888', '123456@qq.com', '上海宝山', '上海交通大学', '本科', 4, '群众', NULL, NULL, '9e4767a68f2fb2418960567bd7af8b8b19e673ba1f0592508f7c91d274aafb8f', '71');
INSERT INTO `worker` VALUES (72, '荆彦璋', '男', '32', '13800138080', '123456@qq.com', '山东省日照市', '中国石油大学学生会', '本科', 4, '团员', NULL, NULL, '0d69413fe07fe6a81fd179fced7722fa494c68924d6ac6997b8bc9f603c23fca', '72');
INSERT INTO `worker` VALUES (73, '白怡均', '男', '24', '1380000020', '4564646@qq.com', '山东省日照市', '中国海洋大学本科', '本科', 8, '群众', NULL, NULL, '1cd9ec83b622a0e2ddfea843b0f2204c979fe86be53104224e4fea21e8fd3b9b', '73');
INSERT INTO `worker` VALUES (74, '林姿辛', '男', '26', '13500135000', 'linzixing@163.com', '广东省广州市海珠区滨江东路', '上海复旦大学', '本科', 5, '党员', NULL, NULL, '6afb3096034bdc5f7d3640869a90cd84ea2f6e6f23a1f3844956f8a16dac4529', '74');
INSERT INTO `worker` VALUES (75, '连书忠', '男', '24', '13700008888', 'service@500d.me', '广东省上海市海珠区滨江东路', '中山大学-本科', '本科', 5, '群众', NULL, NULL, '03e00e3435e9392a94ed2e2248b3cb4a9176bd7a76b7d2c1315d26ecdc779802', '75');
INSERT INTO `worker` VALUES (76, '余仪礼', '男', '28', '18880013500', 'service@500d.me', '广东省广州市', '', '', 6, '群众', NULL, NULL, '1c134a05aece19d1d4638760ef3c8c899e7037c52b6d571a9611002a3ca80c41', '76');
INSERT INTO `worker` VALUES (77, '袁哲仪', '男', '23', '13700008888', '500d@139.com', '', '南开大学', '本科', 6, '群众', NULL, NULL, '9ee67744b2d81c3a20e932e67405060163db0b467fb1f7fad04e4d6bc125ddb5', '77');
INSERT INTO `worker` VALUES (78, '叶怡财', '男', '32', '18800145000', 'service@500d.me', '广东佛山', '天津大学', '本科', 8, '党员', NULL, NULL, '3bb6349e6abccee662a66dd997cce3786474fa470e9cdf46ccc88a724616d223', '78');
INSERT INTO `worker` VALUES (79, '冯雅筑', '男', '27', '18888888888', 'nesson.com', '', '郑州大学', '本科', 8, '群众', NULL, NULL, '2c75c3ca15eed2bfb63346f3af919ddcb5e3d82bd1690823c68501cd019503c8', '79');
INSERT INTO `worker` VALUES (80, '吴惠美', '男', '32', '13912345678', 'you@hotmail.com', '山东', '', '本科', 2, '群众', NULL, NULL, 'ba29a10c850502666401b13e4ff5d1b92a5fdbca6e8351ecf82ab82130254389', '80');
INSERT INTO `worker` VALUES (81, '何佳慧', '男', '28', '1888888000', 'naisen.com', '上海市', '中国人民大学', '本科', 4, '党员', NULL, NULL, '25e45838dda2694b0947a8e2ebe5cfb6c9aa985b3791eed25b742c2ec3eea157', '81');
INSERT INTO `worker` VALUES (82, '李伦圣', '男', '30', '', '12345@docer.com', '家庭住址', '', '本科', 3, '群众', NULL, NULL, '88c0b787243bcf81a54fcf7ceb3eb301c94e9ce5fcfdb2cbef9e3d1d67ca2ada', '82');
INSERT INTO `worker` VALUES (83, '彭正仁', '男', '27', '12345678901', '12498118@qq.com', '广东省韶关市', '华中科技大学', '本科', 1, '党员', NULL, NULL, '9b2824480ff8dae9e71a125af65a21abc36bbcb1ea4fff7a9a4a1809217e731d', '83');
INSERT INTO `worker` VALUES (84, '刘小紫', '男', '31', '13800000000', '13800@qq.com', '', '东南大学院校联络部', '本科', 7, '群众', NULL, NULL, '90fa68ec2540639b7761d6d5fe98eba1aeea1d05609d05fc5c590c63aa6053ca', '84');
INSERT INTO `worker` VALUES (85, '温燕达', '男', '29', '13988888888', '888888@163.com', '浙江省杭州市滨江区', '苏州大学校园大使', '本科', 3, '党员', NULL, NULL, '744c531b725419264b2c827f7c182b12eae8b5003dba8f50202882b983b54aad', '85');
INSERT INTO `worker` VALUES (86, '刘佳雨', '男', '29', '18091898568', '53555893@qq.com', '', '陕西工业职业技术学院', '', 5, '群众', NULL, NULL, 'b36ab915fa339cb9085e1a77601fc00e4ed2e5c3d45403e31810ae4eaa8ae2b0', '86');
INSERT INTO `worker` VALUES (87, '林怡紫', '男', '24', '137397777777', '@healthyyang2', '', '', '硕士', 3, '群众', NULL, NULL, '37bb38d170c631fad3f56638590271df7e043d929963269905aa7269bd7764f1', '87');
INSERT INTO `worker` VALUES (88, '吴婷婷', '男', '31', '', '@12345', '住址', '中央财经大学', '硕士', 3, '群众', NULL, NULL, '092c63990e38ae7bc4a9a4a955c47d7276ecdbf617175c991a7f3110eef125a9', '88');
INSERT INTO `worker` VALUES (89, '杨怡君', '男', '26', '13912345678', 'xianxian@taobao.com', '上海', '北京清华大学', '本科', 3, '群众', NULL, NULL, '5d7e20f74ee3dcc618169134a21221c08b02d8748da7628e6d46436408689c86', '89');
INSERT INTO `worker` VALUES (90, '黄康刚', '男', '22', '17345678900', '12345@123.com', '', '北京科技大学', '本科', 5, '群众', NULL, NULL, '59cdf2e01fc6347230aad8ace58abbf3a3506466de91a6532bae279cb47c342e', '90');
INSERT INTO `worker` VALUES (91, '林辰', '男', '32', '13910345678', 'yourname@163.cm', '上海', '西安电子科技大学', '本科', 8, '党员', NULL, NULL, 'b6aa513c1b69cda274a66b7b8e17f030138bd3e00699f0951fd34f50f47c8e7d', '91');
INSERT INTO `worker` VALUES (92, '沈慧美', '男', '23', '13912220080', 'myemail@163.com', '上海', '上海海洋大学', '本科', 6, '党员', NULL, NULL, 'e483dacb5f005016c88f124ea87d4c4247565af81e8ea608d2a121c0b27376f8', '92');
INSERT INTO `worker` VALUES (93, '吴佩霖', '男', '23', '', 'yourname@163.com', '湖南', '湖南中医药大学', '本科', 0, '党员', NULL, NULL, '24f068cfbc0d00af5170196b417c954e59225dfcd41307ceaf98f2b8ea5e0183', '93');
INSERT INTO `worker` VALUES (94, '张伟杰', '男', '33', '15031019999', '123456qq.com', '', '', '硕士', 4, '群众', NULL, NULL, '3246ebd4c648cd90fdecda05ef31d08d321d688cbfff9bfdd6824a80403a4706', '94');
INSERT INTO `worker` VALUES (95, '刘友淳', '男', '26', '', '22448900@qq.com', '', '东城区第三中学分校', '本科', 6, '群众', NULL, NULL, '604b8e3d27b07410f85ff4f93b5979c87feee6cc59f382e0046fa193bf156e6b', '95');
INSERT INTO `worker` VALUES (96, '杜怡', '女', '25', '18010001000', '微博/@微软Office PLUS', '籍贯/北京', '', '', 5, '群众', NULL, NULL, '37e775b5a6e7476d7f1fad71e90d95a8fa42136329acd95d4b7c0cece41e32df', '96');
INSERT INTO `worker` VALUES (97, '潘孝东', '女', '31', '13899999999', 'xiaohen@189.com', '', '中央戏曲学院', '本科', 0, '团员', NULL, NULL, 'de2573eaf570050bb3668f7f05a7a7b865fb366d5b0c6067476dd54d749758a8', '97');
INSERT INTO `worker` VALUES (98, '周志合', '男', '28', '1350013500', 'service@163.com', '广东省广州市', '深圳大学', '本科', 3, '群众', NULL, NULL, '207fcf2233ec0a04e1384618d322a9968d4679b1a06f12d67b889e117a611c55', '98');
INSERT INTO `worker` VALUES (99, '刘力霞', '男', '25', '', 'eplus@micros', '籍贯北京', '', '本科', 2, '群众', NULL, NULL, '2b2f77190fe28316a58b0e18669756b2087be5cf6386dd8012c6ca1da5ea62e2', '99');
INSERT INTO `worker` VALUES (100, '林钰婷', '男', '25', '13800138000', 'zxj2015@gmail.com', '', '北京师范大学', '本科', 8, '群众', NULL, NULL, '91ad73766040448afda86db4dbcd147e5165d306c03593ec067bc46f5424ae63', '100');
INSERT INTO `worker` VALUES (101, '蔡于纬', '男', '26', '13511223344', 'service@500d.me', '广东省广州市', '高中', '', 0, '群众', NULL, NULL, 'f4217f4cad43b195097690ecb9c65c1c288c46d806ec1125a916e7bb8871dce8', '101');
INSERT INTO `worker` VALUES (102, '林俊凯', '男', '24', '13500135000', 'shixi@shixiseng.com', '广东省广州市', '高中', '', 5, '群众', NULL, NULL, '63ff86f2b5c213057fe37f2b3c36c4afe0034fd9a6d5359b6200652b673f1454', '102');
INSERT INTO `worker` VALUES (103, '蔡雅惠', '男', '25', '13912345678', 'Caiyahui@123.com', '山东', '高中', '高中', 6, '群众', NULL, NULL, '8e5026412a44d58677c7b80b6cb8e8dc1c6e314c56a91f1941bd13bdeb67d5fc', '103');
INSERT INTO `worker` VALUES (104, '汪喜祥', '男', '25', '13800138000', '224438888@qq.com', '广东省广州市', '', '', 11, '群众', NULL, NULL, '3821337e88b7613d1db9a07e62e640188a6335eff3d74376f7179d313d9432b1', '104');
INSERT INTO `worker` VALUES (105, '陈铭', '女', '28', '18122334455', 'Chenming@qq.com', '', '兰州交通大学', '本科', 12, '群众', NULL, NULL, '1137626e1fb4eb56419d1cdc7da346b1043bf1d3ae19bac9d203e458908d4f29', '105');
INSERT INTO `worker` VALUES (106, '郭子珠', '男', '24', '熟练运用 Microsoft Office (ppt/excel/word)办公软件、 Premiere、 Photoshop等专业视', 'Chenming@qq.com', '辽宁省辽阳市民政局', '人民公安大学学生会', '本科', 7, '团员', NULL, NULL, '7d76d373a9c06f882ec001ba95c66db6d53867b3e74f9571c91d9de76e1d2934', '106');
INSERT INTO `worker` VALUES (107, '许伦吉', '女', '30', '1308310002', '456481343@qq.com', '广东省广州市', '', '本科', 5, '群众', NULL, NULL, 'f97d4f4c29e9ddaa611607f211c24cce3c4c49adb58e1004d37405e1f0a8cfb5', '107');
INSERT INTO `worker` VALUES (108, '陈佳雨', '男', '25', '>负责手机客户端产品GUI的整体风格设计，应用工具的相关菜单', '24546326@163.com', '湖南省长沙市', '怀化职业技术学院艺术设计', '大专', 7, '群众', NULL, NULL, '9862d460e703550cec1bbfd3f8447ee81ff9483bb52c0dd9478984428f5a183e', '108');
INSERT INTO `worker` VALUES (109, '赖英贤', '男', '26', '', 'office@microsoft.com/箱', '', '', '硕士', 2, '群众', NULL, NULL, '6b685d32907e0119129db621c65e9bf054e79fcd3bcac082e730ecbf1dc6b3cb', '109');
INSERT INTO `worker` VALUES (110, '吴嘉茹', '男', '30', '13912345678', 'wujiaru@123.com', '', '高中', '', 3, '群众', NULL, NULL, '8110d34a8547b7d97ab6e4cd9476ba6010ba4a1fb34027ad33ab7794d8c3194c', '110');
INSERT INTO `worker` VALUES (111, '陈永桂', '男', '28', '13700008888', '3254465@qq.com', '', '', '本科', 7, '群众', NULL, NULL, '9ae11bd5a107e08d3553edcc6f2710c2de9df0a6b2de5ccf0aa25bf67894b10c', '111');
INSERT INTO `worker` VALUES (112, '张裕忠', '男', '24', '15966583333', 'dafs@qq.com', '广东省广州市', '华南科技大学市场营销本科', '本科', 8, '群众', NULL, NULL, '967f18478a01e1f481f86e2aff00c570a0bfed45b5fea59f562c38adbd049466', '112');
INSERT INTO `worker` VALUES (113, '石春紫', '男', '28', '电话/18010001000', '箱/officeplus@microsoft.com', '籍贯/北京', '北京联合大学', '学历', 7, '群众', NULL, NULL, '1a16405de6998df9558a287ea935742d2af5173cad8784fdbd5cff1525de8b32', '113');
INSERT INTO `worker` VALUES (114, '方美君', '男', '28', '13500135000', 'Service@500d.me', '广东省广州市', '中国传媒大学MBA', '硕士', 8, '群众', NULL, NULL, '9c42f1935c4ddb2e7ea15804ec22d14337689052cb6c96bcaa4887c52ba8d289', '114');
INSERT INTO `worker` VALUES (115, '潘右博', '女', '29', '', 'panyoubo@qq.com', '上海', '北京工业大学', '本科', 0, '团员', NULL, NULL, 'b3b4d7f071dabcc08d03fb6abf5bb284c29255d89c38e8d0a9156011b8d66b4f', '115');
INSERT INTO `worker` VALUES (116, '俞星如', '女', '30', '18686660000', '186866@qq.com', '', '厦门大学-硕士', '硕士', 3, '团员', NULL, NULL, '92de8deb0417e81446048204debcbf94097bed2986a0c3f59a8a1f3cd734b17f', '116');
INSERT INTO `worker` VALUES (117, '张冠杰', '男', '27', '18123456789', 'office@microsoft.com', '', '', '本科', 5, '群众', NULL, NULL, '77b693f899fc732621ce69ed4e1626591b68ba2564671bb3c052be8d7a873a63', '117');
INSERT INTO `worker` VALUES (118, '钟庭玮', '男', '24', '', ' office@microsoft.com', '', '', '', 0, '群众', NULL, NULL, 'fe23c5bf906508d0d5a9099f80ccabe185608dbfaa98826a84e7966783eda5de', '118');
INSERT INTO `worker` VALUES (119, '叶茜', '男', '26', '13500000000', 'Yeqian@163.com', '', '北京师范大学', '本科', 4, '群众', NULL, NULL, '8b655315cf88eaa4a2d082a2cfa15a118071854520f76a82269e9a363d9f9f2a', '119');
INSERT INTO `worker` VALUES (120, '陈伯薇', '男', '28', '15031088898', 'chenbowei@qq.com', '北京', '中国科学院大学', '', 9, '群众', NULL, NULL, '5820b64bd0a16c96033a0080da6ecdadfb10d709807a7e75fc3e76147276eb4e', '120');
INSERT INTO `worker` VALUES (121, '陈昭祥', '男', '33', '131415161', '151515@126.com', '', '湖北工业大学学生会', '校级三好学生、系级三好学生、优秀学生干部、优秀主持人', 6, '群众', NULL, NULL, '11b14f94fa5c55b99c943069d33bdd2b59be01a7dd335dc444a87a20e9c4b3c9', '121');
INSERT INTO `worker` VALUES (122, '陈伟伦', '男', '28', '13888888888', 'service@500d.me', '广东省广州市', '中南林业科技大学', '', 8, '群众', NULL, NULL, '655b2a77606093cdafd6356632c320f5c0f5b0fff54749956f6e8e9ca4234185', '122');
INSERT INTO `worker` VALUES (123, '黄雅慧', '男', '23', '13500135000', 'service@d.me', '广东省广州市', '淮南师范学院', '本科', 3, '群众', NULL, NULL, '4ac2c47ee3c57b7f2059043731a491ef0ef6307df40b3a14f6cc93cf7af1af68', '123');
INSERT INTO `worker` VALUES (124, '郭子豪', '女', '27', '18088888088', 'Zyq1998@163.com', '', '南京师范大学', '本科', 5, '团员', NULL, NULL, '1d511c0dabc4169750f8e0fb19be293b9657e317b803feea3c476ed55582713a', '124');
INSERT INTO `worker` VALUES (125, '黄彦霖', '女', '24', '13656547899', '123456789@qq.com', '上海市静安区', '秦皇岛外国语大学', '大专', 5, '群众', NULL, NULL, 'e0d78bdbd8250bd8a20093fda4af848f032cb15dffd1192b186063cc835bbe9f', '125');
INSERT INTO `worker` VALUES (126, '宋合', '男', '30', '15812344321', 'songhe@qq.com', '广州', '广州白云学院', '', 6, '群众', NULL, NULL, '8eb71a54198fc7fb86f8f94bfbc5651d0eca080b5910326fc69f807003802611', '126');
INSERT INTO `worker` VALUES (127, '许雅婷', '男', '24', '15000000000', '458434@qq.com', '广州', '宁波工程学院', '本科', 10, '群众', NULL, NULL, '973ee92f5994b62f927c8291db0efca016c1cc53632b3fae1be751a114e0681d', '127');
INSERT INTO `worker` VALUES (128, '王圣如', '女', '33', '13800000000', '235664@qq.com', '浙江省台州市黄岩新前卫生院', '广州医科大学', '', 6, '党员', NULL, NULL, 'c5626cdad5e518008f2547679cee8b78e79461497909d2f25968ab7d065b03e5', '128');
INSERT INTO `worker` VALUES (129, '何伶元', '男', '28', '15800000000', 'halingyuan@qq.com', '', '武汉大学', '文学学士', 6, '群众', NULL, NULL, '6822526fa70cee182c54abf688c0bfd8e7f575d6f97cd1c227aaa303b8e37813', '129');
INSERT INTO `worker` VALUES (130, '钟伦军', '男', '33', '13800000800', '1380454@qq.com', '', '浙江大学', '', 5, '群众', NULL, NULL, '182b8d3fa0f6e83a17e77343c1512fbf814278a363a829aaca4ac1849cda0f3c', '130');
INSERT INTO `worker` VALUES (131, '蔡佳蓉', '男', '27', '13588888888', 'caijiarong@qq.com', '广东广州', '汕头大学本科', '本科', 8, '群众', NULL, NULL, 'a3ba1161437fad9937ee664fad8071991fefb5659b1c455e682baad615891b30', '131');
INSERT INTO `worker` VALUES (132, '薄康柔', '男', '33', '13000000000', '5464654@qq.com', '', '南昌大学艺术设计本科', '本科', 4, '群众', NULL, NULL, '5e95e798189bf775f5271df5dee748a87a87d7b38b90a96f2a8939ede27db2dc', '132');
INSERT INTO `worker` VALUES (133, '冯成轩', '女', '23', '', '5464654@qq.com', '现居地址', '合肥工业大学', '本科', 10, '团员', NULL, NULL, 'e9e861732f633a7a062fd6c2e87bfca7f5c732c4ad87f7a87306c3e95fd6dbd1', '133');
INSERT INTO `worker` VALUES (134, '高成彦', '男', '27', '13500000000', 'zxj2015@gmai.com', '地址', '北京师范大学本科', '本科', 5, '群众', NULL, NULL, '68d012230989568f9919b89ad48ac2cb1b0387f7044439b11e247540a7f6d42a', '134');
INSERT INTO `worker` VALUES (135, '徐采伶', '男', '27', '13500135000', 'service@500d.me', '广东省广州市', '华南科技大学', '本科', 8, '群众', NULL, NULL, '184cf72a8bc1c3eac6fbc7eb8c6718ac350a0a89ea809ffe4395b0521278d142', '135');
INSERT INTO `worker` VALUES (136, '杨雪', '女', '31', '15031088888', '123456@qq.com', '北京', '北京协和医学院', '本科', 7, '团员', NULL, NULL, '152cbdedbf882cec8b4427871e2c28c8e9188d32d5cf1b35c3bba8024152b72d', '136');
INSERT INTO `worker` VALUES (137, '林彦韦', '男', '30', '15886888688', '123456@qq.com', '', '清华大学大学夏令营', '本科', 5, '党员', NULL, NULL, '8d48d4020fb38b22f9337fb0cf1e90848ddff3be305cd1b371361d780a548439', '137');
INSERT INTO `worker` VALUES (138, '李毓', '男', '33', '13800138000', '123456@qq.com', '广东省广州市', '', '本科', 8, '群众', NULL, NULL, '4ee7952b36a07d864baf61ed5f73c5554641c80a9e58dcb90814e42f461ee563', '138');
INSERT INTO `worker` VALUES (139, '邱宜瑶', '男', '23', '', 'office@microsoft.com', '', '', '本科', 0, '群众', NULL, NULL, 'ffd8552fbcae2dec8bda673cd6d917851e6258fe64c04d4e455b8748ef5e517d', '139');
INSERT INTO `worker` VALUES (140, '陈政文', '男', '24', '', 'me@shixiseng.com', '北京', '', '', 10, '团员', NULL, NULL, '037aea9effccb00b2dc657b5d7b037e114d7f6672806368a5f603e0e6d0473c2', '140');
INSERT INTO `worker` VALUES (141, '李宜豪', '男', '32', '18600000000', '1051566620@qq.com', '', '上海财经大学', '本科', 9, '群众', NULL, NULL, '850ed65ea299246523f707dddb7c0ee823b934780118f825002027b6b4915d8e', '141');
INSERT INTO `worker` VALUES (142, '陈宜宁', '女', '31', '18010001000', '@微软', '北京', '北京工商大学', '', 12, '群众', NULL, NULL, '8fb31b113142d19f51d147c5c903013b24f08401a3f85242d3189054a9008b95', '142');
INSERT INTO `worker` VALUES (143, '陈志宏', '男', '29', '13103456789', '131234@163.com', '', '北京建筑大学', '本科', 8, '党员', NULL, NULL, '4c7f4560f4ef07f2cdb566100ad9235b1484cb904161443a08118ba8a6641606', '143');
INSERT INTO `worker` VALUES (144, '阮柔治', '男', '28', '15031019999', '邮寄杂志，并邮件告知会员杂志已寄出，随时记录并采纳会员们的反馈意见', '江苏省传媒艺术研究会', '公共管理学院', '硕士', 7, '群众', NULL, NULL, 'f5384d23a6cbf02f151dbb731d82332a77b0dcfca78c6bc6d72494011f0a75ae', '144');
INSERT INTO `worker` VALUES (145, '林乐', '男', '32', '', 'linle@qq.com', '', '', '本科', 4, '群众', NULL, NULL, '5b7532466a9ef9438e03db0bd2ab9cb7836b25d2e18d1609de383ec638d6faec', '145');
INSERT INTO `worker` VALUES (146, '简健昀', '男', '27', '15031088888', '123456@qq.com', '北京', '', '本科', 7, '党员', NULL, NULL, '82d287bf6d373bab0a1a3d191bc23778647028e36472e0ddb60df67127f85606', '146');
INSERT INTO `worker` VALUES (147, '廖雅君', '男', '31', '', 'service@500d.mme', '上海', '苏州大学', '学士学位', 5, '群众', NULL, NULL, 'd018917d25e78113cd041c2aaf9b8463998f2fc8089fa3852e9f3c5ffa223b88', '147');
INSERT INTO `worker` VALUES (148, '梁佩芬', '男', '32', '18071404', '909096@qq.com', '湖南', '长沙理工大学', '学士学位', 4, '党员', NULL, NULL, '980c59440d01ac584a88ee7c806b3de1f4daddcf679962ed75bab78bb8dd7c89', '148');
INSERT INTO `worker` VALUES (149, '苏玮伦', '男', '32', '城警察》电视专题栏目及负责联系各大媒体对新闻事件的集中报道；', 'suweilun@qq.com', '', '湖南师范大学', '本科', 12, '群众', NULL, NULL, '2304c02be27158daea597eadc0bc26bdad3c803f4b5ee2fcfc68f2769bd06911', '149');
INSERT INTO `worker` VALUES (150, '秦娇真', '男', '29', '13888888888', 'service@500d.me', '湖北省武汉市', '湖北经济学院-本科', '本科', 8, '群众', NULL, NULL, 'f07d53dcbca92a27db47c4558a85bf6b465711207dbf0f3d0cb1de6057fa0626', '150');
INSERT INTO `worker` VALUES (151, '李仁杰', '男', '27', '', 'lirenjie@qq.com', '', '北京市清华大学', '本科', 4, '团员', NULL, NULL, '683ce7ee4dd78d79e24f2c3f51271bddbcc8a6a1d205de7a59ded4a43e1e84a3', '151');
INSERT INTO `worker` VALUES (152, '谢佳雯', '男', '25', '', 'Youremail@gmail.com', '籍贯', '山东建筑大学', '本科', 12, '群众', NULL, NULL, '0db82a5c8cc506b2404edb363a8693ad63ed41d57d5c8313702a4ef163deb3cd', '152');
INSERT INTO `worker` VALUES (153, '李佳', '男', '23', '', '123456789@qq.com', '山东烟台', '山东理工大学', '本科', 5, '党员', NULL, NULL, 'fc9a098871a0c7fbc7c447ab59efffc9431ce731c29279dee89f04a0c93e1812', '153');
INSERT INTO `worker` VALUES (154, '郭贤青', '男', '22', '', '45325578@qq.com', '', '暨南大学', '本科', 6, '党员', NULL, NULL, 'e796226f26dcdc3e94540ffad1079be93bfc3b497bebd7e58def007fa031e026', '154');
INSERT INTO `worker` VALUES (155, '吴怡伶', '男', '30', '配合每期公益电影活动的宣传，并负责联系场地策划电影展；', 'zhangxiaojie@gmail.com', '', '北京师范大学', '本科', 3, '群众', NULL, NULL, '937729b5e3bbaa5f4f7be108194bb1bd4723ee72ebf843b6bc93fe1aed8cbcae', '155');
INSERT INTO `worker` VALUES (156, '陈怡婷', '男', '33', '', 'zhangxiaojie@gmail.com', '广东省广州市', '英国爱丁堡大学', '硕士', 7, '群众', NULL, NULL, '4b9ba20cad81f2616a9a050770ac095e0c2bb106f9eddfeed707878a5a7d9fb1', '156');
INSERT INTO `worker` VALUES (157, '阮晴桦', '女', '23', '', 'xiaochen@qq.com', '河北省唐山市古冶区', '浙江传媒学院', '本科', 8, '团员', NULL, NULL, 'b0473e781215e35add6f590382c43255ac7ceb1eab74535181d9fc907e5165f8', '157');
INSERT INTO `worker` VALUES (158, '林孟富', '男', '26', '', 'viv2010@163.com', '', '中央民族大学', '本科', 7, '群众', NULL, NULL, '591f6bafc0028f65ced10e5604727dc5bcb7f7ac008125cea2be1aa17da8f80b', '158');
INSERT INTO `worker` VALUES (159, '刘美', '男', '30', '18888888808', '868898999@qq.com', '', '大学应用英语A1级', '本科', 3, '群众', NULL, NULL, 'e60466a9e4d2d5f8e1ae5a3e8d37ca8df419686e0e035b6f88caeca677bef039', '159');
INSERT INTO `worker` VALUES (160, '金蝶', '女', '32', '', '123456789@qq.com', '浙江省', '中国美术学院', '大专', 4, '党员', NULL, NULL, '939bdd396f93750e247006140ccf7648aad86c8ac923b4f6f3036458a7780646', '160');
INSERT INTO `worker` VALUES (161, '白凯修', '男', '29', '12345678900', '**@163.com', '', '高级中学教师资格证', '本科', 9, '群众', NULL, NULL, '7ef8edd46a07125a5bc4b34c132936a7135e0efd2260ce395509fa46fcd75522', '161');
INSERT INTO `worker` VALUES (162, '黄蓉芳', '女', '26', '13808138036', 'huangrongfang@qq.com', '广东省广州市海珠区', '阳江职业学院', '大专', 9, '党员', NULL, NULL, '2f1d254c4e64b40caeca9dce766a2dc2e69af98549a51e50171a379a2f3823d5', '162');
INSERT INTO `worker` VALUES (163, '赵吟琪', '男', '32', '13800138000', 'zhaoyinqi@qq.com', '广东省广州市海珠区', '沧州工贸学校', '中专', 4, '党员', NULL, NULL, 'e023c04ce2feb10d76a6ac24e935f43f32ef8b6904a4a1478938d26ab896616e', '163');
INSERT INTO `worker` VALUES (164, '陈嘉惠', '男', '29', '13588888888', 'service@500d.me', '深圳', '深圳职业学院', '大专', 3, '党员', NULL, NULL, '16a949f89374a787fa48c123099c22b46ccba907248c7d8494329ae191f64c5b', '164');
INSERT INTO `worker` VALUES (165, '吴惠劲', '男', '28', '1888008000', 'service@500d.me', '上海市', '中山大学附属第三医院', '大专', 7, '群众', NULL, NULL, '31d43f384553b58df1b18fb7bc6d8058636b00998e69e635740881cc5fab3c6a', '165');
INSERT INTO `worker` VALUES (166, '谢健铭', '男', '29', '13800008888', 'service@500d,me', '广东广州', '江苏建筑职业技术学院', '大专', 9, '党员', NULL, NULL, '3c64d6f8519ffdcb7a6be12b36432a8c8864c5217806bd1f9c9a9a0e90ec798f', '166');
INSERT INTO `worker` VALUES (167, '林怡婷', '男', '24', '13822138221', 'xiazhihao@qq.com', '广东省广州市海珠区', '广东邮电职业技术学院', '大专', 5, '群众', NULL, NULL, 'ffe5f8e451e16b5ca53495c37f7b60cdb7f56f0555d5a9be7b90e4aa8c4cbbf1', '167');
INSERT INTO `worker` VALUES (168, '廖佳蓉', '男', '29', '13823138023', 'nesson@91muban.cn', '广东省广州市海珠区', '广东建设职业技术学院', '大专', 10, '群众', NULL, NULL, '40d2d6aff9813f1848c8a9258820cd002fb0aba8098bcad72f52005ccd0a535f', '168');
INSERT INTO `worker` VALUES (169, '李佩', '男', '32', '188888000', 'service@500d.me', '上海市', '清远职业技术学院', '大专', 9, '党员', NULL, NULL, '358e9a0498670b3d3b10547b981fa4637c41933a8cf9523fb92c996e807c1f3f', '169');
INSERT INTO `worker` VALUES (170, '何甄', '男', '24', '', 'service@500d.me', '上海', '中专', '中专', 5, '群众', NULL, NULL, 'ea3bd5bce53d673c72afbfffaf2ba919a8887b5c108bd5bc5da7d0261689f4df', '170');
INSERT INTO `worker` VALUES (171, '谢晓玲', '男', '26', '0011', 'office@microsoft.com', '', '中专', '中专', 0, '群众', NULL, NULL, '60fa2f2054bc480e6c2cd304aef03e87ed5c8e926aaf6a242e05901c7bd7d026', '171');
INSERT INTO `worker` VALUES (172, '李礼娇', '男', '28', '13122345678', 'lilijiao@qq.com', '广东省广州市', '', '本科', 7, '群众', NULL, NULL, '35e59839eacb590677206d4a50aeed31c8894dc2f117ab5961f59d3485e09a53', '172');
INSERT INTO `worker` VALUES (173, '沈阳市', '男', '29', '13111234455', 'liyixiao@qq.com', '上海', '', '本科', 7, '群众', NULL, NULL, '1895a6565ed3ad4d83b6ff540f293abc3c80f97b237b9a5f6bc3f98782c1b452', '173');
INSERT INTO `worker` VALUES (174, '黄静雯', '男', '22', '13112344321', 'hjw@qq.com', '上海市浦东新区', '上海财经大学', '本科', 11, '群众', NULL, NULL, '1ab3d08e63b8abbf59225017ce42670101cc62119f49c7076b20b6e3733b50eb', '174');
INSERT INTO `worker` VALUES (175, '背景', '男', '30', '13522334567', 'chenchunbao@qq.com', '', '', '本科', 0, '群众', NULL, NULL, '5d4eb6e2873b27fbb6c912e8abd75419b7ff3f1cd79cefd3a7110d161c5020c2', '175');
INSERT INTO `worker` VALUES (176, '李文育', '女', '27', '13112344321', 'liwenyu@qq.com', '广东省广州市', '湖北工业大学', '本科', 6, '群众', NULL, NULL, '70a8f040d3a2ae12ae7525dd68726c5b60fa428519833454a8da9c0cfb73387b', '176');
INSERT INTO `worker` VALUES (177, '林佳蓉', '男', '23', '', 'linjiarong@qq. com', '', '上海南湖职业技术学院', '大专', 7, '群众', NULL, NULL, '1089a89754d46a749d794c2ca60f8dbacfea415d5b888c65cfc575048e2c6dcf', '177');
INSERT INTO `worker` VALUES (178, '罗依茂', '男', '29', '13112233445', 'luoyimao@qq.com', '上海市浦东新区', '苏州工艺美术职业技术学院', '大专', 12, '群众', NULL, NULL, '83e13275b1e073788ce5afefd6aeede35be7d25ce0ae78baa80f5cd697621eb9', '178');
INSERT INTO `worker` VALUES (179, '李淑佩', '男', '24', '2', 'luoyimao@qq.com', '', '无锡职业技术学院', '中专', 9, '群众', NULL, NULL, '1fd7808332ec8bb11fa7dd3e40fc3a294f0f3bd4c81fa2bed5ccb9e7042fd652', '179');
INSERT INTO `worker` VALUES (180, '谢怡君', '男', '26', '通过网络及电话咨询并收集各行各业的潜在商户信息，并分析其合作潜力，协助部门经', 'luoyimao@qq.com', '', '北京大学', '本科', 8, '群众', NULL, NULL, 'f3f94d908439bb14ff4cfa95132069f1b308c5597fc3c85488cd809c61d3fea7', '180');
INSERT INTO `worker` VALUES (181, '王美玲', '男', '31', '13500135000', 'wangmeiling@qq.com', '广东省广州市海珠区滨江东路', '上海复旦大学', '本科', 10, '党员', NULL, NULL, '69e6308e7695cde13ab02e4faf39aae0caa2234be8f9878177982fe5d75ce963', '181');
INSERT INTO `worker` VALUES (182, '黄慧学', '男', '30', '15123456789', 'huanghuiyu@qq.com', '广东深圳', '清华大学', '硕士', 4, '党员', NULL, NULL, '3b9c94073a2be626e12f5988cf32ea4c1b215d3ccd2d0069995d3abb58628a2f', '182');
INSERT INTO `worker` VALUES (183, '邓幸韵', '男', '30', '13800138080', 'dengxingyun@qq.com', '广东省广州市', '西南大学', '本科', 4, '团员', NULL, NULL, 'ebd0f8e375f718c2dc820887553edfc31359e08d6c2701e04aa942261f3dab4d', '183');
INSERT INTO `worker` VALUES (184, '陈秀', '男', '25', '13800138000', 'Chenxiu@163.com', '', '北京师范大学', '本科', 13, '群众', NULL, NULL, '2581c9c7d8980b0e05dcd5636db7678f2ea89fddd3768adaee61ffdc5e6282f7', '184');
INSERT INTO `worker` VALUES (185, '许平', '男', '34', '13500135000', 'Service@500d.me', '广东省广州市', '广东金融学院', '本科', 8, '群众', NULL, NULL, '1664872711f0b36ff9bd0d07d40deb580c337d079cdc8ff88586e8a492497549', '185');
INSERT INTO `worker` VALUES (186, '许爱礼', '男', '31', '13111223344', 'xuaili@qq.com', '上海市浦东新区', '上海工艺美术职业学院', '大专', 9, '群众', NULL, NULL, '33aaa4dbd155c8e89cdffd560861e82ce468caa47b5a58e894bbf73364e6ebd8', '186');
INSERT INTO `worker` VALUES (187, '谢一忠', '男', '31', '13888888888', '888pic.com', '上海', '北京大学', '', 9, '群众', NULL, NULL, '09d1e48ac8df53a205d946e3386ba5be5ed506113126e798b0c75bda9c14b5be', '187');
INSERT INTO `worker` VALUES (188, '简志雪', '男', '30', '13112344567', 'jianzhixue@qq.com', '上海市浦东新区', '上海南湖职业技术学院', '大专', 7, '群众', NULL, NULL, 'e1399726e24cf3de75645a67d7161e81e9231ab6b9b4ca787af53e9b54617931', '188');
INSERT INTO `worker` VALUES (189, '赵若喜', '女', '28', '1308310002', '456481343@qq.com', '广东省广州市', '', '本科', 5, '群众', NULL, NULL, 'b2e9c15e92414108e8fba889c9e622b93910db1474c2f182f435a7f3b6ce4d35', '189');
INSERT INTO `worker` VALUES (190, '许承翰', '男', '23', '>负责手机客户端产品GUI的整体风格设计，应用工具的相关菜单', '24546326@163.com', '湖南省长沙市', '', '大专', 7, '群众', NULL, NULL, 'e3bcc299dc02e1b522708c7db58d1bb3af3e3c61f9772e56bbc2c22913e994da', '190');
INSERT INTO `worker` VALUES (191, '姚哲维', '男', '22', '18800135000', '24546326@163.com', '广东省广州市', '', '本科', 7, '群众', NULL, NULL, 'ff1a5a65896ec6e46851b5aa1f617e54c9e0aa4b60477c0188f7897960c9c8b5', '191');
INSERT INTO `worker` VALUES (192, '苏俊安', '男', '26', '', '24546326@163.com', '广东省广州市', '广州番禺职业技术学院', '大专', 4, '群众', NULL, NULL, 'b9a478e23bf5933f0fa4ef8d9cc929145f14c3d34afacbe74b5c16287a4c3748', '192');
INSERT INTO `worker` VALUES (193, '郭礼钰', '男', '29', '13588888888', 'service@500d.me', '江西省南昌市', '', '大专', 5, '党员', NULL, NULL, 'adc02a1326cc4f2c2314f9e90123d0bf3f4385e1ec53a0dc8188c7f0e8bcec29', '193');
INSERT INTO `worker` VALUES (194, '姜佩珊', '男', '31', '13500135000', 'Service@500d.me', '广东省广州市', '广州市信息技术职业学校', '中专', 3, '群众', NULL, NULL, '8457e5db72358f66e2daa30e8b672fb1e01780e065fb7b71f6aa78b0057d808f', '194');
INSERT INTO `worker` VALUES (195, '张鸿信', '男', '27', '13912345678', '13912@163.com', '北京', '中专', '中专', 4, '群众', NULL, NULL, '077b9fea8b74acc2aa452f14b98a7e0f87737e940c795ce68fb648176f7bd504', '195');
INSERT INTO `worker` VALUES (196, '秦欣瑜', '男', '32', '', '13912@163.com', '', '中山大学', '博士', 15, '群众', NULL, NULL, '3b5e2b7c53c415fc3a49084707732ce09c05b3355a94fddc74dc03bc603035dc', '196');
INSERT INTO `worker` VALUES (197, '李旺劲', '男', '29', '13512344321', 'liwangjing@qq.com', '赴江苏省图书馆志愿者服务', '上海燎原中等专业学校', '中专', 9, '团员', NULL, NULL, 'eccf5df292e481325b71a81974f6939d7375dc92cc02866e9431b8e5acb79b7a', '197');
INSERT INTO `worker` VALUES (198, '吴惠美', '男', '26', '13912345678', 'you@hotmail.com', '山东', '', '本科', 2, '群众', NULL, NULL, '459b48ea7353599cf2ef98f0f01d791079e21167890c10a82d2e6fdee603446e', '198');
INSERT INTO `worker` VALUES (199, '陈秀德', '男', '29', '', 'you@hotmail.com', '广东省广州市', '', '大专', 4, '群众', NULL, NULL, '4effe453d1c2db03b62b8ad61e1e462fa55766160acda22cc170f28a7bb975af', '199');
INSERT INTO `worker` VALUES (200, '张佳伶', '男', '28', '13788886666', 'service@500d.me', '黑龙江省牡丹江市', '牡丹江大学', '大专', 0, '群众', NULL, NULL, 'db4ff9a75cf7738552f747b0fbcb562aee4eaabc9b4fe1b0e4fed19a09c02a49', '200');
INSERT INTO `worker` VALUES (201, '郑凯婷', '男', '33', '18888886666', 'service@500d.me', '', '广东松山职业技术学院', '大专', 15, '群众', NULL, NULL, '75c68c3860f7e10fe7229dda59493b6fc34e472e10ac2bcefec6f738ab56042b', '201');
INSERT INTO `worker` VALUES (202, '郑雅仁', '男', '23', '13912345678', 'xianxian@taobao.com', '上海', '中专', '中专', 8, '群众', NULL, NULL, '6834a0755f6a7491b951914389b8430c937a088df642da60c89fbd28d04a9496', '202');
INSERT INTO `worker` VALUES (203, '黄姝', '男', '23', '13511223344', '12343345@qq.com', '', '湖南工商大学', '硕士', 3, '群众', NULL, NULL, '2c5bab05f74418c43f71afca53d65872e84a700acc2c5309b26a8206e0ca0b79', '203');
INSERT INTO `worker` VALUES (204, '林芳江', '男', '32', '13999999999', '1234567@123.com', '上海', '中专', '中专', 6, '群众', NULL, NULL, '665737cf6ce9db9f22a03104aea22e0c1e7e3981227eaa284ef05d4d39be8b36', '204');
INSERT INTO `worker` VALUES (205, '江骏生', '男', '30', '', '1234567@123.com', '', '重庆科技学院', '本科', 8, '群众', NULL, NULL, '06fcb15eb7cd95a2b624b15185243437ad99777a5fbd95064d441d466b0b8daf', '205');
INSERT INTO `worker` VALUES (206, '黄儒纯', '男', '24', '13122334455', '12345678@qq.com', '', '上海城建职业学院', '大专', 10, '群众', NULL, NULL, '533ef3d02b9735c5b10dbbbbb4b277a0a01de500196f8cd96b36405aab0165c7', '206');
INSERT INTO `worker` VALUES (207, '王培伦', '男', '23', '13912345678', 'Yourname@163. com', '河南', '中专', '中专', 13, '群众', NULL, NULL, '4676e5a0815df1dc407dc73cb5427e9828ee6c74b70e3830aa92a595e08d50c2', '207');
INSERT INTO `worker` VALUES (208, '陈蕙纶', '男', '32', '13500135000', 'service@500d.me', '广东佛山', '广东金融学院', '本科', 6, '党员', NULL, NULL, '2b2347dbda889408f55566a10bb7d3f8ae351aae4af8c5a72be371d0bfdf28f2', '208');
INSERT INTO `worker` VALUES (209, '蔡宜', '男', '26', '13144556677', '1311123456@qq.com', '湖北省武汉市', '', '本科', 0, '群众', NULL, NULL, '0c50e815a5d1ce3a825985df2bd6ab8cc89581bf4cf12ba2c3256fdbc080b169', '209');
INSERT INTO `worker` VALUES (210, '陈信意', '女', '28', '1888888000', 'chenxinyi@qq.com', '上海市', '上海商学院', '本科', 7, '党员', NULL, NULL, '40d65380a913d100995e4fc08ba6e3de829a93e43e1314c36a429795ce4bffb4', '210');
INSERT INTO `worker` VALUES (211, '陈惠雯', '男', '23', '13112344321', 'chenxinyi@qq.com', '', '上海师范大学', '', 8, '群众', NULL, NULL, '857fc6b47c795017e0920ac4880e9fbbe9788e856d27b8f4654542048829c77e', '211');
INSERT INTO `worker` VALUES (212, '张秀', '男', '23', '13912345678', 'Zhangxiu@123.com', '山东', '高中', '高中', 6, '群众', NULL, NULL, 'c9e270c7185b4905425165155d5b11674635edec9a7249c2347495cd8589eecb', '212');
INSERT INTO `worker` VALUES (213, '黄碧仪', '男', '30', '13822334455', '17818322267@qq.com', '广东省广州市', '广州市第二中学', '', 8, '群众', NULL, NULL, '75cef4ddbeb60621a782bf21e30ab32a73256d4ed3a66f87616490e67b9ae7d1', '213');
INSERT INTO `worker` VALUES (214, '陈志文', '女', '33', '18233445566', 'Chenzhiwen@qq.com', '', '华中科技大学', '本科', 12, '群众', NULL, NULL, '300b25b763d99bf56537e3da16208ba4c4addb36fa1f020be8be7641bba5c675', '214');
INSERT INTO `worker` VALUES (215, '谢懿富', '男', '30', '熟练运用Microsoft Office (ppt/excel/word)办公软件、 Premiere、 Photoshop等专业视', 'Chenzhiwen@qq.com', '', '中国政法大学学生会', '', 7, '团员', NULL, NULL, 'd36a5beff350795485e28ca367f6d4d8595d10ed765ae3f3b6a1c4ac32ccdc96', '215');
INSERT INTO `worker` VALUES (216, '杨凡靖', '男', '24', '', '123456789@qq.com', '', '中央美术学院', '本科', 8, '群众', NULL, NULL, '977b8efd63d3973686907bc0b640beb34d955c7a09ad065e5f6aa849947914a7', '216');
INSERT INTO `worker` VALUES (217, '蔡秀琴', '男', '28', '13444332211', '123456789@qq.com', '上海', '上海财经大学', '本科', 0, '群众', NULL, NULL, '9b136c173775259a7425cc25ba47573290f815284796def8646c1d0e7334f2d5', '217');
INSERT INTO `worker` VALUES (218, '温惠玲', '男', '32', '13122334455', 'wenhuiling@139.com', '上海市浦东新', '江苏科技大学', '本科', 10, '群众', NULL, NULL, '268d305984cb36706db20fe27ac862fb2a3ff26b272bf474deee43352dc5cb7f', '218');
INSERT INTO `worker` VALUES (219, '林宗其', '男', '24', '', '123456789@qq.com', '', '中国社会科学院大学', '本科', 7, '群众', NULL, NULL, '9f95eefc797bb1d348bbd3c75c64aa4fca2a116d615a0e9e2392ccfbc61e7161', '219');
INSERT INTO `worker` VALUES (220, '林绍泰', '男', '27', '13324567890', '1234567@qq.com', '', '湖北大学', '本科', 10, '团员', NULL, NULL, 'f9cae6ae5865cc5399ae88ac68606931c17acbec433d0c55e908826c1cd3cdbe', '220');
INSERT INTO `worker` VALUES (221, '蔡辰纶', '男', '29', '·接听电话、接待来访人员、安排会议工作，负责会议纪要', '·出入库工作，各类公文、信件、邮件、传真的分发和登记。', '', '西安交通大学', '本科', 6, '党员', NULL, NULL, '69b4031d678921ef14b365ff75bfd750da729861682696b679deb6e3efbefcdf', '221');
INSERT INTO `worker` VALUES (222, '王雅雯', '男', '28', '13111223344', 'wangyawen@139.com', '上海市浦东新区', '吉林大学', '本科', 6, '群众', NULL, NULL, '019ed2615e2e27235677126bbcf37422c13be7c0cddabe9ba9468042ef3d20cb', '222');
INSERT INTO `worker` VALUES (223, '黄丽昆', '男', '29', '18122223344', '1.负责公司日常行政管理的运作（运送安排、邮件和固定的供给等）；', '', '华南理工大学', '本科', 6, '团员', NULL, NULL, 'c26002fbd04d946b8dba3be73420c1da81da14bcbe37d0b8d420e250eaa06678', '223');
INSERT INTO `worker` VALUES (224, '李育泉', '男', '32', '', '1.负责公司日常行政管理的运作（运送安排、邮件和固定的供给等）；', '', '湖北工业大学', '', 6, '团员', NULL, NULL, '7b0cf8dd14927bf86ed7c00f0118cc128b6e889f960e6e2045dc936c08b0df28', '224');
INSERT INTO `worker` VALUES (225, '黄芸欢', '男', '26', '15877665544', '1233344@139.com', '深圳', '广西科技大学', '本科', 7, '党员', NULL, NULL, '0e629e599875fe3f855a53971110de7addf1ccd49f028a86e8827662fb5423f6', '225');
INSERT INTO `worker` VALUES (226, '吴韵如', '男', '22', '18022335252', '1456789@qq.com', '', '学院青年志愿者协会财务部', '本科', 6, '群众', NULL, NULL, '4fca28dd24a60d657c84d0d24d99ec51f5c10bb85d08f9085fc17bab6d0ab583', '226');
INSERT INTO `worker` VALUES (227, '李肇芬', '男', '29', '', '123454321@qq.com', '', '江南大学院学生会', '本科', 4, '群众', NULL, NULL, '39c170da0c4a397aaf491cccda3ead129b135edafd97d5f8b0560ebdfa270943', '227');
INSERT INTO `worker` VALUES (228, '卢木仲', '男', '27', '13112345678', '2233445@qq.com', '上海市浦东新区', '上海大学', '本科', 7, '群众', NULL, NULL, '898ffe8e4eb7e13602c25c6ac6a1ea28c6b847d8146358b42e00ba22faa2a2da', '228');
INSERT INTO `worker` VALUES (229, '李成白', '女', '24', '1582233455', '136567899@qq.com', '广州', '华南师范大学', '硕士', 15, '群众', NULL, NULL, '11eb57cc784ce529e76600a264e7de9b50f0b85387138269007758ba614f4c81', '229');
INSERT INTO `worker` VALUES (230, '方兆玉', '男', '22', '13800138000', '44332256@qq126.com', '', '上海东华大学', '本科', 7, '群众', NULL, NULL, '5c82ad0faab70d4bfadddc6f6d056ba23ae3f822981f456a6a36d1aa570ba0a9', '230');
INSERT INTO `worker` VALUES (231, '刘翊惠', '男', '23', '20', '15678965@qq.com', '上海市浦东', '上海工艺美术职业学院', '大专', 10, '群众', NULL, NULL, '4fc38309fc53b509ae53b7b6d51494d5f7efcf617124811ab59a90c4f774fd88', '231');
INSERT INTO `worker` VALUES (232, '丁汉臻', '男', '32', '13244556677', '15678965@qq.com', '', '上海海事大学', '硕士', 7, '群众', NULL, NULL, 'fa1a0f1569451f84845f57ef2840157790308283937622479689c72e433059ce', '232');
INSERT INTO `worker` VALUES (233, '吴佳瑞', '男', '26', '', '12345678@qq.com', '', '广州财经大学', '本科', 5, '群众', NULL, NULL, 'd5f905cd4a116659f99dd4b0659898b707bfc76eb4d45d7cfb4fdb778c5fc47e', '233');
INSERT INTO `worker` VALUES (234, '舒现', '男', '27', '13344556677', 'shuxian@163.com', '', '大学期间', '本科', 7, '群众', NULL, NULL, 'ab1fcb7d24e4aacd30125bc3e2119b9e76504bc9c9ef6f864f5ecc4a7a1a7ab0', '234');
INSERT INTO `worker` VALUES (235, '周白芷', '男', '27', '13122343344', 'zhoubaizhi@139.com', '', '上海理工大学', '本科', 6, '群众', NULL, NULL, 'b97254207be03be5562004657adb93bd54f15ee1b0b52382f0c95d7ffd848084', '235');
INSERT INTO `worker` VALUES (236, '张姿好', '男', '27', '13533445566', 'zhangzihao@139.com', '', '南京艺术学院', '本科', 7, '群众', NULL, NULL, '0eee621a8a63569dd72537b6049836c926bf2a680ca0a68be273f9ca8ef35292', '236');
INSERT INTO `worker` VALUES (237, '张虹伦', '男', '28', '0013', 'zhonghonglun@139.com', '天津', '天津大学', '硕士', 12, '党员', NULL, NULL, '0b16718ef2e10edb1064297bf24bcd6443f4500524c2751f455d85cb8202f32b', '237');
INSERT INTO `worker` VALUES (238, '周琼玫', '男', '33', '13134566543', '1234@ibaotu.com', '', '河北大学', '本科', 6, '群众', NULL, NULL, 'ec683a8e261d983209fa81a32a7c7303b20f868755eee35d82a9a347be8b3390', '238');
INSERT INTO `worker` VALUES (239, '倪怡芳', '男', '29', '012123456789', '123456@139.com', '', '广东第二师范学院', '本科', 4, '群众', NULL, NULL, 'fb301e3e8b49d094fc00e47778bb131945b7aca57cef8ada789c95ad0cb2aa52', '239');
INSERT INTO `worker` VALUES (240, '郭佩芳', '女', '28', '13522334567', 'guopeifang@139.com', '成都', '西华大学', '本科', 8, '群众', NULL, NULL, '844160d8e3c9dd7c0998ad9e22f2469e64f77aca128c4a29bd83dc59c351deec', '240');
INSERT INTO `worker` VALUES (241, '黄文旺', '男', '26', '13588888888', 'huangwenwang@139.com', '江西', '江西财经大学职业发展社', '本科', 8, '党员', NULL, NULL, '00dc93f90131356fd154d6e20a5af8370f8339f1d16d11c6ff0ff5c031dc1af4', '241');
INSERT INTO `worker` VALUES (242, '郑丽青', '男', '26', '13588888888', '123346372@qq.me', '广东广州', '广东工业大学硕士', '硕士', 12, '党员', NULL, NULL, '9f351764b9a0bd32258ba54bc2f7b3d29c28aef4c17844a564e03e43c7f0d721', '242');
INSERT INTO `worker` VALUES (243, '许智云', '男', '34', '13500135000', 'xuzhiuyun@163.com', '广东省广州市', '华南理工大学-本科', '本科', 6, '群众', NULL, NULL, 'ade81f87d0661d144c63ad53f9d5badcd53906f4e42b20d2c3ac5361fc837b1a', '243');
INSERT INTO `worker` VALUES (244, '张孟涵', '女', '27', '13999999999', '2345768@qq.com', '籍贯', '大学期间', '', 2, '群众', NULL, NULL, '40644ae94d0af1565718eeef4479cf8754cb713083075cf6530320fe81c093f8', '244');
INSERT INTO `worker` VALUES (245, '李小爱', '男', '25', '13156788765', '21384795@qq.com', '', '浙江传媒学院', '本科', 3, '群众', NULL, NULL, 'dc57a9c309cd024e1d0f8ace5d9adf289d1be833ef92b580e36bf95663ffbfb6', '245');
INSERT INTO `worker` VALUES (246, '王恩龙', '男', '27', '13112344321', 'wangenlong@139.com', '浙江宁波', '宁波大学', '本科', 7, '群众', NULL, NULL, '7a74516304ebc6e522b180f7d67bcbd99959f6a8f39031b8b892434b509c4238', '246');
INSERT INTO `worker` VALUES (247, '朱政廷', '男', '32', '13512344321', '83317396@qq.com', '广东省珠海市', '深圳技术大学', '本科', 9, '群众', NULL, NULL, '414e06a73679314b8bbcbaeea907546cc5b408c44f07289f7f7ece4fbf0c2ff1', '247');
INSERT INTO `worker` VALUES (248, '邓诗涵', '男', '26', '13554322345', '83317396@qq.com', '广东省珠海市', '南方科技大学', '本科', 7, '群众', NULL, NULL, 'f848d0d47f91a487922e095849b7a06cea8030a7c84aaadf4062a9de90f8e867', '248');
INSERT INTO `worker` VALUES (249, '黄盛玫', '男', '25', '18833445566', '83317396@qq.com', '', '', '硕士', 3, '群众', NULL, NULL, '8008822306a582065a7ca47f0b0186d69f17d93573195ad2b42de749d973bdb5', '249');
INSERT INTO `worker` VALUES (250, '陈政倩', '男', '33', '', '18666@qq.com', '', '学院青年志愿者协会财务部', '本科', 9, '群众', NULL, NULL, '739fa18d270f32a8dd551f5f40d685dd7489b7aa2149ca0b61d79d8a8a30d237', '250');
INSERT INTO `worker` VALUES (251, '吴俊伯', '男', '33', '', '12306@qq.com', '湖北武汉', '湖北中医药大学学生会', '本科', 7, '党员', NULL, NULL, 'e1bfb0e12c6c313f70baa0b407712fa89a5e79795040bdc2edb2f546cc824f90', '251');
INSERT INTO `worker` VALUES (252, '阮馨学', '男', '31', '18899998888', 'ruanxinxue@163.com', '', '大学期间', '硕士', 8, '群众', NULL, NULL, '27c6b96a5c77a7728ddfe4beb1815da362e56996e785729fa871b18d358ae6df', '252');
INSERT INTO `worker` VALUES (253, '翁惠珠', '男', '28', '', '12306@qq.com', '上海', '上海中医药大学学生会', '本科', 7, '党员', NULL, NULL, '5e4cfab4b92e15f1c93cf9b7dff4696607c36e8977b2cf9188ad26b9bde7f670', '253');
INSERT INTO `worker` VALUES (254, '吴思翰', '男', '24', '13533445678', '123456@qq.com', '', '上海对外经贸大学', '本科', 4, '群众', NULL, NULL, '268669cf48d839d9e79f4dec9536c19313f6851bb5649deee4199a8259cf1253', '254');
INSERT INTO `worker` VALUES (255, '林佩玲', '男', '25', '6655', 'Linpeilin@163.com', '', '北京青年政治学院', '大专', 5, '群众', NULL, NULL, '8e63e88210c929492a805a7a4e72fcc18e872d3d01eba267036fb5d48ce66ded', '255');
INSERT INTO `worker` VALUES (256, '邓海来', '男', '28', '写以及线下联系各单位工作。', ' 1345888@qq. com', '', '安徽工业大学', '本科', 6, '群众', NULL, NULL, '5695821bd8d14b804aafa09b0d81d8741230cc17da05ec20df8b9eb50e8c00ca', '256');
INSERT INTO `worker` VALUES (257, '陈翊依', '男', '24', '18045678090', '3543637@qq.com', '', '湖北工业大学', '本科', 5, '群众', NULL, NULL, '65c72f3332d8b97c5b8c9f2cd8b37553817e214f060b0eee9d14f101504bd9ca', '257');
INSERT INTO `worker` VALUES (258, '李建智', '男', '30', '以及线下联系各单位工作。', '3453468@qq.com', '', '', '本科', 7, '群众', NULL, NULL, '7a72ae7b75570c7d212d725113859ba7a5df7b0cdec4572ff043ac271e3162e8', '258');
INSERT INTO `worker` VALUES (259, '张仪湖', '男', '27', '17056787070', '5674587@qq.com', '', '学院青年志愿者协会财务部', '本科', 6, '群众', NULL, NULL, '1c20429d3a96b4c0875913ec0802b39039ed809696807deeb9e0ed5319a066f7', '259');
INSERT INTO `worker` VALUES (260, '王俊民', '男', '29', '13134568899', '2452626@qq.com', '', '天津师范大学', '本科', 4, '群众', NULL, NULL, '5c84fd870946ccb3d85cee7c1b68521c5a9c81440273acc7e05d1384326b1f0f', '260');
INSERT INTO `worker` VALUES (261, '张诗刚', '男', '24', '13134567890', '4365364@qq.com', '', '海南大学老乡会', '本科', 3, '群众', NULL, NULL, '7c5abc299773b521159cf4ce459b18663ec68e4f94c0e921190d6cd0f24ed15f', '261');
INSERT INTO `worker` VALUES (262, '林慧颖', '男', '31', '13645676655', '4365364@qq.com', '', '广东财经大学', '本科', 7, '群众', NULL, NULL, 'cd5bede10476abc3b48057f7af01d744bd52257002544e3b6aad9b0d6d0b0119', '262');
INSERT INTO `worker` VALUES (263, '沈俊君', '男', '30', '13405678901', ' 24234543@qq.com', '河南', '', '', 1, '群众', NULL, NULL, '66abba695be08c2d98fb24d4e61ebb971b3152f02b11461f4c00d28918fd978d', '263');
INSERT INTO `worker` VALUES (264, '武淑芬', '男', '25', '13123456789', '43252345@qq.com', '广东省广州市', '', '本科', 3, '群众', NULL, NULL, 'ec48400ba76e80a2222a9d135ba141a0c4e8538f740e347af62556dd79a1f411', '264');
INSERT INTO `worker` VALUES (265, '金雅琪', '男', '28', '13133445566', '3456436@qq.com', '山西太原', '', '本科', 7, '群众', NULL, NULL, 'd3a744ea5de5a11e23916b5d5783691d574f052ab5f3229a893477c22e769736', '265');
INSERT INTO `worker` VALUES (266, '赖怡宜', '男', '26', '13564356789', '3456436@qq.com', '', '吉林财经大学', '本科', 7, '群众', NULL, NULL, '8f2f0b7a4d0527504499b1220ebaae26786a0172108390c1793794a580c83f5f', '266');
INSERT INTO `worker` VALUES (267, '李姿伶', '男', '23', '13455667788', '15634287@qq.com', '', '肯德基学院店', '本科', 6, '群众', NULL, NULL, '692071bbf56e3a7cc200eadccc8dc789218dedf6afee70b9d90c85e442591ef9', '267');
INSERT INTO `worker` VALUES (268, '康复学', '男', '28', '13156782345', '43125234@qq.com', '广州', '广州医科大学', '本科', 6, '群众', NULL, NULL, '052721d777f8fbe0c24f543fbe8c7fc7d33af1be783108f8483443f1deea74bf', '268');
INSERT INTO `worker` VALUES (269, '陈淑好', '男', '27', '15857685678', '1428364@qq.com', '', '', '本科', 5, '群众', NULL, NULL, 'c1f7f0274fb3c094fbff583c47eea5e7260c479b2becc548e8b54b4e6cee35d5', '269');
INSERT INTO `worker` VALUES (270, '高咏钰', '男', '23', '', '4325653486@qq.com', '上海', '', '本科', 0, '群众', NULL, NULL, '842e8f40820534a3165f762ce0e4781d931a1d7162b077cd534f9259e48bed96', '270');
INSERT INTO `worker` VALUES (271, '黄彦宜', '男', '31', '13134256789', 'huangyanyi@139.com', '', '承德医学院', '本科', 6, '群众', NULL, NULL, 'c06af5b1fa26d48d195c37ae3145053088af4c968c24d8907f2a2cf67c89daa7', '271');
INSERT INTO `worker` VALUES (272, '周孟儒', '男', '26', '13127364859', '36473829@qq.com', '', '', '本科', 8, '群众', NULL, NULL, '59478fabf79a6ade588ac26ed53c6e559e5d019b5332f2214cd185439476ba36', '272');
INSERT INTO `worker` VALUES (273, '潘欣臻', '男', '29', '13118857649', '54654743@qq.com', '广东省广州市', '', '大专', 0, '群众', NULL, NULL, '6e060adc591fa0e52a2e31bf9eb6bccdeb15bd125c15d08e296a20731e0bd6f6', '273');
INSERT INTO `worker` VALUES (274, '李祯韵', '男', '26', '13125364758', '15364758@qq.com', '广东省广州市', '东莞理工学院', '本科', 2, '群众', NULL, NULL, '2fd7be33416d5ce6344cb0080af657c5c7712ac90e0a164dc4ebd12c5efaf456', '274');
INSERT INTO `worker` VALUES (275, '叶洁', '男', '24', '13126475839', '15364758@qq.com', '广东省梅州市', '嘉应学院', '', 8, '群众', NULL, NULL, '1443818a382c4ce778e6e98a970f638f7ed1ace780602bb222be72952f247dd2', '275');
INSERT INTO `worker` VALUES (276, '梁哲宇', '男', '23', '13135462718', '364758392@qq.com', '广东省广州市', '五邑大学', '本科', 10, '群众', NULL, NULL, '8576d743f55198fdd65998afceeb2dec2aae3898acf96cb88373c19c05cb8a3c', '276');
INSERT INTO `worker` VALUES (277, '黄晓萍', '男', '28', '13185746352', '42362626@qq.com', '', '西南大学', '本科', 8, '群众', NULL, NULL, '0a53cab49ed036e638e8b16c2178d0357f42d4831c7a1eaaf8aca554b66155bb', '277');
INSERT INTO `worker` VALUES (278, '杨雅萍', '男', '27', '13137482910', 'yangyaping@139.com', '广东省广州市', '广西科技师范学院', '', 14, '群众', NULL, NULL, '9bc87ed1da8aad92e8e34e4de995826dd1440487ee82a9ce761bb6b6946dbc2a', '278');
INSERT INTO `worker` VALUES (279, '卢志铭', '男', '30', '13184736482', 'Luzhiming@163.com', '广西省南宁市', '', '本科', 7, '群众', NULL, NULL, 'ab2555c9384ad724eba6ee461e7fdc009935afd393190d251dc0fefe0e3d3a11', '279');
INSERT INTO `worker` VALUES (280, '张茂以', '男', '28', '13145362718', '364758291@qq.com', '', '', '本科', 6, '群众', NULL, NULL, '41fc3ba21043cecc15da9e8fafe56f61d4a9a4e231c94ffe12cdd3184b44dbb3', '280');
INSERT INTO `worker` VALUES (281, '林婉婷', '男', '27', '13164537281', '364758291@qq.com', '', '范大学“军训先进个人', '本科', 6, '群众', NULL, NULL, '9b7140d23d1fd8941c7bc681c58b701833c0f02b562eea390851d5f31a294cf9', '281');
INSERT INTO `worker` VALUES (282, '蔡宜芸', '女', '24', '18275849320', 'office@caiyiyun.com', '北京', '北京大学商学院学生会宣传部', '本科', 10, '团员', NULL, NULL, '12cbbcaa7e7715329bf498ba31ecd5f80c4784c9cc648f6fda872109ee90823d', '282');
INSERT INTO `worker` VALUES (283, '林现瑜', '男', '22', '13516745389', '436536345@qq.com', '广州市', '龙岩学院', '本科', 10, '群众', NULL, NULL, '8410f01057e8bf73645e907ed5eac38d6e51350aa94aaa92daa2123a3f9e0bd1', '283');
INSERT INTO `worker` VALUES (284, '黄柏仪', '男', '27', '', '34526526@qq.com', '', '', '本科', 0, '群众', NULL, NULL, '8fa634aed783b9eccb3d94d4818d0001f9902789c1b27776664dc8c9e9279ece', '284');
INSERT INTO `worker` VALUES (285, '周逸', '男', '28', '13134567893', '536541856@qq.com', '广东省广州市', '南京审计大学', '本科', 8, '群众', NULL, NULL, '095d32deafb9c702b36c89e1788ed5dd601754e957928e9f66e0a8d1bada17dd', '285');
INSERT INTO `worker` VALUES (286, '夏雅惠', '男', '28', '13127364859', '1738492887@qq.com', '住址', '上海外国语大学', '本科', 0, '群众', NULL, NULL, '5dfde70ea65510ef47051267476ac8ccc9916a79fa5b6357206c82ce06d957cc', '286');
INSERT INTO `worker` VALUES (287, '王采现', '男', '27', '', '23425244@qq.com', '', '重庆工商大学', '', 7, '群众', NULL, NULL, '7a2f1322221f5b1f511d7312f223ce420dd326fc04236236cef28c31178b748d', '287');
INSERT INTO `worker` VALUES (288, '林孟霖', '男', '25', '13167237434', 'Linger@139.com', '广东省广州市', '湖南文理学院', '本科', 5, '群众', NULL, NULL, '8ea30d578a7ed8b3b242c4ca2a599a03e38df3db08f652640c6fcd3c97783984', '288');
INSERT INTO `worker` VALUES (289, '林竹水', '男', '24', '13154568797', 'Linger@139.com', '', '经济学院”先进个人“', '本科', 6, '群众', NULL, NULL, 'ff1a39f6423a0ff2a049ecb0f147da94d8e720fc16165096f9f996cb2eedd05f', '289');
INSERT INTO `worker` VALUES (290, '王怡乐', '男', '26', '13175648392', '84673528@qq.com', '广东省广州市', '2016-2020湘南学院', '本科', 4, '群众', NULL, NULL, 'a79e1f19b147d5a8f7a0e2c05d3ca5ddc51c63f180d8af5e06a738c45328112a', '290');
INSERT INTO `worker` VALUES (291, '王爱乐', '男', '27', '', '342562455@qq.com', '广东省广州市', '云南大学获国家', '本科', 4, '群众', NULL, NULL, '49d49969b43e001f83998d38c13a0f2e8c7306f329ffe9d39beffcc3ce26dc90', '291');
INSERT INTO `worker` VALUES (292, '金佳蓉', '男', '27', '13545678765', '123456@qq.com', '江西省高校联盟', '艺术与设计学院', '本科', 8, '群众', NULL, NULL, '2484c5f34472b04c7a7c7bc086f8bf660b12305d5e471701be4d24f9a6ff5a33', '292');
INSERT INTO `worker` VALUES (293, '韩健毓', '男', '30', '13565456343', '12345456@qq.com', '吉林省/长春市', '长春大学', '', 8, '群众', NULL, NULL, '96d701bf648b8e6c9945479498f9a4365790c9a35e514573276e768e698f5bdc', '293');
INSERT INTO `worker` VALUES (294, '李士杰', '男', '24', '', '12345456@qq.com', '', '吉林大学', '本科', 0, '群众', NULL, NULL, '29b0b3941d7c7acef4b24d77c6ed903ed7fadfbb4dd6183b2dd85ab98a355fea', '294');
INSERT INTO `worker` VALUES (295, '陈萱珍', '男', '23', '13144556789', '43234325@qq.com', '河北省邢台市', '邢台医学高等专科学校', '大专', 0, '群众', NULL, NULL, '57648cf96145c868973323fe9d49c4c2254747bcff2a37df146b49b5f48ac838', '295');
INSERT INTO `worker` VALUES (296, '苏姿婷', '男', '29', '13534567898', '5342637@qq.com', '浙江省绍兴市', '绍兴文理学院', '本科', 10, '群众', NULL, NULL, '48d1a2293180a2887ebed11d5107f741054b8ad23d576f9ca1e7b96756fc6a49', '296');
INSERT INTO `worker` VALUES (297, '张政霖', '男', '26', '131912345667', '4324654@qq.com', '上海市浦东新区', '南京航空航天大学', '本科', 6, '群众', NULL, NULL, '12eef3a0096f12375ad53e7c594a89cea4dee623804a2ad601f39616e3a4e985', '297');
INSERT INTO `worker` VALUES (298, '李志宏', '女', '24', '13877665544', '123123@qq.com', '地址', '华东政法大学', '本科', 6, '群众', NULL, NULL, '37391266dc78b1a888be03c5ad102a6d8f7769c67042c61c14142ad0a5a61a81', '298');
INSERT INTO `worker` VALUES (299, '陈素达', '男', '25', '13119876543', '12343556@qq.com', '', '哈尔滨工程大学', '本科', 9, '群众', NULL, NULL, 'a15629b38881d5380cfa7761beea99b00934cefe46e9b389e81f30ff46127de8', '299');
INSERT INTO `worker` VALUES (300, '陈虹荣', '女', '32', '13144556677', '23243545@qq.com', '广东省广州市', '深圳技术大学', '本科', 6, '群众', NULL, NULL, 'fe4195b94cdd76d705502f6168794a4d71e959145adc7c83eea0c9c6f1064110', '300');

SET FOREIGN_KEY_CHECKS = 1;
